#!/usr/bin/env python3
"""End-to-end API tests for Uniheaven (bugs + new features).

Start a scratch server first (from the repo root):

    rm -rf /tmp/unitest && UNI_REGISTER_MAX=7 python3 server.py \
        --port 8077 --datadir /tmp/unitest --host 127.0.0.1

then run:

    python3 tests/e2e.py
"""
import io
import json
import os
import subprocess
import sys
import time
import urllib.request
import urllib.error
import zipfile

B = "http://127.0.0.1:8077/api"
PASS = 0
FAIL = 0


def req(method, path, token=None, body=None, raw=None, headers=None):
    r = urllib.request.Request(
        B + "/" + path, method=method,
        data=raw if raw is not None else (json.dumps(body).encode() if body is not None else None),
        headers=(headers or {}) | ({"Authorization": "Bearer " + token} if token else {}))
    try:
        with urllib.request.urlopen(r, timeout=30) as resp:
            ct = resp.headers.get("Content-Type", "")
            data = resp.read()
            if "json" in ct:
                return resp.status, dict(resp.headers), json.loads(data)
            return resp.status, dict(resp.headers), data
    except urllib.error.HTTPError as e:
        try:
            return e.code, dict(e.headers), json.loads(e.read())
        except Exception:
            return e.code, dict(e.headers), {}


def check(label, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print("  ok   %s" % label)
    else:
        FAIL += 1
        print("  FAIL %s %s" % (label, extra))


def register(name):
    code, _, d = req("POST", "register", body={"username": name, "password": "password123"})
    return d.get("token") if code == 200 else None


print("== 1. registration + rate limit (UNI_REGISTER_MAX=7)")
ta = register("alice")
check("alice registered", bool(ta))
tb = register("bob")
check("bob registered", bool(tb))
for i in range(5):
    register("spam%d" % i)
code, _, d = req("POST", "register", body={"username": "spam5", "password": "password123"})
check("8th registration in window -> 429", code == 429, "got %s" % code)

print("== 2. admin panel password generation")
code, _, d = req("POST", "admin", body={"username": "eye", "password": "internetheaven"})
check("old hardcoded password rejected", code == 401, "got %s" % code)
# read the generated password from the server log
# the server's stderr log (admin password is printed there once)
LOG_PATH = sys.argv[1] if len(sys.argv) > 1 else "/tmp/opencode/uni.log"
log = open(LOG_PATH).read()
import re as _re
m = _re.search(r"password: ([A-Za-z0-9_-]+)", log)
check("generated admin password printed to stderr", bool(m), log[-300:])
if m:
    code, _, d = req("POST", "admin", body={"username": "eye", "password": m.group(1)})
    check("admin login with generated password", code == 200 and "token" in d)
    tadmin = d.get("token")
    code, _, d = req("GET", "admin/users", tadmin)
    check("admin users list", code == 200 and len(d.get("users", [])) >= 2)

print("== 3. private space + activity redaction")
code, _, d = req("POST", "spaces", ta, {"name": "secret-notes", "public": False})
sid = d["id"] if code == 200 else None
check("private space created", bool(sid))
code, _, d = req("PUT", "spaces/%s/note" % sid, ta,
                 {"path": "diary/exam.md", "content": "secret content", "message": "hush"})
check("note saved in private space", code == 200)
code, _, d = req("GET", "activity", None)
acts = d.get("activity", [])
leak = [a for a in acts if a.get("space_name") == "secret-notes"]
check("guest feed hides private space name/path",
      all(a.get("space") is None and a.get("path") is None for a in leak), str(leak))
code, _, d = req("GET", "activity", ta)
acts = d.get("activity", [])
mine = [a for a in acts if a.get("space_name") == "secret-notes"]
check("owner still sees own private activity", any(a.get("path") == "diary/exam.md" for a in mine))

print("== 4. path traversal blocked")
code, _, d = req("GET", "spaces/%s/history?branch=../../%s/revlogs/main" % (sid, sid), ta)
check("history traversal -> 400", code == 400, "got %s" % code)
code, _, d = req("GET", "spaces/%s/history?branch=../../../deadlines" % sid, ta)
check("deadlines traversal -> 400", code == 400, "got %s" % code)
code, _, d = req("GET", "spaces/%s/tree?branch=../x" % sid, ta)
check("tree traversal -> 400", code == 400, "got %s" % code)
# bob's own public space, traversal to alice's private revlog
code, _, d = req("POST", "spaces", tb, {"name": "bob-public", "public": True})
bpub = d["id"]
code, _, d = req("GET", "spaces/%s/history?branch=../../%s/revlogs/main" % (bpub, sid), tb)
check("traversal via own space -> 400", code == 400, "got %s" % code)

print("== 5. header injection blocked")
code, _, d = req("POST", "spaces", tb, {"name": "evil\r\nX-Evil: injected", "public": True})
check("space name with CRLF rejected", code == 400, "got %s: %s" % (code, d))

print("== 6. collaborators + viewers on private spaces")
code, _, d = req("PATCH", "spaces/%s" % sid, ta,
                 {"collaborators": ["bob"], "viewers": ["bob"]})
check("patch sets collab+viewer", code == 200, str(d)[:100])
code, _, d = req("GET", "spaces/%s" % sid, tb)
check("bob (collab) can now view private space", code == 200, "got %s" % code)
code, _, d = req("PUT", "spaces/%s/note" % sid, tb,
                 {"path": "diary/bob.md", "content": "bob edit"})
check("bob (collab) can edit private space", code == 200, "got %s" % code)
code, _, d = req("GET", "spaces/%s" % sid, tb)
check("space lists viewers", code == 200 and "bob" in d.get("viewers", []))
# now demote bob to viewer only
code, _, d = req("PATCH", "spaces/%s" % sid, ta, {"collaborators": [], "viewers": ["bob"]})
check("bob demoted to viewer", code == 200)
code, _, d = req("GET", "spaces/%s" % sid, tb)
check("bob (viewer) still sees space", code == 200, "got %s" % code)
code, _, d = req("PUT", "spaces/%s/note" % sid, tb,
                 {"path": "diary/nope.md", "content": "x"})
check("bob (viewer) cannot edit", code == 403, "got %s" % code)
code, _, d = req("GET", "notifications", tb)
check("bob got share notification",
      any(n.get("type") == "share" for n in d.get("notifications", [])), str(d)[:150])

print("== 7. restore from history")
code, _, d = req("PUT", "spaces/%s/note" % sid, ta,
                 {"path": "notes/thm.md", "content": "version 1"})
check("note v1 saved", code == 200)
code, _, d = req("PUT", "spaces/%s/note" % sid, ta,
                 {"path": "notes/thm.md", "content": "version 2"})
check("note v2 saved", code == 200)
code, _, d = req("GET", "spaces/%s/note-history?path=notes/thm.md&branch=main" % sid, ta)
check("note-history lists revs", code == 200 and len(d["revs"]) >= 2, str(d)[:150])
code, _, d = req("GET", "spaces/%s/note?path=notes/thm.md" % sid, ta)
check("head is version 2", d.get("content") == "version 2")
# note-history is newest-first: [v2 rev, v1 rev]
code, _, d = req("GET", "spaces/%s/note-history?path=notes/thm.md&branch=main" % sid, ta)
v1rev = d["revs"][-1]["rev"] if len(d["revs"]) >= 2 else None
check("found the rev containing version 1", v1rev is not None)
code, _, d = req("POST", "spaces/%s/restore" % sid, ta,
                 {"path": "notes/thm.md", "branch": "main", "rev": v1rev})
check("restore to version 1 rev ok", code == 200 and d.get("rev"), str(d)[:150])
code, _, d = req("GET", "spaces/%s/note?path=notes/thm.md" % sid, ta)
check("content restored to version 1", d.get("content") == "version 1")
code, _, d = req("GET", "spaces/%s/history?branch=main" % sid, ta)
check("restore created a new revision", len(d["revs"]) >= 5)
code, _, d = req("POST", "spaces/%s/restore" % sid, ta,
                 {"path": "notes/thm.md", "branch": "main", "rev": 1})
check("restore to rev 1 (note did not exist) deletes it", code == 200, str(d)[:150])
code, _, d = req("GET", "spaces/%s/note?path=notes/thm.md" % sid, ta)
check("note gone after restore-to-1", code == 404)
code, _, d = req("POST", "spaces/%s/restore" % sid, tb,
                 {"path": "x.md", "branch": "main", "rev": 0})
check("viewer cannot restore", code == 403, "got %s" % code)
code, _, d = req("POST", "spaces/%s/restore" % sid, ta,
                 {"path": "x.md", "branch": "../..", "rev": 0})
check("restore with traversal branch -> 400", code == 400)

print("== 8. import (JSON + zip + new space)")
code, _, d = req("POST", "spaces/%s/import" % sid, ta,
                 {"branch": "main",
                  "files": [{"path": "imp/a.md", "content": "file a"},
                            {"path": "imp/b.md", "content": "file b"},
                            {"path": "../../evil.md", "content": "evil"}]})
check("import with traversal path rejected atomically", code == 400, str(d)[:120])
code, _, d = req("GET", "spaces/%s/note?path=imp/a.md" % sid, ta)
check("no partial import after rejection", code == 404)
code, _, d = req("POST", "spaces/%s/import" % sid, ta,
                 {"branch": "main",
                  "files": [{"path": "imp/a.md", "content": "file a"},
                            {"path": "imp/b.md", "content": "file b"}]})
check("valid import ok", code == 200 and d.get("imported") == 2, str(d)[:150])
code, _, d = req("GET", "spaces/%s/note?path=imp/a.md" % sid, ta)
check("imported file readable", d.get("content") == "file a")
# zip import
buf = io.BytesIO()
with zipfile.ZipFile(buf, "w") as z:
    z.writestr("zipdir/c.md", "zip file c")
    z.writestr("zipdir/d.md", "zip file d")
    z.writestr("META.json", "{}")
code, _, d = req("POST", "spaces/%s/import-zip?branch=main" % sid, ta,
                 raw=buf.getvalue(), headers={"Content-Type": "application/zip"})
check("zip import ok", code == 200 and d.get("imported") == 2, str(d)[:150])
code, _, d = req("GET", "spaces/%s/note?path=zipdir/c.md" % sid, ta)
check("zipped file readable", d.get("content") == "zip file c")
code, _, d = req("POST", "spaces/%s/import-zip?branch=../x" % sid, ta,
                 raw=b"PK", headers={"Content-Type": "application/zip"})
check("zip import bad branch -> 400", code == 400)
# new space from files
code, _, d = req("POST", "spaces/import", ta,
                 {"name": "imported-space",
                  "files": [{"path": "ch1.md", "content": "chapter one"},
                            {"path": "ch2.md", "content": "chapter two"}]})
check("new space from import", code == 200 and d.get("owner") == "alice", str(d)[:150])
nid = d.get("id")
code, _, d = req("GET", "spaces/%s/note?path=ch2.md" % nid, ta)
check("new space note readable", d.get("content") == "chapter two")

print("== 9. regression: old features still work")
code, _, d = req("POST", "spaces/%s/branches" % sid, ta, {"name": "draft", "from": "main"})
check("branch created", code == 200)
code, _, d = req("PUT", "spaces/%s/note?branch=draft" % sid, ta,
                 {"path": "imp/a.md", "content": "changed on draft"})
check("edit on branch", code == 200)
code, _, d = req("POST", "spaces/%s/merge" % sid, ta, {"source": "draft", "target": "main"})
check("merge ok", code == 200 and d.get("merged"), str(d)[:120])
code, _, d = req("POST", "spaces/%s/comments" % sid, tb,
                 {"path": "imp/a.md", "text": "nice @alice"})
check("comment ok (bob is viewer)", code == 200)
code, _, d = req("POST", "spaces/%s/fork" % sid, tb)
check("fork ok", code == 200 and d.get("owner") == "bob")
code, _, d = req("POST", "star/%s" % sid, tb)
check("star ok", code == 200 and d.get("starred"))
code, _, d = req("GET", "search?q=draft", ta)
check("search finds merged note", any(n.get("path") == "imp/a.md" for n in d.get("notes", [])), str(d)[:150])
code, _, d = req("GET", "spaces/%s/note?path=imp/a.md&rev=abc" % sid, ta)
check("rev=abc -> 400 (not 500)", code == 400, "got %s" % code)
code, _, d = req("GET", "spaces/%s/export.txt?branch=main" % sid, ta)
check("export.txt ok", code == 200 and b"NOTES" in (d if isinstance(d, bytes) else b""))

print("== 10. export filename is header-safe")
code, _, d = req("POST", "spaces", tb, {"name": "Analysis & proofs (2026)", "public": True})
sid2 = d["id"]
code, hdrs, d = req("GET", "spaces/%s/export?branch=main" % sid2, tb)
cd = hdrs.get("Content-Disposition", "")
check("zip export works with punctuation name", code == 200 and "Analysis & proofs (2026)-main.zip" in cd, cd)
check("no CR/LF in Content-Disposition", "\r" not in cd and "\n" not in cd)

print()
print("PASS=%d FAIL=%d" % (PASS, FAIL))
sys.exit(1 if FAIL else 0)
