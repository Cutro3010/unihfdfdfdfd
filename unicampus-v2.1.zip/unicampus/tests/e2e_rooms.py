#!/usr/bin/env python3
"""End-to-end API tests for: rooms (heaven hotel), fuzzy finder, admin stats,
security headers.

Start a scratch server first (from the repo root):

    rm -rf /tmp/unitest && UNI_REGISTER_MAX=100 python3 server.py \
        --port 8077 --datadir /tmp/unitest --host 127.0.0.1

then run:

    python3 tests/e2e_rooms.py
"""
import json
import sys
import time
import urllib.request
import urllib.error

B = "http://127.0.0.1:8077/api"
PASS = 0
FAIL = 0


def req(method, path, token=None, body=None):
    r = urllib.request.Request(
        B + "/" + path, method=method,
        data=json.dumps(body).encode() if body is not None else None,
        headers={"Authorization": "Bearer " + token} if token else {})
    try:
        with urllib.request.urlopen(r, timeout=30) as resp:
            ct = resp.headers.get("Content-Type", "")
            data = resp.read()
            if "json" in ct:
                return resp.status, dict(resp.headers), json.loads(data)
            return resp.status, dict(resp.headers), data
    except urllib.error.HTTPError as e:
        try:
            return e.code, dict(e.headers), json.loads(e.read())
        except Exception:
            return e.code, dict(e.headers), {}


def check(label, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print("  ok   %s" % label)
    else:
        FAIL += 1
        print("  FAIL %s %s" % (label, extra))


def register(name):
    code, _, d = req("POST", "register", body={"username": name, "password": "password123"})
    return d.get("token") if code == 200 else None


print("== setup")
ta = register("alice")
tb = register("bob")
tc = register("carol")
check("users registered", bool(ta) and bool(tb) and bool(tc))

print("== 1. rooms")
code, _, d = req("GET", "room", ta)
check("own room auto-created", code == 200 and d["room"]["owner"] == "alice",
      str(d)[:150])
rid = d["room"]["id"]
check("room has unique id", bool(rid))
code, _, d = req("PATCH", "rooms/%s" % rid, ta, {"name": "the study tower",
                                                "tagline": "where math happens"})
check("owner renames room + tagline", code == 200 and d["room"]["name"] == "the study tower")
code, _, d = req("PATCH", "rooms/%s" % rid, tb, {"name": "hacked"})
check("non-owner cannot edit", code == 403)
code, _, d = req("PATCH", "rooms/%s" % rid, ta, {"name": "x" * 100})
check("name too long rejected", code == 400)
code, _, d = req("GET", "rooms/%s" % rid, tb)
check("room fully visible to others", code == 200 and d["room"]["tagline"] == "where math happens")
code, _, d = req("GET", "rooms", tb)
check("rooms list", code == 200 and any(r["id"] == rid for r in d["rooms"]))

print("== 2. room widgets (save endpoint)")
code, _, d = req("POST", "rooms/%s/save" % rid, ta, {
    "section": "todos",
    "data": [{"id": "l1", "name": "exams", "items": [
        {"id": "i1", "text": "study calc", "done": False},
        {"id": "i2", "text": "sleep", "done": True}]}]})
check("todos saved", code == 200 and d["room"]["todos"][0]["name"] == "exams",
      str(d)[:150])
code, _, d = req("POST", "rooms/%s/save" % rid, ta, {
    "section": "postits",
    "data": [{"id": "p1", "x": 12, "y": 34, "color": "#f85149", "text": "dont forget!"}]})
check("postits saved", code == 200 and d["room"]["postits"][0]["x"] == 12)
code, _, d = req("POST", "rooms/%s/save" % rid, ta, {
    "section": "postits", "data": [{"id": "p1", "x": 0, "y": 0,
                                    "color": "#000000", "text": "x"}]})
check("bad postit color coerced", code == 200 and d["room"]["postits"][0]["color"] in
      ("#4da3ff", "#3fb950", "#f85149", "#d29922", "#ff66cc", "#8b98a5"))
code, _, d = req("POST", "rooms/%s/save" % rid, ta, {
    "section": "notes",
    "data": [{"id": "n1", "text": "# annotated\n==highlighted== text with $x^2$"}]})
check("notes saved", code == 200 and len(d["room"]["notes"]) == 1)
code, _, d = req("POST", "rooms/%s/save" % rid, ta,
                 {"section": "notes", "data": [{"id": "n1", "text": "x" * 5000}]})
check("oversize note rejected", code == 400)
code, _, d = req("POST", "rooms/%s/save" % rid, tb, {"section": "todos", "data": []})
check("non-owner cannot save", code == 403)
code, _, d = req("GET", "rooms/%s" % rid, tb)
check("widgets visible to visitors", code == 200 and d["room"]["todos"]
      and d["room"]["postits"] and d["room"]["notes"])

print("== 3. flashcards import")
code, _, tmpl = req("GET", "rooms/%s/deck-template" % rid, ta)
check("card template", code == 200 and b"uniheaven flashcard format" in tmpl)
txt = """# name: Calc cards

front: derivative of sin(x)
back: cos(x)

front: integral of 1/x
back: ln|x| + C
"""
code, _, d = req("POST", "rooms/%s/import-deck" % rid, ta, {"txt": txt})
check("deck imported", code == 200 and d.get("deck_id")
      and len(d["room"]["decks"][d["deck_id"]]["cards"]) == 2, str(d)[:200])
code, _, d = req("POST", "rooms/%s/import-deck" % rid, ta,
                 {"txt": "front: only a front\n"})
check("unfinished card rejected", code == 400)
code, _, d = req("POST", "rooms/%s/import-deck" % rid, tb, {"txt": txt})
check("non-owner cannot import", code == 403)

print("== 4. fuzzy finder")
code, _, d = req("POST", "spaces", ta, {"name": "Analysis notes", "public": True})
sid = d["id"]
req("PUT", "spaces/%s/note" % sid, ta,
    {"path": "ch1.md", "content": "the mean value theorem connects derivatives and eigenvalues"})
req("POST", "tests", ta, {"title": "Eigenvalue quiz",
                          "questions": [{"type": "tf", "text": "eigenvectors are neat",
                                         "answer": "true"}]})
req("POST", "chats", ta, {"type": "dm", "members": ["bob"]})
dm = req("GET", "chats", ta)[2]["chats"][0]["id"]
req("POST", "chats/%s/messages" % dm, ta, {"text": "secret about eigenvalues, bob"})
code, _, d = req("GET", "find?q=eigenval", ta)
kinds = {r["kind"] for r in d.get("results", [])}
check("finder hits test + chat + note", code == 200
      and {"test", "chat", "note"} <= kinds, str(kinds))
code, _, d = req("GET", "find?q=mean+value", ta)
check("note snippet found", any(r["kind"] == "note" and "mean value" in r["snippet"]
      for r in d["results"]), str(d)[:200])
code, _, d = req("GET", "find?q=eigenval", tc)
bob_hits = [r for r in d["results"] if r["kind"] == "chat"]
check("chat messages private to non-members", not bob_hits, str(bob_hits)[:200])
code, _, d = req("GET", "find?q=eigenval", tb)
tb_hits = [r for r in d["results"] if r["kind"] == "chat"]
check("chat messages visible to members", bool(tb_hits), str(tb_hits)[:200])
code, _, d = req("GET", "find?q=study+tower", tb)
check("room found by visitor", any(r["kind"] == "room" and r["link"].endswith(rid)
      for r in d["results"]))
code, _, d = req("GET", "find?q=zzzqqqnothere", ta)
check("no results ok", code == 200 and d["results"] == [])

print("== 5. admin stats")
# grab the generated admin password
log = open("/tmp/opencode/uni.log").read()
import re as _re
m = _re.search(r"password: ([A-Za-z0-9_-]+)", log)
adm = None
if m:
    code, _, d = req("POST", "admin", body={"username": "eye", "password": m.group(1)})
    adm = d.get("token")
check("admin login", bool(adm))
code, _, d = req("GET", "admin/stats", adm)
check("stats endpoint", code == 200 and "counts" in d and "routes" in d
      and "series" in d, str(d)[:200])
check("counts include new types", all(k in d["counts"] for k in
      ("users", "tests", "events", "chats", "messages", "rooms")), str(d["counts"]))
check("route stats recorded", any(r["n"] > 0 for r in d["routes"]), str(d["routes"])[:200])
code, _, d = req("GET", "admin/tests", adm)
check("admin tests list", code == 200 and any(t["title"] == "Eigenvalue quiz" for t in d["tests"]))
code, _, d = req("GET", "admin/events", adm)
check("admin events list", code == 200)

print("== 6. security headers")
code, hdrs, _ = req("GET", "me", None)
check("json nosniff", hdrs.get("X-Content-Type-Options") == "nosniff")
check("json frame deny", hdrs.get("X-Frame-Options") == "DENY")
r = urllib.request.Request("http://127.0.0.1:8077/index.html")
with urllib.request.urlopen(r) as resp:
    hdrs = dict(resp.headers)
    check("html has CSP", "Content-Security-Policy" in hdrs and "default-src" in hdrs["Content-Security-Policy"])
    check("referrer policy", hdrs.get("Referrer-Policy") == "no-referrer")
code, _, d = req("GET", "spaces/%s/note?path=ch1.md&rev=abc" % sid, ta)
check("bad rev no longer leaks exception text", code == 400, str(d)[:120])

print()
print("PASS=%d FAIL=%d" % (PASS, FAIL))
sys.exit(1 if FAIL else 0)
