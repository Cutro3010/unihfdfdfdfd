#!/usr/bin/env python3
"""End-to-end API tests for Uniheaven's new features:
exercises/tests, calendar/events, chats, leaderboard.

Start a scratch server first (from the repo root):

    rm -rf /tmp/unitest && UNI_REGISTER_MAX=100 UNI_WATCH_INTERVAL=1 \
        python3 server.py --port 8077 --datadir /tmp/unitest --host 127.0.0.1

then run:

    python3 tests/e2e_new.py
"""
import json
import sys
import time
import urllib.request
import urllib.error

B = "http://127.0.0.1:8077/api"
PASS = 0
FAIL = 0


def req(method, path, token=None, body=None, raw=None):
    r = urllib.request.Request(
        B + "/" + path, method=method,
        data=raw if raw is not None else (json.dumps(body).encode() if body is not None else None),
        headers={"Authorization": "Bearer " + token} if token else {})
    try:
        with urllib.request.urlopen(r, timeout=30) as resp:
            ct = resp.headers.get("Content-Type", "")
            data = resp.read()
            if "json" in ct:
                return resp.status, dict(resp.headers), json.loads(data)
            return resp.status, dict(resp.headers), data
    except urllib.error.HTTPError as e:
        try:
            return e.code, dict(e.headers), json.loads(e.read())
        except Exception:
            return e.code, dict(e.headers), {}


def check(label, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print("  ok   %s" % label)
    else:
        FAIL += 1
        print("  FAIL %s %s" % (label, extra))


def register(name):
    code, _, d = req("POST", "register", body={"username": name, "password": "password123"})
    return d.get("token") if code == 200 else None


print("== setup")
ta = register("alice")
tb = register("bob")
tc = register("carol")
check("3 users registered", bool(ta) and bool(tb) and bool(tc))

print("== 1. tests: create / list / answers hidden")
TEST = {
    "title": "Calculus quiz", "subject": "math", "tags": ["calculus", "derivatives"],
    "description": "a quick quiz", "public": True,
    "questions": [
        {"type": "mc", "text": "derivative of $x^2$?", "choices": ["x", "2", "2x"],
         "answer": ["2x"], "explanation": "power rule"},
        {"type": "tf", "text": "sin' = cos", "answer": ["true"]},
        {"type": "open", "text": "integral of 1/x?", "answer": ["ln|x| + C", "log(x) + C"]},
    ],
}
code, _, d = req("POST", "tests", ta, TEST)
check("create test", code == 200 and d.get("id"), str(d)[:150])
tid = d.get("id")
code, _, d = req("GET", "tests", ta)
check("test listed", code == 200 and any(t["id"] == tid for t in d["tests"]))
code, _, d = req("GET", "tests/" + tid, tb)
check("taker view", code == 200 and len(d["questions"]) == 3)
check("answers hidden from takers", all("answer" not in q for q in d["questions"]),
      str(d["questions"])[:200])
check("explanation hidden from takers", all("explanation" not in q for q in d["questions"]))
code, _, d = req("GET", "tests/" + tid, ta)
check("owner sees answers", code == 200 and "answer" in d["questions"][0])
code, _, d = req("POST", "tests", tb, {"title": "no images",
                                       "questions": [{"type": "open", "text": "![x](http://a/b.png) what?",
                                                      "answer": "x"}]})
check("images rejected in question text", code == 400, str(d)[:120])
code, _, d = req("POST", "tests", tb, {"title": "no images 2",
                                       "questions": [{"type": "mc", "text": "pick",
                                                      "choices": ["![x](http://a/b.png)", "b"],
                                                      "answer": ["b"]}]})
check("images rejected in choices", code == 400, str(d)[:120])

print("== 2. tests: submit / grading / results")
code, _, d = req("POST", "tests/%s/submit" % tid, tb,
                 {"answers": {"q1": "2x", "q2": "true", "q3": "LN|x|+C"}, "seconds": 95})
check("submit graded", code == 200 and d.get("score") == 3, str(d)[:200])
check("details returned", len(d.get("details", [])) == 3 and all("ok" in x for x in d["details"]))
code, _, d = req("POST", "tests/%s/submit" % tid, tc,
                 {"answers": {"q1": "x", "q2": "false", "q3": "nope"}, "seconds": 60})
check("bad submission graded low", code == 200 and d.get("score") == 0, str(d)[:150])
code, _, d = req("GET", "tests/%s/results" % tid, tb)
check("results sorted by score", code == 200 and d["results"][0]["user"] == "bob",
      str(d)[:200])
code, _, d = req("POST", "tests/%s/submit" % tid, tb,
                 {"answers": {"q1": "x", "q2": "true", "q3": "ln|x|+C"}, "seconds": 30})
check("retake overwrites (best kept)", code == 200)
code, _, d = req("GET", "tests/%s/results" % tid, tb)
check("retake replaced previous result", len(d["results"]) == 2
      and d["results"][0]["user"] == "bob" and d["results"][0]["score"] == 2, str(d)[:200])
code, _, d = req("GET", "tests/" + tid, tb)
check("my_result returned", code == 200 and d.get("my_result", {}).get("score") == 2)

print("== 3. tests: private visibility")
code, _, d = req("POST", "tests", ta, {"title": "secret test", "public": False,
                                       "questions": [{"type": "tf", "text": "1=1", "answer": "true"}]})
stid = d["id"]
code, _, d = req("GET", "tests/" + stid, tb)
check("private test hidden from others", code == 404)
code, _, d = req("GET", "tests/" + stid, ta)
check("private test visible to owner", code == 200)

print("== 4. tests: txt import / template / export")
code, _, tmpl = req("GET", "tests/template", ta)
check("template endpoint", code == 200 and b"uniheaven test format" in tmpl)
txt = """# title: Imported by AI
# subject: physics
# tags: mechanics

Q1 (mc)
What is g on earth?
- 9.8 m/s^2
- 3.7 m/s^2
+ 9.8 m/s^2
# explain: standard gravity

Q2 (tf)
Force equals mass times acceleration.
= true

Q3 (open)
Who formulated the laws of motion?
= Newton || Isaac Newton
"""
code, _, d = req("POST", "tests/import", ta, {"txt": txt})
check("txt import ok", code == 200 and d.get("n_questions") == 3, str(d)[:150])
itid = d["id"]
code, _, d = req("POST", "tests/%s/submit" % itid, tb,
                 {"answers": {"q1": "9.8 m/s^2", "q2": "true", "q3": "isaac newton"},
                  "seconds": 40})
check("imported test grades (open alternative)", code == 200 and d.get("score") == 3,
      str(d)[:150])
code, _, d = req("POST", "tests/import", ta, {"txt": txt.replace("Q1 (mc)", "Q1 (bogus)")})
check("bad type rejected", code == 400, str(d)[:120])
code, _, d = req("POST", "tests/import", ta, {"txt": "# title: x\n\nQ1 (mc)\nwhat?\n- a\n- b\n"})
check("mc without + answer rejected", code == 400, str(d)[:120])
code, _, d = req("POST", "tests/import", ta,
                 {"txt": "# title: img\n\nQ1 (open)\na ![x](http://e/f.png) b?\n= x\n"})
check("image in import rejected", code == 400, str(d)[:120])
code, _, d = req("GET", "tests/%s/export.txt" % itid, ta)
check("export.txt owner", code == 200 and b"Q1 (mc)" in d and b"+ 9.8 m/s^2" in d)
code, _, d = req("GET", "tests/%s/export.txt" % itid, tb)
check("export.txt owner-only", code == 403)
code, _, d = req("DELETE", "tests/" + stid, tb)
check("delete denied for non-owner", code == 403)
code, _, d = req("DELETE", "tests/" + stid, ta)
check("delete by owner", code == 200)
code, _, d = req("GET", "tests/" + stid, ta)
check("deleted test gone", code == 404)

print("== 5. leaderboard")
code, _, d = req("GET", "leaderboard", ta)
check("creators list", code == 200 and any(c["username"] == "alice" and c["tests"] >= 1
      for c in d["creators"]), str(d)[:200])
code, _, d = req("GET", "leaderboard", tb)
check("solvers list", code == 200 and any(s["username"] == "bob" and s["tests"] >= 2
      for s in d["solvers"]), str(d)[:200])
code, _, d = req("POST", "spaces", ta, {"name": "lb-space", "public": True})
check("space created for creators lb", code == 200)
code, _, d = req("GET", "leaderboard", tb)
check("space counts towards creators", any(c["username"] == "alice" and c["spaces"] >= 1
      for c in d["creators"]), str(d)[:200])

print("== 6. events")
start = time.time() + 3600 * 2
code, _, d = req("POST", "events", ta,
                 {"title": "office hours", "description": "come ask questions",
                  "start": start, "end": start + 3600})
check("event created", code == 200 and d["event"]["owner"] == "alice")
eid = d["event"]["id"]
code, _, d = req("GET", "events", tb)
check("event visible", code == 200 and any(e["id"] == eid for e in d["events"]))
code, _, d = req("GET", "notifications", tb)
check("new-event notification sent",
      any(n.get("type") == "event" and "office hours" in n.get("text", "")
          for n in d.get("notifications", [])), str(d)[:250])
code, _, d = req("POST", "events/%s/attend" % eid, tb)
check("rsvp attending", code == 200 and d.get("attending") is True)
code, _, d = req("POST", "events/%s/attend" % eid, tb)
check("rsvp toggle off", code == 200 and d.get("attending") is False)
code, _, d = req("DELETE", "events/" + eid, tb)
check("event delete denied for non-owner", code == 403)
code, _, d = req("POST", "events", ta, {"title": "x", "start": "not-a-number"})
check("bad start rejected", code == 400)
code, _, d = req("POST", "events", ta, {"title": "x", "start": time.time() + 11 * 365 * 86400})
check("start too far rejected", code == 400)
# reminder within the hour (watcher interval is 1s in tests)
code, _, d = req("POST", "events", ta, {"title": "urgent lecture", "start": time.time() + 60})
eid2 = d["event"]["id"]
code, _, d = req("POST", "events/%s/attend" % eid2, tb)
check("rsvp for reminder", code == 200)
time.sleep(3)
code, _, d = req("GET", "notifications", tb)
check("event reminder delivered", any(n.get("type") in ("event_soon", "event_today")
      and "urgent lecture" in n.get("text", "") for n in d.get("notifications", [])),
      str(d)[:250])
code, _, d = req("DELETE", "events/" + eid, ta)
check("event delete by owner", code == 200)

print("== 7. chats")
code, _, d = req("POST", "chats", ta, {"type": "dm", "members": ["bob"]})
check("dm created", code == 200 and d["chat"]["type"] == "dm")
dm = d["chat"]["id"]
code, _, d = req("POST", "chats", tb, {"type": "dm", "members": ["alice"]})
check("dm is unique (same pair)", code == 200 and d["chat"]["id"] == dm)
code, _, d = req("POST", "chats/%s/messages" % dm, ta, {"text": "hi bob, how is the proof?"})
check("dm message sent", code == 200)
mid = d["message"]["id"]
code, _, d = req("POST", "chats/%s/messages" % dm, tb, {"text": "good! $e^{i\\pi}+1=0$"})
check("dm reply sent", code == 200)
code, _, d = req("GET", "chats", tb)
chat = next(c for c in d["chats"] if c["id"] == dm)
check("bob sees his own reply (auto-read)", code == 200 and chat["unread"] == 0,
      str(chat)[:200])
code, _, d = req("GET", "chats", ta)
chat = next(c for c in d["chats"] if c["id"] == dm)
check("unread counted for alice after bob's reply", code == 200 and chat["unread"] == 1,
      str(chat)[:200])
code, _, d = req("GET", "chats/%s/messages?after=%s" % (dm, mid), tb)
check("after= pagination", code == 200 and len(d["messages"]) == 1
      and d["messages"][0]["author"] == "bob")
code, _, d = req("POST", "chats/%s/read" % dm, tb)
check("mark read", code == 200)
code, _, d = req("GET", "chats", tb)
chat = next(c for c in d["chats"] if c["id"] == dm)
check("unread cleared", chat["unread"] == 0)
code, _, d = req("GET", "chats/%s/messages" % dm, tc)
check("non-member cannot read dm", code == 404)
code, _, d = req("POST", "chats/%s/messages" % dm, tc, {"text": "spy!"})
check("non-member cannot post", code == 404)
code, _, d = req("POST", "chats", ta, {"type": "group", "name": "study gang",
                                       "members": ["bob", "carol"]})
check("group created", code == 200 and len(d["chat"]["members"]) == 3)
gid = d["chat"]["id"]
code, _, d = req("POST", "chats/%s/messages" % gid, tc, {"text": "study tonight?"})
check("group member posts", code == 200)
code, _, d = req("POST", "chats/%s/add" % gid, tc, {"user": "ghost"})
check("add unknown user rejected", code == 404)
code, _, d = req("POST", "chats/%s/leave" % gid, tc)
check("member leaves group", code == 200)
code, _, d = req("GET", "chats/%s/messages" % gid, tc)
check("left member locked out", code == 404)
code, _, d = req("DELETE", "chats/%s" % gid, tb)
check("group delete denied for non-creator", code == 403)
code, _, d = req("POST", "chats/%s/leave" % dm, tb)
check("dm leave deletes the dm", code == 200)
code, _, d = req("GET", "chats", ta)
check("dm gone after leave", all(c["id"] != dm for c in d.get("chats", [])))
code, _, d = req("POST", "chats", ta, {"type": "dm", "members": ["ghost"]})
check("dm with unknown user rejected", code == 400)

print()
print("PASS=%d FAIL=%d" % (PASS, FAIL))
sys.exit(1 if FAIL else 0)
