#!/usr/bin/env python3
"""End-to-end API tests for streaks + forum categories.

Start a scratch server first (from the repo root):

    rm -rf /tmp/unitest && UNI_REGISTER_MAX=100 python3 server.py \
        --port 8077 --datadir /tmp/unitest --host 127.0.0.1

then run:

    python3 tests/e2e_streak.py
"""
import json
import sys
import urllib.request
import urllib.error

B = "http://127.0.0.1:8077/api"
PASS = 0
FAIL = 0


def req(method, path, token=None, body=None):
    r = urllib.request.Request(
        B + "/" + path, method=method,
        data=json.dumps(body).encode() if body is not None else None,
        headers={"Authorization": "Bearer " + token} if token else {})
    try:
        with urllib.request.urlopen(r, timeout=30) as resp:
            return resp.status, json.loads(resp.read())
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read())
        except Exception:
            return e.code, {}


def check(label, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print("  ok   %s" % label)
    else:
        FAIL += 1
        print("  FAIL %s %s" % (label, extra))


print("== setup")
code, d = req("POST", "register", body={"username": "alice", "password": "password123"})
ta = d.get("token")
check("user registered", code == 200 and bool(ta))

print("== 1. streaks")
code, d = req("GET", "streak/alice", ta)
check("fresh streak is 0", code == 200 and d["stats"]["streak"] == 0
      and d["stats"]["exercises"] == 0 and d["stats"]["studied"] == 0)
code, d = req("POST", "streak/pomo", ta, {"seconds": 1500})
check("pomo recorded", code == 200 and d["stats"]["studied"] == 1500)
code, d = req("POST", "streak/pomo", ta, {"seconds": 99999})
check("oversize pomo rejected", code == 400)
code, d = req("POST", "streak/pomo", ta, {"seconds": "abc"})
check("non-numeric pomo rejected", code == 400)
code, d = req("POST", "tests", ta, {"title": "quiz",
                                    "questions": [{"type": "tf", "text": "1=1", "answer": "true"}]})
tid = d["id"]
code, d = req("POST", "tests/%s/submit" % tid, ta,
              {"answers": {"q1": "true"}, "seconds": 40})
check("submit graded", code == 200)
code, d = req("GET", "streak/alice", ta)
check("exercise counted + streak today", code == 200
      and d["stats"]["exercises"] == 1 and d["stats"]["studied"] == 1500
      and d["stats"]["streak"] == 1, str(d["stats"]))
check("last7 has today", d["stats"]["last7"][-1]["e"] == 1)
code, d = req("GET", "streak/ghost", ta)
check("unknown user 404", code == 404)

print("== 2. forum categories")
code, d = req("POST", "posts", ta, {"text": "hello forum", "cat": "math"})
check("post with category", code == 200 and d["post"]["cat"] == "math")
code, d = req("POST", "posts", ta, {"text": "no cat", })
check("post defaults to general", code == 200 and d["post"]["cat"] == "general")
code, d = req("POST", "posts", ta, {"text": "bad cat", "cat": "bogus"})
check("unknown category rejected", code == 400)
code, d = req("GET", "posts", ta)
check("posts list includes cat + cats", code == 200 and d["cats"]
      and any(p["cat"] == "math" for p in d["posts"]))
code, d = req("POST", "posts", ta,
              {"text": "reply", "parent_id": next(p["id"] for p in d["posts"]
                                                  if p["cat"] == "math")})
check("reply inherits parent category", code == 200 and d["post"]["cat"] == "math")

print()
print("PASS=%d FAIL=%d" % (PASS, FAIL))
sys.exit(1 if FAIL else 0)
