#!/usr/bin/env bash
# ============================================================
# Uniheaven CLI installer - puts the `space` command on your PATH.
# The CLI is one stdlib-only Python file (no dependencies).
#
#   sudo bash install_cli.sh             # install to /usr/local/bin/space
#   bash install_cli.sh --user           # install to ~/.local/bin (no root)
#   sudo bash install_cli.sh --remove    # remove the CLI again
#
# Style follows the web UI (cyberangel/cybercore). Colors are on only
# when the output is a terminal; use NO_COLOR=1 or --no-color to disable.
# ============================================================
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST=/usr/local/bin/space
REMOVE=0
USERMODE=0
for arg in "$@"; do
  case "$arg" in
    --remove) REMOVE=1 ;;
    --user) USERMODE=1 ;;
  esac
done

if [[ $USERMODE -eq 1 ]]; then
  DEST="${HOME}/.local/bin/space"
elif [[ $EUID -ne 0 ]]; then
  echo "run as root (sudo bash install_cli.sh) or use --user"
  exit 1
fi

if [[ $REMOVE -eq 1 ]]; then
  rm -f "$DEST"
  echo "removed $DEST"
  exit 0
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "python3 is required (3.8+). Install it with:  sudo apt install -y python3"
  exit 1
fi

mkdir -p "$(dirname "$DEST")"
install -m 755 "$SRC/space.py" "$DEST"
chmod 755 "$DEST"

echo ""
echo "================================================"
echo " installed: $DEST"
echo ""
echo " try it:    space --help"
echo "            space login USERNAME        (needs a server)"
echo "            space register USERNAME"
echo ""
echo " server:    remembered in ~/.spacecli.json, or use --server / \$SPACE_SERVER"
echo " theme:     \$SPACE_THEME=dark|light · NO_COLOR=1 or --no-color"
echo "================================================"
