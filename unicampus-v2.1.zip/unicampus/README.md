# ============================================================
# Uniheaven - a tiny self-hosted GitHub for your students
#
# One Python process (stdlib only), JSON files on disk, plain
# HTML/CSS/TypeScript frontend, Python CLI. No frameworks, no SQL.
#
#   Notes ("spaces")  - folders + markdown files, #tags connect spaces
#   LaTeX             - $...$ and $$...$$ in every note (KaTeX, self-hosted)
#   Branching         - branch spaces, merge with 3-way conflict resolution
#   Restore           - view any revision of a note and restore it (a new
#                       revision is created, history keeps everything)
#   Import            - add .md files or a .zip of notes (one revision),
#                       or create a whole new space from files
#   Comments          - comment on notes, @mention other users
#   Fork / star       - fork a space with attribution, star your favorites
#   Search / activity - full-text search, tag cloud, activity feed
#   Accounts          - simple registration, passwords hashed (pbkdf2)
#   Sharing           - collaborators (edit) and viewers (read-only)
#   Profiles          - about text, 20x20 logo (pixel editor or photo),
#                       stats: top tags, top words, revision sparkline
#   Deletion          - delete notes or whole folders (history keeps them)
#   News              - twitter-style public posts with replies, @mentions
#                       and chat colors (!£XX codes)
#   Exercises         - upload batches of exercises as "tests" (mc / true-
#                       false / open questions, no images). a .txt preset
#                       lets AI models generate importable tests. timed
#                       taking, grading, explanations, per-test scoreboards
#   Leaderboard       - creators (most spaces + tests) and solvers (most
#                       tests completed in the least time)
#   Calendar          - everyone can add events; everyone is notified, and
#                       reminded the day before and the hour before; rsvp
#   Chats             - private 1:1 messages and group chats, markdown +
#                       math, unread badges, live polling + a global badge
#                       on every page (no reloading needed)
#   Heaven Hotel      - everyone gets a "my room" (unique id, public name +
#                       tagline, visible to all): pomodoro timer (with
#                       presets + streak logging), fuzzy finder over every
#                       resource, ai-importable flashcards, to-do lists,
#                       graph calculator, draggable post-its, annotating
#                       text editor
#   Streaks           - daily streak of exercises solved and time studied
#                       (pomodoro focus sessions report to the server),
#                       shown on profiles and in rooms
#   Forum             - the news feed is a forum: categories (general,
#                       questions, announcements, math, physics, cs,
#                       off-topic), filter chips, replies inherit the
#                       thread's category
#   Split view        - /split.html shows two halves of the site side by
#                       side or stacked: any two pages, drag the divider,
#                       swap panes; layout is remembered
#   Mobile            - every page fits a phone screen (no horizontal
#                       overflow at 375 px; scrollable nav, stacked grids)
#   Admin             - server load + data-quantity graphs, per-route
#                       request stats, moderation for tests and events
#   Updater           - update.sh: repo URL in, backups made, install run
#   Exports           - .zip of the space, one .txt file (structure on
#                       top, notes below), or the open note as PDF
#                       (client-side jsPDF + KaTeX SVG - no printing)
# ============================================================

Quickstart (local machine)
--------------------------
1. Requirements: Python 3.9+. That is all (no Node needed to *run* it).
2. Start the server:
      python server.py --port 8000
3. Open http://127.0.0.1:8000 and register - the first account is admin.
4. Create a space, write notes with $math$, branch, merge, comment.

CLI (space.py)
--------------
Install it once (it is one stdlib-only Python file):

      sudo bash install_cli.sh              # /usr/local/bin/space
      bash install_cli.sh --user            # ~/.local/bin (no root needed)
      sudo bash install_cli.sh --remove     # uninstall the CLI

      python space.py register alice --server http://127.0.0.1:8000
      python space.py create "Analysis" --tags math          # add --private to hide it
      python space.py send "Theorem 5 proof" --space Analysis --path notes/thm5.md
      python space.py rm Analysis --path notes/thm5.md       # delete a note
      python space.py rm Analysis --path notes/              # delete a folder
      python space.py pull Analysis --out notes/
      python space.py push Analysis --dir notes/ --message "week 3"
      python space.py comment Analysis --path notes/thm5.md "nice!"
      python space.py branch Analysis solutions    # then edit + merge
      python space.py merge Analysis --source solutions
      python space.py diff Analysis                # last revision
      python space.py history Analysis
      python space.py search "eigenvalues"
      python space.py fork Analysis                # copy someone's space
      python space.py inbox                        # mentions
      python space.py star Analysis
      python space.py profile alice                # profile + stats
      python space.py about "I teach analysis"     # set your about text
      python space.py collab Analysis              # list collaborators
      python space.py collab Analysis --add bob --remove carol
      python space.py post "office hours moved!"   # public news post
      python space.py export Analysis --out space.txt   # one-file export
      python space.py tags | list | me | logout

  - Login state lives in ~/.spacecli.json (a Bearer token).
  - Server address is remembered; override with --server or $SPACE_SERVER.
  - Non-interactive password: set $SPACE_PASSWORD (useful for scripts).
  - `send` without --space posts to your private auto-created "inbox" space.
  - Viewers: give read-only access via the web UI (space settings) or by
    adding them to the space meta - they see the space but cannot edit.

CLI style
---------
The CLI mirrors the web UI themes. Colors are on only when the output is a
terminal, so scripts stay clean.

      SPACE_THEME=dark|light   force a palette (default: match your terminal)
      NO_COLOR=1  or  --no-color   disable colors entirely

Chat colors
-----------
In posts and comments, a line starting with `!£` gets a color until the
end of the line. Add `m` for monospace (before or after the number).

      !£01..!£09   normal colors    !£11..!£19   dark colors
      !£21..!£29   light colors     !£00         rainbow (animated)
      !£30         warm white       !£m30        warm white + monospace

      Example:  "!£m30 office hours moved to Friday"
      works with $math$ and **bold** on the same line.

VPS installation (Ubuntu/Debian)
--------------------------------
The repo ships precompiled JS and KaTeX, so the VPS only needs Python 3.

      git clone <your-repo> uniheaven && cd uniheaven
      sudo bash install.sh

That installs to /opt/uniheaven, creates an unprivileged `uniheaven`
system user, starts a systemd service (uniheaven.service, port 8000),
and sets up a nightly backup cron (last 14 copies kept in
/opt/uniheaven/backups). Then:

      sudo ufw allow 8000/tcp
      http://<vps-ip>:8000     -> register, first user = admin

Upgrade later (data in /opt/uniheaven/data is never touched):

      git pull && sudo bash install.sh

Wipe everything and start over:

      sudo bash install.sh --fresh      # also: --dry-run to preview

Admin panel (/admin.html)
-------------------------
The admin panel is a separate login (username `eye`) with its own password.
On first start the server generates a random password and prints it once to
the journal (it is stored PBKDF2-hashed in data/admin_creds.json):

      journalctl -u uniheaven | grep "admin page"

To fix the password yourself, set UNI_ADMIN_PASSWORD in the systemd unit
(see the commented Environment line in uniheaven.service).

HTTPS (optional, your own domain)
---------------------------------
Run the app behind a reverse proxy and bind it to localhost. Edit
/etc/systemd/system/uniheaven.service, set Environment=UNI_HOST=127.0.0.1,
then `systemctl daemon-reload && systemctl restart uniheaven`.

Caddy (/etc/caddy/Caddyfile):
      your.domain.tld {
        reverse_proxy 127.0.0.1:8000
      }

nginx (in /etc/nginx/sites-available/uniheaven):
      server {
        listen 443 ssl;
        server_name your.domain.tld;
        # ssl_certificate ... (Let's Encrypt / certbot)
        location / { proxy_pass http://127.0.0.1:8000; }
      }

Backup / restore
----------------
      sudo tar -czf backup.tar.gz -C /opt/uniheaven data     # manual
      sudo tar -xzf backup.tar.gz -C /opt/uniheaven          # restore
The cron job /etc/cron.daily/uniheaven-backup does this nightly.

Uninstall
---------
      sudo bash uninstall.sh            # remove the app, KEEP data + backups
      sudo bash uninstall.sh --purge    # remove the app AND all data/backups
      sudo bash uninstall.sh --dry-run  # preview what would be removed

The CLI is removed with `sudo bash install_cli.sh --remove`.

Project layout
--------------
      server.py            HTTP server + JSON API (stdlib only)
      space.py             CLI client (styled like the web UI)
      install.sh           VPS installer (systemd + backup cron)
      uninstall.sh         removes the app (data kept unless --purge)
      install_cli.sh       installs / removes the `space` CLI
      update.sh            repo URL in -> backups -> clone -> install
      tests/e2e.py         end-to-end API test suite
      web/                 frontend
        index.html         home: spaces, tags, search, feed, events, tests
        space.html         space: tree, editor, comments, branches
        tests.html         exercises: build/import/take tests, scoreboards
        calendar.html      events: month grid, rsvp, reminders
        chats.html         private messages and groups
        leaderboard.html   creators + solvers rankings
        room.html          heaven hotel: my room (widgets, public to all)
        split.html         two panes of the site: horizontal / vertical
        user.html          user profile: about, logo, stats
        css/theme.css      ALL design tokens (angel/light + cyber/dark themes)
        css/layout.css     component styles (tokens only)
        src/*.ts           TypeScript sources
        out/*.js           precompiled JS (committed - VPS needs no Node)
        vendor/katex/      self-hosted KaTeX (on-screen math)
        vendor/mathjax/    tex-svg bundle (vector math for the PDF export)
        vendor/jspdf/      self-hosted jsPDF + svg2pdf (note PDF export)
      data/                created at runtime (users, spaces, notes)
      STYLE.md             how to restyle the app (written for LLMs)

API (JSON, Bearer token or cookie)
----------------------------------
      POST /api/register  POST /api/login  POST /api/logout  GET /api/me
      GET|POST /api/spaces            GET|PATCH|DELETE /api/spaces/<id>
      GET  /api/spaces/<id>/tree?branch=
      GET  /api/spaces/<id>/note?path=&branch=&rev=
      PUT  /api/spaces/<id>/note?branch=        {path, content, message}
      DELETE /api/spaces/<id>/note?path=&branch=   (path with / = folder)
      GET  /api/spaces/<id>/object?sha=
      GET|PUT /api/users/<name>/profile         {about, logo (PNG data URL)}
      GET|POST /api/posts      DELETE /api/posts/<id>   (public news)
      GET  /api/spaces/<id>/export.txt?branch=  (one-file text export)
      GET|POST /api/spaces/<id>/comments?path=
      GET  /api/spaces/<id>/history?branch=
      GET  /api/spaces/<id>/note-history?path=&branch=   (revs touching a note)
      POST /api/spaces/<id>/restore          {path, branch, rev, message?}
      POST /api/spaces/<id>/import           {branch, files:[{path,content}], message?}
      POST /api/spaces/<id>/import-zip?branch=   (raw zip body, .md files only)
      POST /api/spaces/import                create a new space from files
      GET  /api/spaces/<id>/diff?branch=&rev_a=&rev_b=
      POST /api/spaces/<id>/branches            {name, from}
      POST /api/spaces/<id>/merge               {source, target, resolve?}
      POST /api/spaces/<id>/fork
      GET  /api/spaces/<id>/export?branch=      (zip download)
      GET  /api/search?q=      GET /api/tags      GET /api/activity
      POST /api/star/<id>      POST /api/unstar/<id>
      GET  /api/notifications  POST /api/notifications/read
      GET  /api/users?prefix=
      # exercises
      GET|POST /api/tests              GET|DELETE /api/tests/<id>
      POST /api/tests/import           {txt}  (.txt preset, ai-friendly)
      GET  /api/tests/template         (the .txt preset to feed an AI)
      GET  /api/tests/<id>/export.txt  (owner)
      POST /api/tests/<id>/submit      {answers, seconds}
      GET  /api/tests/<id>/results
      GET  /api/leaderboard
      # calendar
      GET|POST /api/events             DELETE /api/events/<id>
      POST /api/events/<id>/attend     (rsvp toggle)
      # chats
      GET|POST /api/chats              GET|DELETE /api/chats/<id>
      GET|POST /api/chats/<id>/messages?after=
      POST /api/chats/<id>/read|add|leave
      # rooms (heaven hotel)
      GET  /api/room                   (your room, auto-created)
      GET  /api/rooms                  GET|PATCH /api/rooms/<id>
      POST /api/rooms/<id>/save        {section: todos|postits|notes|decks, data}
      POST /api/rooms/<id>/import-deck {txt}
      GET  /api/rooms/<id>/deck-template
      GET  /api/find?q=                (fuzzy search over everything visible)
      GET  /api/streak/<user>          POST /api/streak/pomo {seconds}
      # posts carry a forum category (cat): general, questions,
      # announcements, math, physics, cs, off-topic
      # admin extras (eye account)
      GET  /api/admin/stats            (load, latency, data quantities)
      GET|DELETE /api/admin/tests      GET|DELETE /api/admin/events

Exercises / tests (.txt preset for AI models)
---------------------------------------------
The tests page can import a plain-text format. Download the template from
the tests page (or GET /api/tests/template), paste it into an AI model and
ask it to "generate questions in exactly this format", then import the
answer into uniheaven:

      # title: Midterm - Calculus
      # subject: math
      # tags: calculus, derivatives
      # description: optional one-line description
      # public: true|false        (default: true)

      Q1 (mc)
      What is the derivative of x^2?
      - x
      - 2
      + 2x
      # explain: d/dx x^n = n x^(n-1)

      Q2 (tf)
      The derivative of sin(x) is cos(x).
      = true

      Q3 (open)
      State the integral of 1/x dx.
      = ln|x| + C || log(x) + C

Rules: questions start with `Q<n> (<type>)` where type is mc / tf / open.
mc: `- ` wrong choices, `+ ` correct choices (several + allowed). tf/open:
`= ` the answer; open answers accept alternatives separated by `||` and
are compared ignoring case and whitespace. Optional `# explain:` line per
question. Images are not allowed anywhere in tests.

Timed taking is client-side (the timer starts when you open the test); the
server grades and stores your best result per test. Retakes overwrite.

Calendar
--------
Everyone can add events (title, markdown description, start/end, optional
space link). On creation every other user gets a notification; reminders
are sent the day before and the hour before to attendees (or everyone if
nobody has RSVP'd). Past events are dropped automatically.

Chats
-----
Private 1:1 conversations and named groups. Markdown, $math$ and !£ chat
colors work. Unread badges per conversation, live polling every 10 s.
Groups: any member can add members; anyone can leave; only the creator
can delete the group. DMs are unique per pair and disappear when either
side closes them.

Leaderboard
-----------
Two rankings, computed from everything on the instance:
creators = spaces + tests created; solvers = distinct tests completed
(desc), then total best time (asc). Data is rebuilt automatically when
tests are deleted.

Heaven Hotel (my room)
----------------------
Every user gets a room with a unique id, a name and a tagline that
everyone can see (rooms are fully public). The room holds:

      pomodoro     focus/break timer with a beep and session counting
      find         fuzzy search over notes, tests, posts, comments, YOUR
                   chat messages, events, rooms and profiles - every hit
                   links to its page and shows a snippet
      flashcards   .txt importable (same idea as tests: download the
                   template, ask an AI, paste the result) with flip,
                   shuffle, known-marking
      to-do        multiple lists with checkboxes
      graph        plot f(x) expressions (sin/cos/sqrt/log/^/…), zoom
      post-its     draggable, colorable, saved where you leave them
      annotate     text editor with bold/italic/code/highlight (==x==)
                   marks and a live preview

Widget state saves on change; visitors see everything but cannot edit.

Updating (update.sh)
--------------------
      sudo bash update.sh

Asks for your repo URL, makes a full recovery copy (code + data) AND a
separate data-only copy into /root/backups/uniheaven, clones the repo
and runs install.sh. Data is preserved. Add --branch <name> or --dry-run.

Limits & safety
---------------
      - 1 MB per note, disk guard at ~9.5 GB (your 10 GB VPS)
      - login rate limit (8 tries / 10 min per user+IP)
      - registration rate limit (5 per hour per IP; UNI_REGISTER_MAX/WINDOW)
      - optional account cap: UNI_MAX_USERS env var
      - imports: max 50 MB zip / 500 files / 64 MB unzipped; bad entry paths
        (absolute, .., backslash) abort the whole import
      - tests: max 200 questions, no images (rejected on create and import),
        one stored result per user per test (retakes overwrite)
      - events: start time within 10 years, dropped 2 days after they pass
      - chats: 4000 chars per message, max 50 members, 5000 messages kept
      - rooms: 10 to-do lists / 200 items, 50 post-its, 20 notes, 10 decks /
        500 cards; find returns at most 60 results and never crosses
        visibility boundaries (private spaces, private tests, other people's
        chats are excluded)
      - note paths and branch names sanitized against traversal
      - space names limited to a safe character set (no header injection)
      - private spaces: only owner, collaborators and viewers can see them;
        the public activity feed redacts private-space details
      - passwords: pbkdf2-hmac-sha256, 120k rounds, per-user salt
      - admin panel password: random per install (data/admin_creds.json),
        printed once to the journal; override with UNI_ADMIN_PASSWORD
      - profile logos: PNG data URLs only, max 30 KB

Testing
-------
See web/tsconfig.json for the frontend build (needs `npm i typescript`,
then `npx tsc -p web`). Recompile after editing web/src/ and commit
web/out/ so the VPS stays Node-free.

Server API tests (56 checks: auth, rate limits, traversal, restore,
import, viewers, regression):

      rm -rf /tmp/unitest && UNI_REGISTER_MAX=7 python3 server.py \
          --port 8077 --datadir /tmp/unitest --host 127.0.0.1 &
      python3 tests/e2e.py

New-feature tests (64 checks: tests/txt-import/grading, events/reminders,
chats, leaderboard):

      rm -rf /tmp/unitest && UNI_REGISTER_MAX=100 UNI_WATCH_INTERVAL=1 \
          python3 server.py --port 8077 --datadir /tmp/unitest --host 127.0.0.1 &
      python3 tests/e2e_new.py

Rooms / finder / admin-stats / security tests (36 checks):

      rm -rf /tmp/unitest && UNI_REGISTER_MAX=100 python3 server.py \
          --port 8077 --datadir /tmp/unitest --host 127.0.0.1 &
      python3 tests/e2e_rooms.py /tmp/opencode/uni.log

Streaks / forum-category tests (14 checks):

      rm -rf /tmp/unitest && UNI_REGISTER_MAX=100 python3 server.py \
          --port 8077 --datadir /tmp/unitest --host 127.0.0.1 &
      python3 tests/e2e_streak.py
