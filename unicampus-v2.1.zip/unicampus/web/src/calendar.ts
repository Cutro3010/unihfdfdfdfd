// Calendar page: month grid + upcoming list + day detail, event creation,
// rsvp and deletion. Everyone can add events; reminders come via the bell.

import {
  listEvents, createEvent, deleteEvent, toggleAttend, User,
} from "./api.js";
import { renderMarkdown, esc } from "./render.js";
import {
  initTheme, initBell, initUserArea, fmtTime, fmtDate, fmtDateTime, openModal,
} from "./common.js";

let user: User | null = null;
let events: any[] = [];
let cursor = new Date();
cursor.setDate(1);
cursor.setHours(0, 0, 0, 0);
let selectedDay: string | null = null;   // "YYYY-MM-DD"

const $ = (id: string) => document.getElementById(id)!;

function dayKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

async function boot(): Promise<void> {
  initTheme();
  initBell();
  user = await initUserArea();
  $("cal-prev").addEventListener("click", () => { cursor.setMonth(cursor.getMonth() - 1); renderCal(); });
  $("cal-next").addEventListener("click", () => { cursor.setMonth(cursor.getMonth() + 1); renderCal(); });
  $("cal-new").addEventListener("click", () => { void newEventModal(); });
  await reload();
}

async function reload(): Promise<void> {
  try {
    events = (await listEvents()).events;
  } catch {
    events = [];
  }
  renderCal();
  renderUpcoming();
}

function renderCal(): void {
  $("cal-title").textContent = cursor.toLocaleDateString(undefined,
    { month: "long", year: "numeric" });
  const grid = $("cal-grid");
  grid.innerHTML = "";
  const dows = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"];
  for (const d of dows) {
    const cell = document.createElement("div");
    cell.className = "cal-dow";
    cell.textContent = d;
    grid.appendChild(cell);
  }
  const first = new Date(cursor);
  const startDow = (first.getDay() + 6) % 7;            // monday-first
  const prevMonth = new Date(cursor);
  prevMonth.setMonth(prevMonth.getMonth() - 1);
  const dim = new Date(prevMonth.getFullYear(), prevMonth.getMonth() + 1, 0).getDate();
  const daysInMonth = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0).getDate();
  const todayKey = dayKey(new Date());

  const byDay = new Map<string, any[]>();
  for (const e of events) {
    const k = dayKey(new Date(e.start * 1000));
    if (!byDay.has(k)) byDay.set(k, []);
    byDay.get(k)!.push(e);
  }

  const total = 42;
  for (let i = 0; i < total; i++) {
    const cell = document.createElement("div");
    cell.className = "cal-day";
    let dayNum: number;
    let key: string;
    if (i < startDow) {
      dayNum = dim - startDow + 1 + i;
      key = dayKey(new Date(prevMonth.getFullYear(), prevMonth.getMonth(), dayNum));
      cell.classList.add("other");
    } else if (i < startDow + daysInMonth) {
      dayNum = i - startDow + 1;
      key = dayKey(new Date(cursor.getFullYear(), cursor.getMonth(), dayNum));
    } else {
      dayNum = i - startDow - daysInMonth + 1;
      key = dayKey(new Date(cursor.getFullYear(), cursor.getMonth() + 1, dayNum));
      cell.classList.add("other");
    }
    if (key === todayKey) cell.classList.add("today");
    if (key === selectedDay) cell.classList.add("selected");
    const num = document.createElement("span");
    num.className = "dnum";
    num.textContent = String(dayNum);
    cell.appendChild(num);
    const dayEvents = byDay.get(key) || [];
    for (const _e of dayEvents.slice(0, 3)) {
      const dot = document.createElement("span");
      dot.className = "cal-dot";
      cell.appendChild(dot);
    }
    if (dayEvents.length > 3) {
      const more = document.createElement("span");
      more.className = "faint xs";
      more.textContent = "+" + (dayEvents.length - 3);
      cell.appendChild(more);
    }
    cell.addEventListener("click", () => {
      selectedDay = selectedDay === key ? null : key;
      renderCal();
      renderDayPanel();
    });
    grid.appendChild(cell);
  }
  renderDayPanel();
}

function eventItem(e: any, showDay: boolean): HTMLElement {
  const item = document.createElement("div");
  item.className = "event-item";
  const when = document.createElement("span");
  when.className = "ev-when";
  when.textContent = showDay ? fmtDateTime(e.start) : fmtDate(e.start);
  item.appendChild(when);
  const body = document.createElement("div");
  body.className = "ev-body";
  const title = document.createElement("div");
  title.className = "ev-title";
  title.textContent = e.title;
  body.appendChild(title);
  const by = document.createElement("span");
  by.className = "faint xs mono";
  by.textContent = " by @" + e.owner
    + (e.end ? " · until " + new Date(e.end * 1000).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" }) : "");
  body.appendChild(by);
  if (e.description) {
    const desc = document.createElement("div");
    desc.className = "note-body small mt1";
    desc.innerHTML = renderMarkdown(e.description);
    body.appendChild(desc);
  }
  if (e.space) {
    const link = document.createElement("a");
    link.className = "small";
    link.href = "/space.html?id=" + encodeURIComponent(e.space);
    link.textContent = "open the space";
    body.append(document.createTextNode(" "), link);
  }
  item.appendChild(body);
  const actions = document.createElement("div");
  const att = document.createElement("button");
  att.className = "btn small" + (e.attending ? " active" : "");
  att.textContent = (e.attending ? "going ✓ " : "going ") + e.attendee_count;
  att.addEventListener("click", () => {
    toggleAttend(e.id).then((d) => {
      e.attending = d.attending;
      e.attendee_count = d.attendee_count;
      renderCal();
      renderUpcoming();
    }).catch(() => { /* ignore */ });
  });
  actions.appendChild(att);
  if (user && (e.owner === user.username || user.admin)) {
    const del = document.createElement("button");
    del.className = "btn small danger";
    del.textContent = "delete";
    del.addEventListener("click", () => {
      if (!window.confirm(`delete event "${e.title}"?`)) return;
      deleteEvent(e.id).then(reload).catch((err) => alert((err as Error).message));
    });
    actions.appendChild(del);
  }
  item.appendChild(actions);
  return item;
}

function renderUpcoming(): void {
  const box = $("cal-upcoming");
  box.innerHTML = "";
  const nowTs = Date.now() / 1000;
  const upcoming = events.filter((e) => e.start > nowTs - 3600)
    .sort((a, b) => a.start - b.start).slice(0, 10);
  if (!upcoming.length) {
    box.innerHTML = '<div class="dim">no upcoming events — add one.</div>';
    return;
  }
  for (const e of upcoming) box.appendChild(eventItem(e, true));
}

function renderDayPanel(): void {
  const panel = $("cal-day-panel");
  const box = $("cal-day-events");
  box.innerHTML = "";
  if (!selectedDay) { panel.classList.add("hidden"); return; }
  panel.classList.remove("hidden");
  $("cal-day-title").textContent = "events on " + selectedDay;
  const dayEvents = events.filter((e) => dayKey(new Date(e.start * 1000)) === selectedDay)
    .sort((a, b) => a.start - b.start);
  if (!dayEvents.length) {
    box.innerHTML = '<div class="dim">nothing on this day.</div>';
    return;
  }
  for (const e of dayEvents) box.appendChild(eventItem(e, true));
}

function newEventModal(): void {
  if (!user) { alert("login first"); return; }
  const { root, close } = openModal(`
    <h2>new event</h2>
    <label class="field"><span class="lbl">title</span>
      <input type="text" id="ev-title"></label>
    <label class="field"><span class="lbl">description (markdown, optional)</span>
      <textarea id="ev-desc" rows="3" spellcheck="false"></textarea></label>
    <div class="row">
      <label class="field grow"><span class="lbl">starts</span>
        <input type="datetime-local" id="ev-start"></label>
      <label class="field grow"><span class="lbl">ends (optional)</span>
        <input type="datetime-local" id="ev-end"></label>
    </div>
    <label class="field"><span class="lbl">space link (space id, optional)</span>
      <input type="text" id="ev-space" placeholder="e.g. 58da8eb6"></label>
    <div class="error-box hidden" id="ev-error"></div>
    <div class="actions">
      <button class="btn" id="ev-cancel">cancel</button>
      <button class="btn primary" id="ev-go">add</button>
    </div>`);
  const start = root.querySelector("#ev-start") as HTMLInputElement;
  start.value = new Date(Date.now() + 3600 * 1000).toISOString().slice(0, 16);
  root.querySelector("#ev-cancel")!.addEventListener("click", close);
  root.querySelector("#ev-go")!.addEventListener("click", async () => {
    const title = (root.querySelector("#ev-title") as HTMLInputElement).value.trim();
    const startVal = start.value;
    if (!title || !startVal) {
      const b = root.querySelector("#ev-error") as HTMLElement;
      b.textContent = "title and start time are required";
      b.classList.remove("hidden");
      return;
    }
    const endVal = (root.querySelector("#ev-end") as HTMLInputElement).value;
    try {
      await createEvent({
        title,
        description: (root.querySelector("#ev-desc") as HTMLTextAreaElement).value.trim(),
        start: new Date(startVal).getTime() / 1000,
        end: endVal ? new Date(endVal).getTime() / 1000 : null,
        space: (root.querySelector("#ev-space") as HTMLInputElement).value.trim(),
      });
      close();
      await reload();
    } catch (e) {
      const b = root.querySelector("#ev-error") as HTMLElement;
      b.textContent = (e as Error).message;
      b.classList.remove("hidden");
    }
  });
}

boot();
