// Minimal markdown renderer for Uniheaven.
// Supports: headings, bold, italic, inline code, fenced code blocks,
// links, blockquotes, ordered/unordered lists, images, $...$ and $$...$$
// LaTeX math via the globally loaded KaTeX (self-hosted).
// Everything is HTML-escaped first; math/code are stashed and re-inserted
// as trusted HTML only after rendering.
//
// Chat colors (posts and comments): a line starting with "!£" gets a color
// until the end of the line.
//   !£01..!£09 normal   !£11..!£19 dark   !£21..!£29 light
//   !£00 rainbow        !£30 warm white
//   adding "m" makes it monospace: "!£m30" or "!£30m"
// Colors render when renderMarkdown(src, {colors:true}) is used.

declare const katex: any;

export function esc(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

const PH = (i: number) => `\u0000${i}\u0000`;

function listify(h: string): string {
  const out: string[] = [];
  let cur: string[] = [];
  let kind = "";
  const flush = () => {
    if (cur.length) {
      out.push(`<${kind}>` + cur.map((li) => `<li>${li}</li>`).join("") + `</${kind}>`);
      cur = [];
      kind = "";
    }
  };
  for (const line of h.split("\n")) {
    const ul = line.match(/^\s*[-*]\s+(.*)$/);
    const ol = line.match(/^\s*\d+\.\s+(.*)$/);
    if (ul) {
      if (kind !== "ul") { flush(); kind = "ul"; }
      cur.push(ul[1]);
    } else if (ol) {
      if (kind !== "ol") { flush(); kind = "ol"; }
      cur.push(ol[1]);
    } else {
      flush();
      out.push(line);
    }
  }
  flush();
  return out.join("\n");
}

export interface RenderOpts { colors?: boolean; noImages?: boolean }

const CC_CODES = new Set([
  "00",
  "01", "02", "03", "04", "05", "06", "07", "08", "09",
  "11", "12", "13", "14", "15", "16", "17", "18", "19",
  "21", "22", "23", "24", "25", "26", "27", "28", "29",
  "30",
]);

export function renderMarkdown(src: string, opts: RenderOpts = {}): string {
  const stash: string[] = [];
  const push = (html: string) => { stash.push(html); return PH(stash.length - 1); };
  let h = src;

  // 1. fenced code blocks (before everything else)
  h = h.replace(/```([\s\S]*?)```/g, (_, code: string) => {
    const c = code.replace(/^\n|\n\s*$/g, "");
    return push(`<pre><code>${esc(c)}</code></pre>`);
  });

  // 2. display math $$...$$
  h = h.replace(/\$\$([\s\S]+?)\$\$/g, (_, tex: string) => {
    try {
      return push(katex.renderToString(tex.trim(), { displayMode: true, throwOnError: false }));
    } catch {
      return push(`<pre><code>${esc(tex)}</code></pre>`);
    }
  });

  // 3. inline math $...$
  h = h.replace(/\$([^\$\n]+?)\$/g, (_, tex: string) => {
    try {
      return push(katex.renderToString(tex.trim(), { displayMode: false, throwOnError: false }));
    } catch {
      return push(`<code>${esc(tex)}</code>`);
    }
  });

  // 3b. chat colors: !£XX / !£mXX / !£XXm at the start of a line
  if (opts.colors) {
    h = h.split("\n").map((line) => {
      const m = line.match(/^!£(m)?(\d{2})(m)?/);
      if (!m) return line;
      const code = m[2];
      if (!CC_CODES.has(code)) return line;
      const mono = !!(m[1] || m[3]);
      const rest = line.slice(m[0].length);
      return push(`<span class="cc c${code}${mono ? " cm" : ""}">`)
        + rest + push("</span>");
    }).join("\n");
  }

  // 4. escape all remaining text
  h = esc(h);

  // 5. inline syntax (after escaping)
  if (!opts.noImages) {
    h = h.replace(/!\[([^\]]*)\]\((https?:[^)\s]+)\)/g,
      (_m, t: string, u: string) => `<img src="${u}" alt="${t}">`);
  }
  h = h.replace(/\[([^\]]+)\]\((https?:[^)\s]+)\)/g,
    (_m, t: string, u: string) => `<a href="${u}" target="_blank" rel="noopener noreferrer">${t}</a>`);
  h = h.replace(/\*\*([^*\n]+)\*\*/g, "<strong>$1</strong>");
  h = h.replace(/(^|[^*])\*([^*\n]+)\*/g, "$1<em>$2</em>");
  h = h.replace(/==([^=\n]+)==/g, "<mark>$1</mark>");
  h = h.replace(/~~([^~\n]+)~~/g, "<del>$1</del>");
  h = h.replace(/`([^`\n]+)`/g, "<code>$1</code>");

  // 6. block syntax
  h = h.replace(/^######\s+(.+)$/gm, "<h4>$1</h4>");
  h = h.replace(/^#####\s+(.+)$/gm, "<h4>$1</h4>");
  h = h.replace(/^####\s+(.+)$/gm, "<h4>$1</h4>");
  h = h.replace(/^###\s+(.+)$/gm, "<h3>$1</h3>");
  h = h.replace(/^##\s+(.+)$/gm, "<h2>$1</h2>");
  h = h.replace(/^#\s+(.+)$/gm, "<h1>$1</h1>");
  h = h.replace(/^\s*&gt;\s?(.*)$/gm, "<blockquote>$1</blockquote>");
  h = h.replace(/^---+$/gm, "<hr>");
  h = listify(h);

  // 7. paragraphs
  h = h.split(/\n{2,}/).map((block) => {
    const b = block.trim();
    if (/^<(h\d|ul|ol|pre|blockquote|hr|p)\b/.test(b)) return b;
    if (b === "") return "";
    return `<p>${block.replace(/\n/g, "<br>")}</p>`;
  }).join("\n");

  // 8. restore stashed trusted HTML
  h = h.replace(/\u0000(\d+)\u0000/g, (_m, i: string) => stash[+i] ?? "");

  return h;
}
