// Home page: auth, spaces grid, tag cloud, activity feed, search.

import {
  api, setToken, listSpaces, searchAll, allTags, activity,
  starSpace, getPosts, postPost, deletePost, votePost, getDeadlines, getReading,
  listEvents, listTests,
  Space, User,
} from "./api.js";
import { renderMarkdown, esc } from "./render.js";
import {
  initTheme, initBell, initUserArea, fmtTime, fmtDateTime, openModal,
  wireMentionAutocomplete, dueState, dueLabel,
} from "./common.js";

let user: User | null = null;

// ---------------- auth ----------------
function showAuth(): void {
  document.getElementById("auth-panel")!.classList.remove("hidden");
}
function hideAuth(): void {
  document.getElementById("auth-panel")!.classList.add("hidden");
}

function authError(msg: string): void {
  const box = document.getElementById("auth-error")!;
  box.textContent = msg;
  box.classList.remove("hidden");
}

function wireAuth(): void {
  document.getElementById("login-btn")!.addEventListener("click", async () => {
    const username = (document.getElementById("login-user") as HTMLInputElement).value.trim();
    const password = (document.getElementById("login-pass") as HTMLInputElement).value;
    try {
      const d = await api("login", { method: "POST", body: { username, password } });
      setToken(d.token);
      location.reload();
    } catch (e) {
      authError((e as Error).message);
    }
  });
  document.getElementById("reg-btn")!.addEventListener("click", async () => {
    const username = (document.getElementById("reg-user") as HTMLInputElement).value.trim();
    const display = (document.getElementById("reg-display") as HTMLInputElement).value.trim();
    const password = (document.getElementById("reg-pass") as HTMLInputElement).value;
    try {
      const d = await api("register", { method: "POST", body: { username, password, display_name: display } });
      setToken(d.token);
      location.reload();
    } catch (e) {
      authError((e as Error).message);
    }
  });
}

// ---------------- spaces ----------------
async function renderSpaces(tag?: string): Promise<void> {
  const grid = document.getElementById("space-grid")!;
  const title = document.getElementById("spaces-title")!;
  grid.innerHTML = "";
  let spaces: Space[];
  try {
    spaces = await listSpaces();
  } catch {
    grid.innerHTML = '<div class="dim">could not load spaces</div>';
    return;
  }
  const list = tag ? spaces.filter((s) => s.tags.includes(tag)) : spaces;
  title.textContent = tag ? `spaces · #${tag}` : "spaces";
  if (list.length === 0) {
    grid.innerHTML = '<div class="dim">no spaces yet — create one.</div>';
    return;
  }
  for (const s of list) {
    const card = document.createElement("div");
    card.className = "card";

    const head = document.createElement("div");
    head.className = "row";
    const t = document.createElement("a");
    t.className = "title grow";
    t.href = "/space.html?id=" + s.id;
    t.textContent = s.name;
    const star = document.createElement("button");
    star.className = "btn small" + (s.starred ? " active" : "");
    star.textContent = (s.starred ? "★ " : "☆ ") + s.star_count;
    star.title = "star / unstar";
    if (user) star.addEventListener("click", async (e) => {
      e.preventDefault();
      const on = !s.starred;
      try {
        const d = await starSpace(s.id, on);
        s.starred = on;
        s.star_count = d.star_count;
        renderSpaces();
      } catch { /* ignore */ }
    });
    head.append(t, star);
    card.appendChild(head);

    const owner = document.createElement("a");
    owner.className = "owner";
    owner.href = "/user.html?name=" + encodeURIComponent(s.owner);
    owner.textContent = "@" + s.owner + (s.forked_from ? ` · forked from @${s.forked_from.owner}` : "");
    card.appendChild(owner);

    if (s.description) {
      const desc = document.createElement("div");
      desc.className = "desc";
      desc.textContent = s.description;
      card.appendChild(desc);
    }

    const meta = document.createElement("div");
    meta.className = "meta-row";
    meta.textContent = `${Object.keys(s.branches).length} branch(es) · ${fmtTime(s.created)}`;
    card.appendChild(meta);

    if (s.tags.length) {
      const tags = document.createElement("div");
      for (const tg of s.tags) {
        const pill = document.createElement("span");
        pill.className = "tag";
        pill.textContent = "#" + tg;
        pill.addEventListener("click", () => renderSpaces(tg));
        tags.appendChild(pill);
      }
      card.appendChild(tags);
    }
    grid.appendChild(card);
  }
}

// ---------------- continue reading / deadlines ----------------
async function renderReading(): Promise<void> {
  const box = document.getElementById("reading")!;
  const section = document.getElementById("reading-section")!;
  box.innerHTML = "";
  let items: any[];
  try {
    items = (await getReading()).reading;
  } catch { return; }
  if (!items.length) return;
  section.classList.remove("hidden");
  for (const r of items.slice(0, 12)) {
    const row = document.createElement("div");
    row.className = "feed-item";
    const when = document.createElement("span");
    when.className = "when";
    when.textContent = fmtTime(r.time);
    const body = document.createElement("span");
    const link = document.createElement("a");
    link.href = `/space.html?id=${r.space}&path=${encodeURIComponent(r.path)}${r.anchor || ""}`;
    link.textContent = `▹ ${r.space_name} / ${r.path}`;
    body.appendChild(link);
    if (r.anchor) {
      const mark = document.createElement("span");
      mark.className = "faint xs mono";
      mark.textContent = " · thread";
      body.appendChild(mark);
    }
    row.append(when, body);
    box.appendChild(row);
  }
}

async function renderDeadlines(): Promise<void> {
  const box = document.getElementById("deadlines")!;
  const section = document.getElementById("deadlines-section")!;
  box.innerHTML = "";
  let items: any[];
  try {
    items = (await getDeadlines()).deadlines;
  } catch { return; }
  if (!items.length) return;
  section.classList.remove("hidden");
  const now = Date.now() / 1000;
  for (const d of items.slice(0, 10)) {
    const row = document.createElement("div");
    row.className = "feed-item";
    const badge = document.createElement("span");
    badge.className = "due " + dueState(d.due, now);
    badge.textContent = dueLabel(d.due, now);
    const body = document.createElement("span");
    const link = document.createElement("a");
    link.href = `/space.html?id=${d.space}&path=${encodeURIComponent(d.path)}`;
    link.textContent = `${d.space_name} / ${d.path}`;
    const date = document.createElement("span");
    date.className = "faint xs mono";
    date.textContent = " · " + new Date(d.due * 1000).toLocaleDateString();
    body.append(link, date);
    row.append(badge, body);
    box.appendChild(row);
  }
}

async function renderEvents(): Promise<void> {
  const box = document.getElementById("events")!;
  const section = document.getElementById("events-section")!;
  box.innerHTML = "";
  let items: any[];
  try {
    items = (await listEvents()).events;
  } catch { return; }
  const nowTs = Date.now() / 1000;
  items = items.filter((e) => e.start > nowTs - 3600).slice(0, 5);
  if (!items.length) return;
  section.classList.remove("hidden");
  for (const e of items) {
    const row = document.createElement("div");
    row.className = "feed-item";
    const when = document.createElement("span");
    when.className = "when";
    when.textContent = fmtDateTime(e.start);
    const body = document.createElement("span");
    const title = document.createElement("a");
    title.href = "/calendar.html";
    title.textContent = e.title;
    const by = document.createElement("span");
    by.className = "faint xs mono";
    by.textContent = " · by @" + e.owner + " · " + e.attendee_count + " going";
    body.append(title, by);
    row.append(when, body);
    box.appendChild(row);
  }
}

async function renderTests(): Promise<void> {
  const box = document.getElementById("tests")!;
  const section = document.getElementById("tests-section")!;
  box.innerHTML = "";
  let items: any[];
  try {
    items = (await listTests()).tests;
  } catch { return; }
  if (!items.length) return;
  section.classList.remove("hidden");
  for (const t of items.slice(0, 5)) {
    const row = document.createElement("div");
    row.className = "feed-item";
    const when = document.createElement("span");
    when.className = "when";
    when.textContent = fmtTime(t.created);
    const body = document.createElement("span");
    const link = document.createElement("a");
    link.href = "/tests.html";
    link.textContent = t.title;
    const meta = document.createElement("span");
    meta.className = "faint xs mono";
    meta.textContent = ` · @${t.owner} · ${t.n_questions} question(s)`
      + (t.subject ? ` · ${t.subject}` : "");
    body.append(link, meta);
    row.append(when, body);
    box.appendChild(row);
  }
}

// ---------------- tags / feed ----------------
async function renderTags(): Promise<void> {
  const cloud = document.getElementById("tag-cloud")!;
  cloud.innerHTML = "";
  let tags: Record<string, number>;
  try {
    tags = (await allTags()).tags;
  } catch { return; }
  const names = Object.keys(tags).sort((a, b) => tags[b] - tags[a]).slice(0, 30);
  if (!names.length) return;
  document.getElementById("tags-section")!.classList.remove("hidden");
  for (const t of names) {
    const pill = document.createElement("span");
    pill.className = "tag";
    pill.textContent = `#${t} (${tags[t]})`;
    pill.addEventListener("click", () => renderSpaces(t));
    cloud.appendChild(pill);
  }
}

const ACTION_WORDS: Record<string, string> = {
  create_space: "created space", edit_note: "edited", delete_note: "deleted",
  comment: "commented on", branch: "branched", merge: "merged",
  fork: "forked", register: "joined", post: "posted",
  create_test: "created test", submit_test: "completed test",
  create_event: "added event",
};

async function renderFeed(): Promise<void> {
  const feed = document.getElementById("feed")!;
  feed.innerHTML = "";
  let acts: any[];
  try {
    acts = (await activity()).activity;
  } catch { return; }
  if (!acts.length) return;
  document.getElementById("feed-section")!.classList.remove("hidden");
  for (const a of acts.slice(0, 30)) {
    const item = document.createElement("div");
    item.className = "feed-item";
    const when = document.createElement("span");
    when.className = "when";
    when.textContent = fmtTime(a.time);
    const body = document.createElement("span");
    const who = document.createElement("a");
    who.className = "who";
    who.href = "/user.html?name=" + encodeURIComponent(a.user);
    who.textContent = "@" + a.user;
    const what = document.createElement("span");
    what.className = "what";
    let txt = ACTION_WORDS[a.action] || a.action;
    if (a.space) {
      const link = document.createElement("a");
      link.href = "/space.html?id=" + a.space;
      link.textContent = a.space_name || a.space;
      txt += " ";
      what.append(document.createTextNode(txt));
      what.appendChild(link);
    } else {
      what.textContent = txt;
    }
    if (a.path) {
      what.append(document.createTextNode(" · " + a.path));
    }
    if (a.summary) {
      what.append(document.createTextNode(" — " + a.summary));
    }
    body.append(who, document.createTextNode(" "), what);
    item.append(when, body);
    feed.appendChild(item);
  }
}

// ---------------- search ----------------
async function doSearch(q: string): Promise<void> {
  const out = document.getElementById("search-out")!;
  const section = document.getElementById("search-results")!;
  section.classList.remove("hidden");
  out.innerHTML = '<div class="dim">searching…</div>';
  let d: any;
  try {
    d = await searchAll(q);
  } catch {
    out.innerHTML = '<div class="dim">search failed</div>';
    return;
  }
  out.innerHTML = "";
  if (!d.spaces.length && !d.notes.length) {
    out.innerHTML = '<div class="dim">no results for “' + esc(q) + '”</div>';
    return;
  }
  for (const s of d.spaces) {
    const a = document.createElement("a");
    a.className = "row mb1";
    a.href = "/space.html?id=" + s.id;
    a.textContent = `▸ ${s.name} (@${s.owner})${s.tags.map((t: string) => " #" + t).join("")}`;
    out.appendChild(a);
    out.appendChild(document.createElement("br"));
  }
  for (const n of d.notes) {
    const a = document.createElement("a");
    a.className = "row mb1";
    a.href = `/space.html?id=${n.space}&path=${encodeURIComponent(n.path)}`;
    a.textContent = `▹ ${n.space_name} / ${n.path}`;
    out.appendChild(a);
    out.appendChild(document.createElement("br"));
  }
}

// ---------------- new space ----------------
function wireNewSpace(): void {
  document.getElementById("new-space-btn")!.addEventListener("click", () => {
    const { root, close } = openModal(`
      <h2>new space</h2>
      <label class="field"><span class="lbl">name</span>
        <input type="text" id="ns-name"></label>
      <label class="field"><span class="lbl">description (optional)</span>
        <input type="text" id="ns-desc"></label>
      <label class="field"><span class="lbl">tags (comma separated)</span>
        <input type="text" id="ns-tags" placeholder="math, analysis"></label>
      <label class="row small"><input type="checkbox" id="ns-public" checked>
        <span>public (any logged-in user can view and comment)</span></label>
      <div class="error-box hidden" id="ns-error"></div>
      <div class="actions">
        <button class="btn" id="ns-cancel">cancel</button>
        <button class="btn primary" id="ns-create">create</button>
      </div>`);
    root.querySelector("#ns-cancel")!.addEventListener("click", close);
    root.querySelector("#ns-create")!.addEventListener("click", async () => {
      const name = (root.querySelector("#ns-name") as HTMLInputElement).value.trim();
      const desc = (root.querySelector("#ns-desc") as HTMLInputElement).value.trim();
      const tags = (root.querySelector("#ns-tags") as HTMLInputElement).value
        .split(",").map((t) => t.trim()).filter(Boolean);
      const isPublic = (root.querySelector("#ns-public") as HTMLInputElement).checked;
      try {
        const s = await api("spaces", { method: "POST", body: { name, description: desc, tags, public: isPublic } });
        location.href = "/space.html?id=" + s.id;
      } catch (e) {
        const box = root.querySelector("#ns-error") as HTMLElement;
        box.textContent = (e as Error).message;
        box.classList.remove("hidden");
      }
    });
  });
}

// ---------------- news (forum threads) ----------------
let replyingTo: string | null = null;
type SortMode = "hot" | "new" | "top";
let sortMode: SortMode = "hot";
let forumCats: string[] = [];
let activeCat: string | null = null;

function hotScore(score: number, time: number): number {
  const ageH = (Date.now() / 1000 - time) / 3600;
  return score / Math.pow(ageH + 2, 1.3);
}

function postCard(p: any, depth: number): HTMLElement {
  const isReply = depth > 0;
  const card = document.createElement("div");
  card.className = "post";
  const head = document.createElement("div");
  head.className = "p-head";
  const av = document.createElement(p.logo ? "img" : "div");
  av.className = p.logo ? "p-avatar" : "p-avatar-ph";
  if (p.logo) (av as HTMLImageElement).src = p.logo;
  else av.textContent = p.author[0].toUpperCase();
  const author = document.createElement("a");
  author.className = "p-author";
  author.href = "/user.html?name=" + encodeURIComponent(p.author);
  author.textContent = "@" + p.author;
  const when = document.createElement("span");
  when.className = "p-time";
  when.textContent = fmtTime(p.time) + (isReply ? " · reply" : "");
  head.append(av, author, when);
  if (!isReply && p.cat) {
    const cat = document.createElement("span");
    cat.className = "find-kind";
    cat.textContent = p.cat;
    head.appendChild(cat);
  }

  const body = document.createElement("div");
  body.className = "p-body";
  if (p.title) {
    const t = document.createElement("div");
    t.className = "p-title";
    t.textContent = p.title;
    body.appendChild(t);
  }
  const text = document.createElement("div");
  text.className = "p-text";
  text.innerHTML = renderMarkdown(p.text, { colors: true });
  body.appendChild(text);

  const actions = document.createElement("div");
  actions.className = "p-actions";
  const reply = document.createElement("button");
  reply.className = "btn small";
  reply.textContent = "reply";
  reply.addEventListener("click", () => {
    replyingTo = p.id;
    const ta = document.getElementById("post-ta") as HTMLTextAreaElement;
    ta.focus();
    document.getElementById("post-btn")!.textContent = "post reply";
  });
  actions.appendChild(reply);
  if (user && (p.author === user.username || user.admin)) {
    const del = document.createElement("button");
    del.className = "btn small danger";
    del.textContent = "delete";
    del.addEventListener("click", () => {
      deletePost(p.id).then(loadPosts).catch((e) => alert((e as Error).message));
    });
    actions.appendChild(del);
  }
  card.append(head, body, actions);
  return card;
}

function voteColumn(p: any): HTMLElement {
  const col = document.createElement("div");
  col.className = "vote";
  const up = document.createElement("button");
  up.type = "button";
  up.className = "v-up" + (p.my_vote === 1 ? " on" : "");
  up.textContent = "▲";
  up.title = "upvote";
  const score = document.createElement("span");
  score.className = "v-score";
  score.textContent = String(p.score || 0);
  const down = document.createElement("button");
  down.type = "button";
  down.className = "v-down" + (p.my_vote === -1 ? " on" : "");
  down.textContent = "▼";
  down.title = "downvote";
  const doVote = async (dir: number) => {
    if (!user) return;
    try {
      const d = await votePost(p.id, dir);
      p.score = d.score;
      p.my_vote = d.my_vote;
      score.textContent = String(p.score);
      up.classList.toggle("on", p.my_vote === 1);
      down.classList.toggle("on", p.my_vote === -1);
    } catch { /* ignore */ }
  };
  up.addEventListener("click", () => { void doVote(p.my_vote === 1 ? 0 : 1); });
  down.addEventListener("click", () => { void doVote(p.my_vote === -1 ? 0 : -1); });
  col.append(up, score, down);
  return col;
}

async function loadPosts(): Promise<void> {
  const box = document.getElementById("posts")!;
  const section = document.getElementById("news-section")!;
  box.innerHTML = "";
  let posts: any[];
  try {
    const d = await getPosts();
    posts = d.posts;
    forumCats = d.cats || forumCats;
  } catch {
    return;
  }
  renderForumCats();
  section.classList.remove("hidden");
  if (!posts.length) {
    box.innerHTML = '<div class="dim">nothing here yet — be the first to post.</div>';
    return;
  }
  const byId = new Map<string, any>(posts.map((p) => [p.id, p]));  const kidsOf = new Map<string, any[]>();
  const tops: any[] = [];
  for (const p of posts) {
    if (p.parent_id && byId.has(p.parent_id)) {
      if (!kidsOf.has(p.parent_id)) kidsOf.set(p.parent_id, []);
      kidsOf.get(p.parent_id)!.push(p);
    } else if (!activeCat || p.cat === activeCat) {
      tops.push(p);
    }
  }
  for (const arr of kidsOf.values()) arr.sort((a, b) => a.time - b.time);
  if (sortMode === "new") {
    tops.sort((a, b) => b.time - a.time);
  } else if (sortMode === "top") {
    tops.sort((a, b) => (b.score || 0) - (a.score || 0) || b.time - a.time);
  } else {
    tops.sort((a, b) => hotScore(b.score || 0, b.time) - hotScore(a.score || 0, a.time)
      || b.time - a.time);
  }

  const collapsed = new Set<string>();
  const renderThread = (p: any, parentEl: HTMLElement, depth: number): void => {
    const row = document.createElement("div");
    row.className = "post-row";
    row.append(voteColumn(p), postCard(p, depth));
    parentEl.appendChild(row);

    const kids = kidsOf.get(p.id) || [];
    if (kids.length) {
      const bar = document.createElement("div");
      bar.className = "p-actions mb1";
      const toggle = document.createElement("button");
      toggle.className = "btn small";
      toggle.textContent = "− thread";
      toggle.title = "collapse this thread";
      bar.appendChild(toggle);
      parentEl.appendChild(bar);
      const wrap = document.createElement("div");
      wrap.className = "thread-replies";
      toggle.addEventListener("click", () => {
        if (collapsed.has(p.id)) {
          collapsed.delete(p.id);
          toggle.textContent = "− thread";
        } else {
          collapsed.add(p.id);
          toggle.textContent = `+ ${kids.length} more`;
        }
        wrap.classList.toggle("hidden", collapsed.has(p.id));
      });
      for (const kid of kids) renderThread(kid, wrap, depth + 1);
      parentEl.appendChild(wrap);
    }
  };
  for (const t of tops) renderThread(t, box, 0);
}

function renderForumCats(): void {
  const box = document.getElementById("forum-cats");
  if (!box) return;
  box.innerHTML = "";
  const chips = ["all", ...forumCats];
  for (const c of chips) {
    const chip = document.createElement("button");
    chip.className = "tab" + ((c === "all" ? activeCat === null : activeCat === c) ? " active" : "");
    chip.textContent = c;
    chip.addEventListener("click", () => {
      activeCat = c === "all" ? null : c;
      void loadPosts();
    });
    box.appendChild(chip);
  }
}

function wirePosts(): void {
  const ta = document.getElementById("post-ta") as HTMLTextAreaElement;
  wireMentionAutocomplete(ta);
  document.getElementById("post-btn")!.addEventListener("click", () => {
    const text = ta.value.trim();
    if (!text) return;
    const title = (document.getElementById("post-title") as HTMLInputElement).value.trim();
    const cat = (document.getElementById("post-cat") as HTMLSelectElement).value;
    postPost(text, replyingTo, title, replyingTo ? undefined : cat)
      .then(() => {
        ta.value = "";
        replyingTo = null;
        (document.getElementById("post-title") as HTMLInputElement).value = "";
        document.getElementById("post-btn")!.textContent = "post";
        void loadPosts();
      })
      .catch((e) => alert((e as Error).message));
  });
  const sortSel = document.getElementById("news-sort") as HTMLSelectElement;
  sortSel.addEventListener("change", () => {
    sortMode = sortSel.value as SortMode;
    void loadPosts();
  });
}

// ---------------- boot ----------------
async function boot(): Promise<void> {
  initTheme();
  initBell();
  wireAuth();
  user = await initUserArea();

  if (!user) {
    showAuth();
  } else {
    hideAuth();
    document.getElementById("spaces-section")!.classList.remove("hidden");
    void renderReading();
    void renderDeadlines();
    void renderEvents();
    void renderTests();
  }
  const qtag = new URLSearchParams(location.search).get("tag");
  renderSpaces(qtag || undefined);
  renderTags();
  renderFeed();
  wirePosts();
  void loadPosts();

  const search = document.getElementById("search") as HTMLInputElement;
  search.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && search.value.trim()) {
      doSearch(search.value.trim());
    }
  });
  wireNewSpace();
}

// the little captions on the hero poster: two different random phrases per visit
const HERO_PHRASES = [
  "Peri loves you!",
  "qtra is probably tired",
  "need some studying, do ya?",
  "prima di gta 6",
  "doomscroll update un giorno arriverà",
];
function heroPhrases(): void {
  const a = Math.floor(Math.random() * HERO_PHRASES.length);
  const b = (a + 1 + Math.floor(Math.random() * (HERO_PHRASES.length - 1))) % HERO_PHRASES.length;
  const p1 = document.getElementById("hero-phrase");
  const p2 = document.getElementById("hero-phrase2");
  if (p1) p1.textContent = HERO_PHRASES[a];
  if (p2) p2.textContent = HERO_PHRASES[b];
}

boot();
heroPhrases();
