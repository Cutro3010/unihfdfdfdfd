// Chats page: private DMs and group chats with polling, unread badges,
// markdown + math rendering, member management.

import {
  listChats, createChat, getChatMessages, sendChatMessage, markChatRead,
  chatAddMember, chatLeave, chatDelete, User,
} from "./api.js";
import { renderMarkdown, esc } from "./render.js";
import {
  initTheme, initBell, initUserArea, fmtTime, openModal,
} from "./common.js";

let user: User | null = null;
let chats: any[] = [];
let activeId: string | null = null;
let activeChat: any = null;
let lastMsgId: string | null = null;

const $ = (id: string) => document.getElementById(id)!;

async function boot(): Promise<void> {
  initTheme();
  initBell();
  user = await initUserArea();
  if (!user) { $("ch-list").innerHTML = '<div class="dim">login first.</div>'; return; }
  $("ch-new").addEventListener("click", () => { void newChatModal(); });
  await loadChats();
  window.setInterval(poll, 5000);
}

async function loadChats(): Promise<void> {
  try {
    chats = (await listChats()).chats;
  } catch {
    chats = [];
  }
  if (activeId) {
    const fresh = chats.find((c) => c.id === activeId);
    if (fresh) {
      activeChat = fresh;              // refresh meta without rebuilding the thread
    } else {
      activeId = null;
      activeChat = null;
      renderThread();
    }
  }
  renderList();
  const total = chats.reduce((n: number, c: any) => n + (c.unread || 0), 0);
  document.title = (total ? `(${total}) ` : "") + "uniheaven · chats";
}

async function poll(): Promise<void> {
  await loadChats();
  if (activeId) {
    const hadNew = await loadMessages(false);
    if (hadNew) {
      // the thread is open: keep it marked as read
      markChatRead(activeId).then(() => loadChats()).catch(() => { /* ignore */ });
    }
  }
}

function renderList(): void {
  const box = $("ch-list");
  box.innerHTML = "";
  if (!chats.length) {
    box.innerHTML = '<div class="dim">no chats yet.</div>';
    return;
  }
  for (const c of chats) {
    const item = document.createElement("div");
    item.className = "chat-item" + (c.id === activeId ? " active" : "");
    const av = document.createElement("span");
    av.className = "ci-avatar";
    av.textContent = (c.type === "group" ? "☰" : (c.label.replace(/^@/, "")[0] || "?").toUpperCase());
    const main = document.createElement("div");
    main.className = "ci-main";
    const name = document.createElement("div");
    name.className = "ci-name";
    name.textContent = c.type === "group" ? c.name : c.label;
    const prev = document.createElement("div");
    prev.className = "ci-preview";
    prev.textContent = c.last ? `@${c.last.author}: ${c.last.text}` : "no messages yet";
    main.append(name, prev);
    item.append(av, main);
    if (c.unread > 0) {
      const badge = document.createElement("span");
      badge.className = "ci-badge";
      badge.textContent = String(c.unread);
      item.appendChild(badge);
    }
    item.addEventListener("click", () => { void openChat(c.id); });
    box.appendChild(item);
  }
}

function renderThread(): void {
  const thread = $("ch-thread");
  const empty = $("ch-empty");
  if (!activeId || !activeChat) {
    thread.innerHTML = "";
    thread.appendChild(empty);
    empty.classList.remove("hidden");
    return;
  }
  empty.classList.add("hidden");
  thread.innerHTML = "";
  const head = document.createElement("div");
  head.className = "row mb2";
  const title = document.createElement("span");
  title.className = "tc-title grow";
  title.textContent = activeChat.type === "group" ? activeChat.name : activeChat.label;
  const members = document.createElement("span");
  members.className = "chat-members";
  members.textContent = activeChat.members.map((m: string) => "@" + m).join(" ");
  head.append(title, members);
  const actions = document.createElement("div");
  if (activeChat.type === "group") {
    const add = document.createElement("button");
    add.className = "btn small";
    add.textContent = "add member";
    add.addEventListener("click", () => { void addMemberModal(); });
    actions.appendChild(add);
  }
  const leave = document.createElement("button");
  leave.className = "btn small";
  leave.textContent = activeChat.type === "group" ? "leave" : "close";
  leave.addEventListener("click", () => {
    if (!window.confirm(activeChat.type === "group" ? "leave this group?" : "close this conversation?")) return;
    chatLeave(activeId!).then(() => { activeId = null; activeChat = null; void loadChats(); })
      .catch((e) => alert((e as Error).message));
  });
  actions.appendChild(leave);
  if (activeChat.type === "group" && activeChat.created_by === user!.username) {
    const del = document.createElement("button");
    del.className = "btn small danger";
    del.textContent = "delete group";
    del.addEventListener("click", () => {
      if (!window.confirm("delete the group and its messages for everyone?")) return;
      chatDelete(activeId!).then(() => { activeId = null; activeChat = null; void loadChats(); })
        .catch((e) => alert((e as Error).message));
    });
    actions.appendChild(del);
  }
  head.appendChild(actions);
  thread.appendChild(head);

  const msgs = document.createElement("div");
  msgs.className = "chat-msgs";
  msgs.id = "ch-msgs";
  thread.appendChild(msgs);

  const form = document.createElement("div");
  form.className = "chat-form";
  const ta = document.createElement("textarea");
  ta.rows = 1;
  ta.placeholder = "message… $math$ and !£ colors work (enter to send)";
  const send = document.createElement("button");
  send.className = "btn primary";
  send.textContent = "send";
  send.addEventListener("click", () => { void doSend(ta); });
  ta.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      void doSend(ta);
    }
  });
  form.append(ta, send);
  thread.appendChild(form);
}

function renderMessages(msgs: any[], prepend: boolean): void {
  const box = $("ch-msgs");
  if (!box) return;
  const scrollToBottom = box.scrollTop + box.clientHeight >= box.scrollHeight - 60;
  for (const m of msgs) {
    if (box.dataset.have === m.id) continue;
    box.dataset.have = m.id;
    const msg = document.createElement("div");
    msg.className = "msg" + (m.author === user!.username ? " mine" : "");
    const bubble = document.createElement("div");
    bubble.className = "m-bubble";
    bubble.innerHTML = renderMarkdown(m.text, { colors: true });
    const meta = document.createElement("div");
    meta.className = "m-meta";
    meta.textContent = `${m.author} · ${fmtTime(m.time)}`;
    msg.append(bubble, meta);
    if (prepend) box.prepend(msg);
    else box.appendChild(msg);
  }
  if (scrollToBottom || !prepend) box.scrollTop = box.scrollHeight;
}

async function openChat(id: string): Promise<void> {
  activeId = id;
  const chat = chats.find((c) => c.id === id);
  activeChat = chat || null;
  lastMsgId = null;
  delete $("ch-msgs")?.dataset.have;
  renderList();
  renderThread();
  await loadMessages(true);
  markChatRead(id).then(() => loadChats()).catch(() => { /* ignore */ });
}

async function loadMessages(initial: boolean): Promise<boolean> {
  if (!activeId) return false;
  try {
    const d = await getChatMessages(activeId, initial ? undefined : (lastMsgId || undefined));
    if (d.messages.length) {
      lastMsgId = d.messages[d.messages.length - 1].id;
      renderMessages(d.messages, false);
      return true;
    }
  } catch { /* ignore */ }
  return false;
}

async function doSend(ta: HTMLTextAreaElement): Promise<void> {
  const text = ta.value.trim();
  if (!text || !activeId) return;
  try {
    await sendChatMessage(activeId, text);
    ta.value = "";
    await poll();
  } catch (e) {
    alert((e as Error).message);
  }
}

function newChatModal(): void {
  const { root, close } = openModal(`
    <h2>new chat</h2>
    <div class="tab-row">
      <button class="tab active" id="nc-tab-dm">private message</button>
      <button class="tab" id="nc-tab-group">group</button>
    </div>
    <div id="nc-dm">
      <label class="field"><span class="lbl">username</span>
        <input type="text" id="nc-user" placeholder="who to talk to"></label>
    </div>
    <div id="nc-group" class="hidden">
      <label class="field"><span class="lbl">group name</span>
        <input type="text" id="nc-name"></label>
      <label class="field"><span class="lbl">members (usernames, comma separated)</span>
        <input type="text" id="nc-members" placeholder="bob, carol"></label>
    </div>
    <div class="error-box hidden" id="nc-error"></div>
    <div class="actions">
      <button class="btn" id="nc-cancel">cancel</button>
      <button class="btn primary" id="nc-go">start</button>
    </div>`);
  const tabDm = root.querySelector("#nc-tab-dm") as HTMLElement;
  const tabGrp = root.querySelector("#nc-tab-group") as HTMLElement;
  const dmBox = root.querySelector("#nc-dm") as HTMLElement;
  const grpBox = root.querySelector("#nc-group") as HTMLElement;
  tabDm.addEventListener("click", () => {
    tabDm.classList.add("active"); tabGrp.classList.remove("active");
    dmBox.classList.remove("hidden"); grpBox.classList.add("hidden");
  });
  tabGrp.addEventListener("click", () => {
    tabGrp.classList.add("active"); tabDm.classList.remove("active");
    grpBox.classList.remove("hidden"); dmBox.classList.add("hidden");
  });
  const fail = (m: string) => {
    const b = root.querySelector("#nc-error") as HTMLElement;
    b.textContent = m;
    b.classList.remove("hidden");
  };
  root.querySelector("#nc-cancel")!.addEventListener("click", close);
  root.querySelector("#nc-go")!.addEventListener("click", async () => {
    try {
      let d: any;
      if (grpBox.classList.contains("hidden")) {
        d = await createChat({ type: "dm", members: [(root.querySelector("#nc-user") as HTMLInputElement).value.trim()] });
      } else {
        d = await createChat({
          type: "group",
          name: (root.querySelector("#nc-name") as HTMLInputElement).value.trim(),
          members: (root.querySelector("#nc-members") as HTMLInputElement).value
            .split(",").map((m) => m.trim()).filter(Boolean),
        });
      }
      close();
      await loadChats();
      await openChat(d.chat.id);
    } catch (e) {
      fail((e as Error).message);
    }
  });
}

function addMemberModal(): void {
  const { root, close } = openModal(`
    <h2>add member</h2>
    <label class="field"><span class="lbl">username</span>
      <input type="text" id="am-user"></label>
    <div class="error-box hidden" id="am-error"></div>
    <div class="actions">
      <button class="btn" id="am-cancel">cancel</button>
      <button class="btn primary" id="am-go">add</button>
    </div>`);
  root.querySelector("#am-cancel")!.addEventListener("click", close);
  root.querySelector("#am-go")!.addEventListener("click", async () => {
    const name = (root.querySelector("#am-user") as HTMLInputElement).value.trim();
    try {
      await chatAddMember(activeId!, name);
      close();
      await loadChats();
      activeChat = chats.find((c) => c.id === activeId) || activeChat;
      renderThread();
    } catch (e) {
      const b = root.querySelector("#am-error") as HTMLElement;
      b.textContent = (e as Error).message;
      b.classList.remove("hidden");
    }
  });
}

boot();
