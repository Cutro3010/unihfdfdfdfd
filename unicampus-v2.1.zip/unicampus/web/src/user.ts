// User profile page: about, 20x20 logo (pixel editor + photo upload),
// stats (spaces/notes/revisions/comments), top tags, top words, sparkline.

import { getProfile, putProfile, getStreak, arcSlug, User } from "./api.js";
import { renderMarkdown, esc } from "./render.js";
import { initTheme, initBell, initUserArea, fmtTime, openModal } from "./common.js";

const qp = new URLSearchParams(location.search);
const name = qp.get("name") || "";

let profile: { about: string; logo: string };
let arcana: string[] = [];
let stats: any;
let isYou = false;
let me: User | null = null;

const $ = (id: string) => document.getElementById(id)!;

const ACTION_WORDS: Record<string, string> = {
  create_space: "created space", edit_note: "edited", delete_note: "deleted",
  comment: "commented on", branch: "branched", merge: "merged",
  fork: "forked", register: "joined",
  create_test: "created test", submit_test: "completed test",
  create_event: "added event",
};

// ---------------- boot ----------------
async function boot(): Promise<void> {
  initTheme();
  initBell();
  me = await initUserArea();
  if (!name) {
    if (me) location.href = "/user.html?name=" + encodeURIComponent(me.username);
    else location.href = "/";
    return;
  }
  let d: any;
  try {
    d = await getProfile(name);
  } catch (e) {
    $("main").innerHTML =
      `<div class="error-box">${esc((e as Error).message)}</div>`;
    return;
  }
  profile = d.profile;
  arcana = d.arcana || [];
  stats = d.stats;
  isYou = d.is_you;
  document.title = "uniheaven · @" + d.user.username;
  $("user-title").textContent = "@" + d.user.username;
  renderAll(d.user);
  void renderStreak(d.user.username);
  if (isYou) {
    const btn = $("edit-profile-btn");
    btn.classList.remove("hidden");
    btn.addEventListener("click", editModal);
  }
}

// ---------------- rendering ----------------
function renderAll(u: any): void {
  // avatar
  const slot = $("avatar-slot");
  slot.innerHTML = "";
  if (profile.logo) {
    const img = document.createElement("img");
    img.className = "avatar";
    img.src = profile.logo;
    img.alt = "logo";
    slot.appendChild(img);
  } else {
    const ph = document.createElement("div");
    ph.className = "avatar-placeholder";
    ph.textContent = u.username[0].toUpperCase();
    slot.appendChild(ph);
  }

  $("p-name").textContent = "@" + u.username +
    (u.display_name ? " · " + u.display_name : "");
  $("p-meta").textContent =
    `joined ${fmtTime(u.created)}` + (u.admin ? " · admin" : "");

  // arcana (given by the admin, max two)
  const prevArc = document.getElementById("p-arcana");
  if (prevArc) prevArc.remove();
  const arcRow = document.createElement("div");
  arcRow.id = "p-arcana";
  arcRow.className = "arcana mt1";
  const arcLbl = document.createElement("span");
  arcLbl.className = "arcana-lbl";
  arcLbl.textContent = "Arcana: ";
  arcRow.appendChild(arcLbl);
  if (!arcana.length) {
    const none = document.createElement("span");
    none.className = "arcana-none";
    none.textContent = "—";
    arcRow.appendChild(none);
  } else {
    for (const a of arcana) {
      const pill = document.createElement("span");
      pill.className = "arc " + arcSlug(a);
      pill.textContent = a.toLowerCase();
      pill.title = a;
      arcRow.appendChild(pill);
    }
  }
  $("p-meta").after(arcRow);

  $("profile-head").classList.remove("hidden");

  // about
  if (profile.about) {
    $("about-text").innerHTML = renderMarkdown(profile.about);
    $("about-panel").classList.remove("hidden");
  }

  // stats
  const statDefs: Array<[string, number]> = [
    ["spaces", stats.spaces],
    ["notes", stats.notes],
    ["revisions", stats.revisions],
    ["comments", stats.comments],
    ["stars given", stats.stars_given],
  ];
  const grid = $("stat-grid");
  for (const [label, n] of statDefs) {
    const cell = document.createElement("div");
    cell.className = "stat";
    const num = document.createElement("div");
    num.className = "n";
    num.textContent = String(n);
    const lab = document.createElement("div");
    lab.className = "l";
    lab.textContent = label;
    cell.append(num, lab);
    grid.appendChild(cell);
  }
  $("stats-panel").classList.remove("hidden");

  // tags
  if (stats.tags.length) {
    const pills = $("tag-pills");
    for (const [t, c] of stats.tags) {
      const pill = document.createElement("span");
      pill.className = "tag";
      pill.textContent = `#${t} (${c})`;
      pill.addEventListener("click", () => { location.href = "/?tag=" + encodeURIComponent(t); });
      pills.appendChild(pill);
    }
    $("tags-panel").classList.remove("hidden");
  }

  // word cloud: 5 size buckets by rank
  if (stats.words.length) {
    const cloud = $("word-cloud");
    const words: Array<[string, number]> = stats.words;
    words.forEach(([w, c], i) => {
      const span = document.createElement("span");
      span.className = "wc wc-" + Math.min(5, 1 + Math.floor((i / words.length) * 5));
      span.textContent = w + " " + c;
      cloud.appendChild(span);
    });
    $("words-panel").classList.remove("hidden");
  }

  // sparkline
  const spark = $("spark");
  for (const d of stats.sparkline) {
    const bar = document.createElement("div");
    const b = d.count === 0 ? "" : d.count === 1 ? " b1" : d.count < 4 ? " b2" : " b3";
    bar.className = "bar" + b;
    bar.title = d.day + ": " + d.count;
    spark.appendChild(bar);
  }
  $("spark-panel").classList.remove("hidden");

  // recent activity
  const recent = $("recent");
  if (stats.recent.length) {
    for (const a of stats.recent) {
      const item = document.createElement("div");
      item.className = "feed-item";
      const when = document.createElement("span");
      when.className = "when";
      when.textContent = fmtTime(a.time);
      const body = document.createElement("span");
      const what = document.createElement("span");
      what.className = "what";
      let txt = ACTION_WORDS[a.action] || a.action;
      what.append(document.createTextNode(txt));
      if (a.space) {
        const link = document.createElement("a");
        link.href = "/space.html?id=" + a.space;
        link.textContent = " " + (a.space_name || a.space);
        what.appendChild(link);
      }
      if (a.path) what.append(document.createTextNode(" · " + a.path));
      body.appendChild(what);
      item.append(when, body);
      recent.appendChild(item);
    }
    $("recent-panel").classList.remove("hidden");
  }
}

// ---------------- streak ----------------
async function renderStreak(name: string): Promise<void> {
  let d: any;
  try {
    d = await getStreak(name);
  } catch {
    return;
  }
  const s = d.stats;
  const box = $("streak-box");
  box.innerHTML = "";
  const big = document.createElement("span");
  big.className = "n";
  big.style.color = "var(--accent)";
  big.style.marginRight = "8px";
  big.textContent = String(s.streak);
  const lab = document.createElement("span");
  lab.className = "dim small";
  lab.textContent = `day streak · best ${s.best} · ${s.exercises} exercise(s) solved · `
    + `${Math.round(s.studied / 3600)}h ${Math.round((s.studied % 3600) / 60)}m studied`;
  const bars = document.createElement("div");
  bars.className = "row mt2";
  bars.style.gap = "3px";
  bars.style.alignItems = "flex-end";
  for (const day of s.last7) {
    const col = document.createElement("div");
    col.style.flex = "1";
    col.style.display = "flex";
    col.style.flexDirection = "column";
    col.style.alignItems = "center";
    const v = Math.max(day.e, Math.round(day.s / 900));
    const bar = document.createElement("div");
    bar.style.width = "100%";
    bar.style.height = Math.max(3, v * 8) + "px";
    bar.style.background = v ? "var(--accent)" : "var(--border)";
    bar.style.borderRadius = "2px";
    bar.title = day.day + " · " + day.e + " exercise(s) · " + Math.round(day.s / 60) + " min";
    const lbl = document.createElement("span");
    lbl.className = "faint";
    lbl.style.fontSize = "9px";
    lbl.textContent = day.day.slice(5);
    col.append(bar, lbl);
    bars.appendChild(col);
  }
  box.append(big, lab, bars);
  $("streak-panel").classList.remove("hidden");
}

// ---------------- logo editor ----------------
const COLORS = ["#4da3ff", "#3fb950", "#f85149", "#d29922",
                "#e6edf3", "#8b98a5", "#161b22", "#ff66cc"];

function editModal(): void {
  const { root, close } = openModal(`
    <h2>edit profile</h2>
    <label class="field"><span class="lbl">about (markdown + $math$ ok)</span>
      <textarea id="pf-about" rows="5">${esc(profile.about || "")}</textarea></label>
    <div class="micro mb1">logo · 20x20 px</div>
    <div class="pix-editor">
      <canvas id="pf-canvas" class="pix-canvas" width="200" height="200"></canvas>
      <div>
        <div class="pix-palette" id="pf-palette"></div>
        <div class="row mt2">
          <button class="btn small" id="pf-clear" type="button">clear</button>
          <label class="btn small">upload photo<input type="file" id="pf-upload" accept="image/*" class="hidden"></label>
        </div>
      </div>
    </div>
    <div class="error-box hidden" id="pf-error"></div>
    <div class="actions">
      <button class="btn" id="pf-cancel">cancel</button>
      <button class="btn primary" id="pf-save">save</button>
    </div>`);
  const canvas = root.querySelector("#pf-canvas") as HTMLCanvasElement;
  const ctx = canvas.getContext("2d")!;
  let color: string | null = COLORS[0];

  if (profile.logo) {
    const img = new Image();
    img.onload = () => { ctx.drawImage(img, 0, 0, 200, 200); };
    img.src = profile.logo;
  }

  // palette
  const pal = root.querySelector("#pf-palette")!;
  const select = (swatch: HTMLElement, c: string | null) => {
    color = c;
    pal.querySelectorAll(".pix-swatch").forEach((s) => s.classList.remove("active"));
    swatch.classList.add("active");
  };
  for (const c of COLORS) {
    const s = document.createElement("button");
    s.type = "button";
    s.className = "pix-swatch";
    s.style.setProperty("--swatch", c);
    s.addEventListener("click", () => select(s, c));
    pal.appendChild(s);
    if (c === COLORS[0]) select(s, c);
  }
  const eraser = document.createElement("button");
  eraser.type = "button";
  eraser.className = "pix-swatch erase";
  eraser.textContent = "x";
  eraser.addEventListener("click", () => select(eraser, null));
  pal.appendChild(eraser);

  // painting (mouse + touch-ish drag)
  let painting = false;
  const paintAt = (e: MouseEvent) => {
    const r = canvas.getBoundingClientRect();
    const x = Math.floor(((e.clientX - r.left) / r.width) * 20);
    const y = Math.floor(((e.clientY - r.top) / r.height) * 20);
    if (x < 0 || x > 19 || y < 0 || y > 19) return;
    if (color === null) ctx.clearRect(x * 10, y * 10, 10, 10);
    else { ctx.fillStyle = color; ctx.fillRect(x * 10, y * 10, 10, 10); }
  };
  canvas.addEventListener("mousedown", (e) => { painting = true; paintAt(e); });
  canvas.addEventListener("mousemove", (e) => { if (painting) paintAt(e); });
  canvas.addEventListener("mouseup", () => { painting = false; });
  canvas.addEventListener("mouseleave", () => { painting = false; });

  root.querySelector("#pf-clear")!.addEventListener("click", () => {
    ctx.clearRect(0, 0, 200, 200);
  });

  // photo upload -> downscale to 20x20
  const up = root.querySelector("#pf-upload") as HTMLInputElement;
  up.addEventListener("change", () => {
    const f = up.files && up.files[0];
    if (!f) return;
    const img = new Image();
    img.onload = () => {
      const small = document.createElement("canvas");
      small.width = 20;
      small.height = 20;
      const sctx = small.getContext("2d")!;
      sctx.drawImage(img, 0, 0, 20, 20);
      ctx.clearRect(0, 0, 200, 200);
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(small, 0, 0, 200, 200);
    };
    img.src = URL.createObjectURL(f);
  });

  root.querySelector("#pf-cancel")!.addEventListener("click", close);
  root.querySelector("#pf-save")!.addEventListener("click", () => {
    const about = (root.querySelector("#pf-about") as HTMLTextAreaElement).value.trim();
    const small = document.createElement("canvas");
    small.width = 20;
    small.height = 20;
    small.getContext("2d")!.drawImage(canvas, 0, 0, 20, 20);
    const logo = small.toDataURL("image/png");
    putProfile(name, { about, logo })
      .then(() => {
        profile.about = about;
        profile.logo = logo;
        close();
        getProfile(name).then((d) => { stats = d.stats; arcana = d.arcana || []; renderAll(d.user); });
      })
      .catch((e) => {
        const box = root.querySelector("#pf-error") as HTMLElement;
        box.textContent = (e as Error).message;
        box.classList.remove("hidden");
      });
      });
}

boot();
