// Admin page: own login (not a user account), arcana assignment
// (max two per user), thread moderation. Token lives in sessionStorage.

import { ARCADA, arcSlug } from "./api.js";
import { initTheme, fmtTime } from "./common.js";
import { esc } from "./render.js";

const TOKEN_KEY = "uni-admin-token";

function getToken(): string {
  try { return sessionStorage.getItem(TOKEN_KEY) || ""; } catch { return ""; }
}
function setToken(t: string): void {
  try { t ? sessionStorage.setItem(TOKEN_KEY, t) : sessionStorage.removeItem(TOKEN_KEY); } catch { /* ignore */ }
}

async function adminApi(path: string, opts: { method?: string; body?: unknown } = {}): Promise<any> {
  const headers: Record<string, string> = {};
  const token = getToken();
  if (token) headers["Authorization"] = "Bearer " + token;
  const res = await fetch("/api/admin/" + path, {
    method: opts.method || "GET",
    headers,
    body: opts.body === undefined ? undefined : JSON.stringify(opts.body),
  });
  let data: any = null;
  try { data = await res.json(); } catch { /* not json */ }
  if (!res.ok) throw new Error((data && data.error) || `HTTP ${res.status}`);
  return data;
}

const $ = (id: string) => document.getElementById(id)!;

// ---------------- boot ----------------
async function boot(): Promise<void> {
  initTheme();
  const area = $("admin-area");
  if (getToken()) {
    const out = document.createElement("button");
    out.className = "btn small";
    out.textContent = "logout";
    out.addEventListener("click", async () => {
      try { await adminApi("logout", { method: "POST" }); } catch { /* ignore */ }
      setToken("");
      location.reload();
    });
    area.replaceChildren(out);
    await loadMain();
  } else {
    area.innerHTML = "";
    const loginPanel = $("admin-login");
    loginPanel.classList.remove("hidden");
    wireLogin();
  }
}

function wireLogin(): void {
  $("adm-login-btn").addEventListener("click", async () => {
    const username = ($("adm-user") as HTMLInputElement).value.trim();
    const password = ($("adm-pass") as HTMLInputElement).value;
    try {
      const d = await adminApi("", { method: "POST", body: { username, password } });
      setToken(d.token);
      location.reload();
    } catch (e) {
      const box = $("adm-error");
      box.textContent = (e as Error).message;
      box.classList.remove("hidden");
    }
  });
}

// ---------------- legend ----------------
function renderLegend(): void {
  const box = $("legend");
  box.innerHTML = "";
  for (const a of ARCADA) {
    const chip = document.createElement("span");
    chip.className = "arc " + arcSlug(a);
    chip.textContent = a;
    chip.title = a;
    box.appendChild(chip);
  }
}

// ---------------- accounts ----------------
function wireCreateUser(): void {
  $("adm-create-btn").addEventListener("click", async () => {
    const username = ($("adm-new-user") as HTMLInputElement).value.trim();
    const display = ($("adm-new-display") as HTMLInputElement).value.trim();
    const password = ($("adm-new-pass") as HTMLInputElement).value;
    const errBox = $("adm-create-error");
    try {
      await adminApi("users", { method: "POST", body: { username, password, display_name: display } });
      ($("adm-new-user") as HTMLInputElement).value = "";
      ($("adm-new-display") as HTMLInputElement).value = "";
      ($("adm-new-pass") as HTMLInputElement).value = "";
      errBox.classList.add("hidden");
      void renderUsers();
    } catch (e) {
      errBox.textContent = (e as Error).message;
      errBox.classList.remove("hidden");
    }
  });
}

// ---------------- users / arcana ----------------
interface AdminUser {
  username: string;
  display_name: string | null;
  admin: boolean;
  created: number;
  arcana: string[];
  spaces: number;
  posts: number;
}

function arcSlot(selected: string): HTMLSelectElement {
  const sel = document.createElement("select");
  sel.className = "arc-slot";
  const none = document.createElement("option");
  none.value = "";
  none.textContent = "— none —";
  sel.appendChild(none);
  for (const a of ARCADA) {
    const o = document.createElement("option");
    o.value = a;
    o.textContent = a;
    sel.appendChild(o);
  }
  sel.value = selected || "";
  return sel;
}

async function renderUsers(): Promise<void> {
  const box = $("admin-users");
  box.innerHTML = '<div class="dim">loading…</div>';
  let users: AdminUser[];
  try {
    users = (await adminApi("users")).users;
  } catch (e) {
    box.innerHTML = `<div class="error-box">${esc((e as Error).message)}</div>`;
    return;
  }
  box.innerHTML = "";
  for (const u of users) {
    const row = document.createElement("div");
    row.className = "admin-user";
    const top = document.createElement("div");
    top.className = "row";
    const who = document.createElement("a");
    who.href = "/user.html?name=" + encodeURIComponent(u.username);
    who.textContent = "@" + u.username;
    who.title = "open profile";
    const meta = document.createElement("span");
    meta.className = "faint xs mono";
    meta.textContent = `joined ${fmtTime(u.created)} · spaces ${u.spaces} · posts ${u.posts}` +
      (u.admin ? " · admin" : "");
    const spacer = document.createElement("span");
    spacer.className = "spacer";
    const del = document.createElement("button");
    del.className = "btn small danger";
    del.textContent = "delete";
    del.title = "remove this account: sessions, profile, spaces, posts, votes";
    del.addEventListener("click", async () => {
      if (!window.confirm(`delete @${u.username} and all their data? this cannot be undone.`)) return;
      try {
        await adminApi("users/" + encodeURIComponent(u.username), { method: "DELETE" });
        void renderUsers();
      } catch (e) {
        alert((e as Error).message);
      }
    });
    top.append(who, meta, spacer, del);
    row.appendChild(top);

    const edits = document.createElement("div");
    edits.className = "row mt1";
    const s1 = arcSlot(u.arcana[0] || "");
    const s2 = arcSlot(u.arcana[1] || "");
    const status = document.createElement("span");
    status.className = "save-status";

    const save = async () => {
      if (s2.value && s1.value === s2.value) {
        s2.value = "";
      }
      const want = [s1.value, s2.value].filter(Boolean);
      try {
        const d = await adminApi("arcana", { method: "POST", body: { user: u.username, arcanas: want } });
        u.arcana = d.arcana;
        status.textContent = "saved";
        status.className = "save-status ok";
        window.setTimeout(() => { status.textContent = ""; }, 2500);
      } catch (e) {
        status.textContent = (e as Error).message;
        status.className = "save-status bad";
      }
    };
    s1.addEventListener("change", () => { void save(); });
    s2.addEventListener("change", () => { void save(); });
    edits.append(s1, s2, status);
    row.appendChild(edits);
    box.appendChild(row);
  }
}

// ---------------- thread moderation ----------------
async function renderPosts(): Promise<void> {
  const box = $("admin-posts");
  box.innerHTML = '<div class="dim">loading…</div>';
  let posts: any[];
  try {
    posts = (await adminApi("posts")).posts;
  } catch (e) {
    box.innerHTML = `<div class="error-box">${esc((e as Error).message)}</div>`;
    return;
  }
  box.innerHTML = "";
  if (!posts.length) {
    box.innerHTML = '<div class="dim">no threads yet.</div>';
    return;
  }
  for (const p of posts) {
    const item = document.createElement("div");
    item.className = "feed-item admin-post";
    const when = document.createElement("span");
    when.className = "when";
    when.textContent = fmtTime(p.time);
    const body = document.createElement("span");
    const who = document.createElement("a");
    who.className = "who";
    who.href = "/user.html?name=" + encodeURIComponent(p.author);
    who.textContent = "@" + p.author;
    const what = document.createElement("span");
    what.className = "what";
    what.textContent = (p.title ? "「" + p.title + "」 " : "") +
      (p.text || "").slice(0, 100) + (p.parent_id ? " · reply" : "");
    body.append(who, document.createTextNode(" "), what);
    const del = document.createElement("button");
    del.className = "btn small danger";
    del.textContent = "delete";
    del.addEventListener("click", async () => {
      try {
        await adminApi("posts/" + p.id, { method: "DELETE" });
        void renderPosts();
      } catch (e) {
        alert((e as Error).message);
      }
    });
    item.append(when, body, del);
    box.appendChild(item);
  }
}

async function loadMain(): Promise<void> {
  $("admin-main").classList.remove("hidden");
  renderLegend();
  wireCreateUser();
  void renderUsers();
  void renderPosts();
  void renderStats();
  void renderAdminTests();
  void renderAdminEvents();
}

// ---------------- server stats ----------------
function fmtDurSec(sec: number): string {
  sec = Math.floor(sec);
  const d = Math.floor(sec / 86400);
  const h = Math.floor((sec % 86400) / 3600);
  const m = Math.floor((sec % 3600) / 60);
  if (d) return `${d}d ${h}h`;
  if (h) return `${h}h ${m}m`;
  return `${m}m ${sec % 60}s`;
}

function fmtBytes(b: number): string {
  if (b > 1024 ** 3) return (b / 1024 ** 3).toFixed(2) + " GB";
  if (b > 1024 ** 2) return (b / 1024 ** 2).toFixed(1) + " MB";
  if (b > 1024) return (b / 1024).toFixed(1) + " KB";
  return b + " B";
}

function drawBars(canvas: HTMLCanvasElement, labels: string[], values: number[]): void {
  const w = canvas.width, h = canvas.height;
  const ctx = canvas.getContext("2d")!;
  ctx.clearRect(0, 0, w, h);
  const max = Math.max(1, ...values);
  const n = labels.length;
  const bw = w / n;
  ctx.font = "9px monospace";
  values.forEach((v, i) => {
    const bh = (v / max) * (h - 24);
    ctx.fillStyle = "#4da3ff";
    ctx.fillRect(i * bw + 4, h - 16 - bh, bw - 8, bh);
    ctx.fillStyle = "#8b98a5";
    ctx.fillText(String(v), i * bw + 6, h - 20 - bh);
    ctx.fillText(labels[i], i * bw + 4, h - 4);
  });
}

function drawLine(canvas: HTMLCanvasElement, values: number[]): void {
  const w = canvas.width, h = canvas.height;
  const ctx = canvas.getContext("2d")!;
  ctx.clearRect(0, 0, w, h);
  ctx.strokeStyle = "rgba(128,138,150,.3)";
  ctx.beginPath();
  for (let g = 0; g <= 4; g++) {
    const y = (h - 20) * g / 4;
    ctx.moveTo(0, y); ctx.lineTo(w, y);
  }
  ctx.stroke();
  if (!values.length) return;
  const max = Math.max(1, ...values);
  ctx.strokeStyle = "#3fb950";
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  values.forEach((v, i) => {
    const x = (i / (values.length - 1 || 1)) * w;
    const y = (h - 16) - (v / max) * (h - 24);
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.stroke();
}

async function renderStats(): Promise<void> {
  const box = $("admin-stats");
  box.innerHTML = '<div class="dim">loading…</div>';
  let d: any;
  try {
    d = await adminApi("stats");
  } catch (e) {
    box.innerHTML = `<div class="error-box">${esc((e as Error).message)}</div>`;
    return;
  }
  box.innerHTML = "";
  const c = d.counts;
  const cards: Array<[string, string]> = [
    ["uptime", fmtDurSec(d.uptime)],
    ["load (1/5/15m)", d.load.map((x: number) => x.toFixed(1)).join(" / ")],
    ["cpu time", d.cpu_s + " s"],
    ["peak rss", fmtBytes((d.maxrss_kb || 0) * 1024)],
    ["disk", fmtBytes(d.disk_bytes) + " / " + fmtBytes(d.disk_budget)],
    ["users", c.users], ["spaces", c.spaces], ["notes", c.notes],
    ["comments", c.comments], ["posts", c.posts], ["tests", c.tests],
    ["results", c.results], ["events", c.events], ["chats", c.chats],
    ["messages", c.messages], ["rooms", c.rooms],
    ["notifications", c.notifications],
  ];
  const grid = document.createElement("div");
  grid.className = "stat-grid";
  for (const [label, val] of cards) {
    const cell = document.createElement("div");
    cell.className = "stat";
    const num = document.createElement("div");
    num.className = "n";
    num.textContent = String(val);
    const lab = document.createElement("div");
    lab.className = "l";
    lab.textContent = label;
    cell.append(num, lab);
    grid.appendChild(cell);
  }
  box.appendChild(grid);

  // data quantity chart
  const head1 = document.createElement("div");
  head1.className = "micro mt4 mb1";
  head1.textContent = "data quantities by type";
  box.appendChild(head1);
  const dataLabels = ["spaces", "notes", "posts", "tests", "results", "events",
    "chats", "messages", "rooms", "users"];
  const barCanvas = document.createElement("canvas");
  barCanvas.width = 680;
  barCanvas.height = 180;
  box.appendChild(barCanvas);
  drawBars(barCanvas, dataLabels, dataLabels.map((k) => c[k] || 0));

  // requests over time
  const head2 = document.createElement("div");
  head2.className = "micro mt4 mb1";
  head2.textContent = "requests per minute (last hours)";
  box.appendChild(head2);
  const lineCanvas = document.createElement("canvas");
  lineCanvas.width = 680;
  lineCanvas.height = 140;
  box.appendChild(lineCanvas);
  const series: Array<{ ts: number; n: number }> = d.series || [];
  const step = 60;
  const last = series.length ? series[series.length - 1].ts : 0;
  const points: number[] = [];
  for (let t = last - 180 * step; t <= last; t += step) {
    const b = series.find((s: any) => s.ts === t);
    points.push(b ? b.n : 0);
  }
  drawLine(lineCanvas, points);

  // route table
  const head3 = document.createElement("div");
  head3.className = "micro mt4 mb1";
  head3.textContent = "requests by route";
  box.appendChild(head3);
  const tbl = document.createElement("div");
  tbl.className = "mt1";
  for (const r of d.routes.slice(0, 30)) {
    const row = document.createElement("div");
    row.className = "lb-row";
    const route = document.createElement("span");
    route.className = "lb-user mono xs";
    route.textContent = r.route;
    const n = document.createElement("span");
    n.className = "lb-val";
    n.textContent = String(r.n);
    const avg = document.createElement("span");
    avg.className = "lb-val";
    avg.textContent = r.avg_ms + " ms";
    const errs = document.createElement("span");
    errs.className = "lb-val" + (r.err ? " warn" : " faint");
    errs.textContent = r.err ? r.err + " err" : "ok";
    row.append(route, n, avg, errs);
    tbl.appendChild(row);
  }
  box.appendChild(tbl);
}

// ---------------- tests / events moderation ----------------
async function renderAdminTests(): Promise<void> {
  const box = $("admin-tests");
  box.innerHTML = '<div class="dim">loading…</div>';
  let d: any;
  try {
    d = await adminApi("tests");
  } catch (e) {
    box.innerHTML = `<div class="error-box">${esc((e as Error).message)}</div>`;
    return;
  }
  box.innerHTML = "";
  if (!d.tests.length) { box.innerHTML = '<div class="dim">no tests.</div>'; return; }
  for (const t of d.tests) {
    const row = document.createElement("div");
    row.className = "feed-item admin-post";
    const what = document.createElement("span");
    what.className = "what";
    what.textContent = `"${t.title}" · @${t.owner} · ${t.questions} question(s) · ${t.completions} completion(s)`;
    const del = document.createElement("button");
    del.className = "btn small danger";
    del.textContent = "delete";
    del.addEventListener("click", async () => {
      if (!window.confirm(`delete test "${t.title}"?`)) return;
      try {
        await adminApi("tests/" + encodeURIComponent(t.id), { method: "DELETE" });
        void renderAdminTests();
      } catch (e) { alert((e as Error).message); }
    });
    row.append(what, del);
    box.appendChild(row);
  }
}

async function renderAdminEvents(): Promise<void> {
  const box = $("admin-events");
  box.innerHTML = '<div class="dim">loading…</div>';
  let d: any;
  try {
    d = await adminApi("events");
  } catch (e) {
    box.innerHTML = `<div class="error-box">${esc((e as Error).message)}</div>`;
    return;
  }
  box.innerHTML = "";
  if (!d.events.length) { box.innerHTML = '<div class="dim">no events.</div>'; return; }
  for (const ev of d.events) {
    const row = document.createElement("div");
    row.className = "feed-item admin-post";
    const what = document.createElement("span");
    what.className = "what";
    what.textContent = `"${ev.title}" · @${ev.owner} · ${new Date(ev.start * 1000).toLocaleString()}`;
    const del = document.createElement("button");
    del.className = "btn small danger";
    del.textContent = "delete";
    del.addEventListener("click", async () => {
      if (!window.confirm(`delete event "${ev.title}"?`)) return;
      try {
        await adminApi("events/" + encodeURIComponent(ev.id), { method: "DELETE" });
        void renderAdminEvents();
      } catch (e) { alert((e as Error).message); }
    });
    row.append(what, del);
    box.appendChild(row);
  }
}

boot();
