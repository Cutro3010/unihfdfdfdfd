// Leaderboard page: creators (spaces + tests) and solvers
// (tests completed, correct answers, total time).

import { getLeaderboard } from "./api.js";
import { esc } from "./render.js";
import { initTheme, initBell, initUserArea, fmtDur } from "./common.js";

const $ = (id: string) => document.getElementById(id)!;

function rankClass(i: number): string {
  return i === 0 ? "gold" : i === 1 ? "silver" : i === 2 ? "bronze" : "";
}

function row(i: number, name: string, cells: string[]): HTMLElement {
  const el = document.createElement("div");
  el.className = "lb-row";
  const rank = document.createElement("span");
  rank.className = "rank " + rankClass(i);
  rank.textContent = String(i + 1);
  const who = document.createElement("a");
  who.className = "lb-user";
  who.href = "/user.html?name=" + encodeURIComponent(name);
  who.textContent = "@" + name;
  el.append(rank, who);
  for (const c of cells) {
    const v = document.createElement("span");
    v.className = "lb-val";
    v.textContent = c;
    el.appendChild(v);
  }
  return el;
}

async function boot(): Promise<void> {
  initTheme();
  initBell();
  await initUserArea();
  const creators = $("lb-creators");
  const solvers = $("lb-solvers");
  creators.innerHTML = '<div class="dim">loading…</div>';
  solvers.innerHTML = '<div class="dim">loading…</div>';
  let d: any;
  try {
    d = await getLeaderboard();
  } catch (e) {
    creators.innerHTML = `<div class="error-box">${esc((e as Error).message)}</div>`;
    solvers.innerHTML = "";
    return;
  }
  creators.innerHTML = "";
  if (!d.creators.length) creators.innerHTML = '<div class="dim">nothing yet.</div>';
  d.creators.forEach((c: any, i: number) => {
    creators.appendChild(row(i, c.username,
      [String(c.spaces), String(c.tests), `${c.spaces + c.tests} total`]));
  });
  solvers.innerHTML = "";
  if (!d.solvers.length) solvers.innerHTML = '<div class="dim">nothing yet.</div>';
  d.solvers.forEach((s: any, i: number) => {
    solvers.appendChild(row(i, s.username,
      [String(s.tests), String(s.correct), fmtDur(s.seconds)]));
  });
}

boot();
