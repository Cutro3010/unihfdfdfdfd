// Client-side PDF export of a note. No window.print() involved: jsPDF builds
// the PDF in memory, and LaTeX math goes in as vector SVG via MathJax
// (tex-svg bundle) drawn into the PDF with svg2pdf.js.
// jsPDF, svg2pdf.js and MathJax are vendored under web/vendor/ (space.html).

declare const jspdf: any;
declare const MathJax: any;

interface Seg {
  t: "text" | "math" | "code";
  s: string;
  b?: boolean;
  i?: boolean;
  el?: Element;   // svg element for math segs
}

interface Block {
  kind: "p" | "h1" | "h2" | "h3" | "h4" | "code" | "quote" | "ul" | "ol" | "hr" | "math";
  text?: string;
  items?: string[];
}

const BODY_SIZE = 11;
const LH = 15.5;
const M = 48; // page margin (pt)

// ---------------- math (MathJax -> svg element) ----------------

async function texToSvgEl(tex: string, display: boolean): Promise<Element | null> {
  try {
    if (typeof MathJax === "undefined" || typeof MathJax.tex2svg !== "function") return null;
    if (MathJax.startup && MathJax.startup.promise) await MathJax.startup.promise;
    const node = MathJax.tex2svg(tex.trim(), { display });
    if (!node) return null;
    const svg = node.querySelector ? node.querySelector("svg") : null;
    return (svg || node) as Element;
  } catch {
    return null;
  }
}

function svgBox(el: Element, size: number): [number, number] {
  try {
    const vb = el.getAttribute("viewBox");
    if (vb) {
      const parts = vb.split(/[\s,]+/).filter(Boolean).map(Number);
      if (parts.length === 4 && parts[2] > 0 && parts[3] > 0) {
        // MathJax svg viewBox: 1000 units per em at the current font size
        return [(parts[2] / 1000) * size, (parts[3] / 1000) * size];
      }
    }
  } catch { /* fall through */ }
  return [size * 2, size * 1.4];
}

/** Draw an svg element into the PDF at (x, y) with the given size in pt.
 *  Uses the svg plugin that svg2pdf.js installs on jsPDF instances. */
async function drawMathSvg(doc: any, el: Element, x: number, y: number, w: number, h: number): Promise<boolean> {
  if (typeof doc.svg !== "function") return false;
  try {
    await doc.svg(el, { x, y, width: w, height: h });
    return true;
  } catch {
    return false;
  }
}

// ---------------- inline parsing ----------------

const RICH_TOKEN = /(\*\*[^*\n]+\*\*|\*[^*\n]+\*|`[^`\n]+`|!?\[[^\]]*\]\([^)]*\))/g;

function parseRich(text: string): Seg[] {
  const segs: Seg[] = [];
  let rest = text;
  while (rest) {
    RICH_TOKEN.lastIndex = 0;
    const m = RICH_TOKEN.exec(rest);
    if (!m) { segs.push({ t: "text", s: rest }); break; }
    if (m.index > 0) segs.push({ t: "text", s: rest.slice(0, m.index) });
    const tok = m[0];
    if (tok.startsWith("**")) segs.push({ t: "text", s: tok.slice(2, -2), b: true });
    else if (tok.startsWith("*")) segs.push({ t: "text", s: tok.slice(1, -1), i: true });
    else if (tok.startsWith("`")) segs.push({ t: "code", s: tok.slice(1, -1) });
    else {
      const lm = tok.match(/^!?\[([^\]]*)\]\(([^)]*)\)$/);
      if (lm) {
        segs.push(tok.startsWith("!") ? { t: "text", s: "[image]" }
          : { t: "text", s: lm[1] });
      } else {
        segs.push({ t: "text", s: tok });
      }
    }
    rest = rest.slice(m.index + tok.length);
  }
  return segs;
}

async function parseInline(line: string): Promise<Seg[]> {
  const segs: Seg[] = [];
  const parts = line.split(/(\$[^$\n]+\$)/g);
  for (const p of parts) {
    if (p.length > 2 && p.startsWith("$") && p.endsWith("$")) {
      const tex = p.slice(1, -1);
      const el = await texToSvgEl(tex, false);
      if (el) segs.push({ t: "math", s: tex, el });
      else segs.push({ t: "text", s: tex, i: true });
      continue;
    }
    segs.push(...parseRich(p));
  }
  return segs;
}

// ---------------- block parsing ----------------

function parseBlocks(src: string): Block[] {
  const stash: Block[] = [];
  const ph = (b: Block): string => { stash.push(b); return `\u0000${stash.length - 1}\u0000`; };
  let h = src.replace(/```([\s\S]*?)```/g, (_m, c: string) =>
    ph({ kind: "code", text: c.replace(/^\n/, "").replace(/\n\s*$/, "") }));
  h = h.replace(/\$\$([\s\S]+?)\$\$/g, (_m, tex: string) => ph({ kind: "math", text: tex.trim() }));

  const out: Block[] = [];
  let para: string[] = [];
  let listKind: "" | "ul" | "ol" = "";
  let listItems: string[] = [];
  let quote: string[] = [];

  const flushPara = () => { if (para.length) { out.push({ kind: "p", text: para.join("\n") }); para = []; } };
  const flushList = () => {
    if (listItems.length) { out.push({ kind: listKind as "ul" | "ol", items: listItems }); listItems = []; listKind = ""; }
  };
  const flushQuote = () => { if (quote.length) { out.push({ kind: "quote", text: quote.join("\n") }); quote = []; } };
  const PH = /\u0000(\d+)\u0000/g;

  for (const line of h.split("\n")) {
    const lone = line.trim().match(/^\u0000(\d+)\u0000$/);
    if (lone) { flushPara(); flushList(); flushQuote(); out.push(stash[+lone[1]]); continue; }
    const expanded = line.replace(PH, (_m, i: string) => {
      const b = stash[+i];
      if (!b) return "";
      return b.kind === "math" ? `$${b.text}$` : (b.text || "");
    });
    if (/^@due\s/.test(expanded)) continue;           // meta line, not content
    const hh = expanded.match(/^(#{1,4})\s+(.*)$/);
    if (hh) { flushPara(); flushList(); flushQuote(); out.push({ kind: `h${hh[1].length}` as any, text: hh[2] }); continue; }
    if (/^-{3,}\s*$/.test(expanded.trim())) { flushPara(); flushList(); flushQuote(); out.push({ kind: "hr" }); continue; }
    const ul = expanded.match(/^\s*[-*]\s+(.*)$/);
    const ol = expanded.match(/^\s*\d+\.\s+(.*)$/);
    const qt = expanded.match(/^\s*>\s?(.*)$/);
    if (ul) { flushPara(); flushQuote(); if (listKind !== "ul") flushList(); listKind = "ul"; listItems.push(ul[1]); continue; }
    if (ol) { flushPara(); flushQuote(); if (listKind !== "ol") flushList(); listKind = "ol"; listItems.push(ol[1]); continue; }
    if (qt) { flushPara(); flushList(); quote.push(qt[1]); continue; }
    if (expanded.trim() === "") { flushPara(); flushList(); flushQuote(); continue; }
    flushList(); flushQuote();
    para.push(expanded);
  }
  flushPara(); flushList(); flushQuote();
  return out;
}

// ---------------- layout / drawing ----------------

function setFont(doc: any, s: Seg, size: number): void {
  let family = "times";
  if (s.t === "code") family = "courier";
  let style = "normal";
  if (s.b && s.i) style = "bolditalic";
  else if (s.b) style = "bold";
  else if (s.i) style = "italic";
  doc.setFont(family, style);
  doc.setFontSize(size);
}

function segWidth(doc: any, s: Seg, size: number): number {
  if (s.t === "math" && s.el) return svgBox(s.el, size)[0];
  setFont(doc, s, size);
  return doc.getTextWidth(s.s);
}

function layoutInline(doc: any, segs: Seg[], maxW: number, size: number): Seg[][] {
  const lines: Seg[][] = [];
  let cur: Seg[] = [];
  let w = 0;
  const emit = () => { if (cur.length) { lines.push(cur); cur = []; w = 0; } };
  for (const s of segs) {
    if (s.t !== "text") {
      const sw = segWidth(doc, s, size);
      if (w + sw > maxW && cur.length) emit();
      cur.push(s); w += sw;
      continue;
    }
    for (const word of s.s.split(/(\s+)/)) {
      if (!word) continue;
      const wseg: Seg = { ...s, s: word };
      const ww = segWidth(doc, wseg, size);
      if (w + ww > maxW && cur.length) emit();
      cur.push(wseg); w += ww;
    }
  }
  emit();
  return lines;
}

async function drawLine(doc: any, segs: Seg[], x: number, y: number, size: number): Promise<void> {
  let cx = x;
  for (const s of segs) {
    if (s.t === "math" && s.el) {
      const [w, h] = svgBox(s.el, size);
      const ok = await drawMathSvg(doc, s.el, cx, y - h * 0.76, w, h);
      if (!ok) {
        setFont(doc, { t: "text", s: s.s, i: true }, size);
        doc.text(s.s, cx, y);
      }
      cx += w;
      continue;
    }
    setFont(doc, s, size);
    doc.text(s.s, cx, y);
    cx += doc.getTextWidth(s.s);
  }
}

// ---------------- export ----------------

export async function exportNotePdf(opts: {
  spaceName: string; path: string; branch: string; content: string;
}): Promise<void> {
  const { spaceName, path, branch, content } = opts;
  if (typeof jspdf === "undefined" || !jspdf.jsPDF) {
    throw new Error("pdf library not loaded");
  }
  const doc = new jspdf.jsPDF({ unit: "pt", format: "a4" });
  const PW = doc.internal.pageSize.getWidth();
  const PH = doc.internal.pageSize.getHeight();
  const MAXW = PW - M * 2;
  let y = M + 14;
  let page = 1;

  const footer = () => {
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(130, 135, 145);
    doc.text(`${spaceName} · ${path}`, M, PH - 22);
    doc.text(String(page), PW - M, PH - 22, { align: "right" });
  };
  const newPage = () => { footer(); doc.addPage(); page += 1; y = M; };
  const ensure = (need: number) => { if (y + need > PH - M) newPage(); };

  // title block
  const base = path.split("/").pop() || path;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(15);
  doc.setTextColor(15, 20, 40);
  doc.text(base, M, y);
  y += 14;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(130, 135, 145);
  doc.text(`${spaceName} · branch ${branch} · ${new Date().toLocaleDateString()}`, M, y);
  y += 14;
  doc.setDrawColor(200, 205, 215);
  doc.line(M, y, PW - M, y);
  y += 16;

  for (const b of parseBlocks(content)) {
    switch (b.kind) {
      case "h1": case "h2": case "h3": case "h4": {
        const size = { h1: 19, h2: 15, h3: 12.5, h4: 11 }[b.kind];
        doc.setTextColor(15, 20, 40);
        for (const l of layoutInline(doc, await parseInline(b.text || ""), MAXW, size)) {
          ensure(size + 6);
          await drawLine(doc, l.map((s) => ({ ...s, b: true })), M, y, size);
          y += size * 1.3;
        }
        y += 6;
        break;
      }
      case "p": {
        const size = BODY_SIZE;
        doc.setTextColor(30, 32, 38);
        for (const l of layoutInline(doc, await parseInline(b.text || ""), MAXW, size)) {
          ensure(LH);
          await drawLine(doc, l, M, y, size);
          y += LH;
        }
        y += 5;
        break;
      }
      case "code": {
        const lines = (b.text || "").split("\n");
        const size = 8.5;
        const clh = 11.5;
        const h = lines.length * clh + 12;
        if (y + h > PH - M) newPage();
        doc.setFillColor(244, 246, 250);
        doc.setDrawColor(214, 218, 226);
        doc.rect(M, y, MAXW, h, "F");
        doc.rect(M, y, MAXW, h);
        doc.setTextColor(20, 22, 28);
        doc.setFont("courier", "normal");
        doc.setFontSize(size);
        let cy = y + 10;
        for (const ln of lines) { doc.text(ln || " ", M + 8, cy); cy += clh; }
        y = cy + 4;
        break;
      }
      case "quote": {
        const size = 10.5;
        doc.setTextColor(80, 85, 95);
        for (const l of layoutInline(doc, await parseInline(b.text || ""), MAXW - 22, size)) {
          ensure(15);
          doc.setFillColor(170, 185, 215);
          doc.rect(M + 2, y - 10, 2.5, 14, "F");
          await drawLine(doc, l, M + 12, y, size);
          y += 15;
        }
        y += 5;
        break;
      }
      case "ul": case "ol": {
        const size = BODY_SIZE;
        doc.setTextColor(30, 32, 38);
        let idx = 0;
        for (const it of (b.items || [])) {
          const mark = b.kind === "ol" ? `${idx + 1}.` : "•";
          idx += 1;
          const ls = layoutInline(doc, await parseInline(it), MAXW - 24, size);
          for (let li = 0; li < ls.length; li++) {
            ensure(LH);
            doc.setFont("helvetica", "normal");
            doc.setFontSize(size);
            if (li === 0) doc.text(mark, M + 8, y);
            await drawLine(doc, ls[li], M + 24, y, size);
            y += LH;
          }
        }
        y += 4;
        break;
      }
      case "hr":
        ensure(14);
        doc.setDrawColor(180, 184, 192);
        doc.line(M, y, PW - M, y);
        y += 12;
        break;
      case "math": {
        const el = await texToSvgEl(b.text || "", true);
        const size = 12;
        const [w, h] = el ? svgBox(el, size) : [size * 2, size * 1.4];
        const scale = w > MAXW ? MAXW / w : 1;
        ensure(h * scale + 8);
        const x = (PW - w * scale) / 2;
        let drawn = false;
        if (el) {
          drawn = await drawMathSvg(doc, el, x, y - h * scale * 0.72, w * scale, h * scale);
        }
        if (!drawn) {
          doc.setTextColor(60, 65, 80);
          doc.setFont("times", "italic");
          doc.setFontSize(BODY_SIZE);
          doc.text(b.text || "", M + 8, y);
          y += 15;
        } else {
          y += h * scale * 0.55 + 6;
        }
        break;
      }
    }
  }

  footer();
  const fname = base.replace(/\.md$/i, "") + ".pdf";
  doc.save(fname);
}
