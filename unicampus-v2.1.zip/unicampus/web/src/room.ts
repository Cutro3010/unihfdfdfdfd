// The "Heaven Hotel" room page. Every user has a room (unique id, name,
// tagline) that is fully visible to everyone. The owner gets a desk of
// widgets: pomodoro, fuzzy finder, flashcards, to-do lists, a graph
// calculator, draggable post-its and an annotating text editor.

import {
  getOwnRoom, getRoom, listRooms, patchRoom, saveRoomSection,
  importDeck, cardTemplateUrl, find, getStreak, postPomo, User,
} from "./api.js";
import { renderMarkdown, esc } from "./render.js";
import {
  initTheme, initBell, initUserArea, openModal,
} from "./common.js";

let user: User | null = null;
let room: any = null;
let mine = false;

const POSTIT_COLORS = ["#4da3ff", "#3fb950", "#f85149", "#d29922", "#ff66cc", "#8b98a5"];

const $ = (id: string) => document.getElementById(id)!;

// ---------------- boot ----------------
async function boot(): Promise<void> {
  initTheme();
  initBell();
  user = await initUserArea();
  const qp = new URLSearchParams(location.search);
  const id = qp.get("id");
  try {
    room = id ? (await getRoom(id)).room : (await getOwnRoom()).room;
  } catch (e) {
    $("room-name").textContent = "room";
    $("room-tagline").textContent = (e as Error).message;
    return;
  }
  mine = !!user && room.owner === user.username;
  document.title = "uniheaven · " + room.name;
  renderHead();
  renderStreak();
  renderPostits();
  renderPomodoro();
  renderFind();
  renderFlashcards();
  renderTodos();
  renderGraph();
  renderEditor();
}

// ---------------- streak ----------------
async function renderStreak(): Promise<void> {
  const root = $("streak-root");
  let d: any;
  try {
    d = await getStreak(room.owner);
  } catch {
    root.innerHTML = '<div class="dim">no streak data yet.</div>';
    return;
  }
  const s = d.stats;
  root.innerHTML = "";
  const big = document.createElement("div");
  big.className = "pomo-big";
  big.textContent = String(s.streak);
  const lab = document.createElement("div");
  lab.className = "micro dim mb1";
  lab.textContent = "day streak (best " + s.best + ")";
  const bars = document.createElement("div");
  bars.className = "row mb2";
  bars.style.gap = "3px";
  bars.style.alignItems = "flex-end";
  for (const day of s.last7) {
    const col = document.createElement("div");
    col.style.flex = "1";
    col.style.display = "flex";
    col.style.flexDirection = "column";
    col.style.alignItems = "center";
    const v = Math.max(day.e, Math.round(day.s / 900));
    const bar = document.createElement("div");
    bar.style.width = "100%";
    bar.style.height = Math.max(3, v * 8) + "px";
    bar.style.background = v ? "var(--accent)" : "var(--border)";
    bar.style.borderRadius = "2px";
    bar.title = day.day + " · " + day.e + " exercise(s) · " + Math.round(day.s / 60) + " min";
    const lbl = document.createElement("span");
    lbl.className = "faint";
    lbl.style.fontSize = "9px";
    lbl.textContent = day.day.slice(5);
    col.append(bar, lbl);
    bars.appendChild(col);
  }
  const meta = document.createElement("div");
  meta.className = "small dim";
  meta.textContent = `${s.exercises} exercise(s) solved · `
    + `${Math.round(s.studied / 3600)}h ${Math.round((s.studied % 3600) / 60)}m studied`;
  root.append(lab, big, bars, meta);
}

function renderHead(): void {
  $("room-name").textContent = room.name;
  const owner = $("room-owner");
  owner.innerHTML = "";
  const a = document.createElement("a");
  a.href = "/user.html?name=" + encodeURIComponent(room.owner);
  a.textContent = "@" + room.owner;
  owner.append("by ", a, document.createTextNode(" · id " + room.id));
  $("room-tagline").textContent = room.tagline || "";
  applyLook();
  $("room-edit-btn").classList.toggle("hidden", !mine);
  $("room-edit-btn").addEventListener("click", () => { void editRoomModal(); });
  $("room-list-btn").addEventListener("click", () => { void roomsModal(); });
}

// ---- room customisation: theme, header ornament, status, columns, widgets ----
const THEMES = ["ice", "lavender", "aqua", "blush", "graphite"];
const BANNERS = ["none", "disc", "wings", "moons", "reticle", "sparkle"];
const WIDGETS: [string, string][] = [
  ["postits", "post-it board"], ["streak", "streak"], ["pomo", "pomodoro"], ["find", "find anything"],
  ["flash", "flashcards"], ["todo", "to-do"], ["graph", "graph calculator"], ["editor", "annotate"],
];

/** Paint the look stored in a room (or a draft of it) onto the page. */
function applyLook(r: any = room): void {
  const main = document.querySelector("main.page") as HTMLElement;
  main.dataset.roomTheme = THEMES.includes(r.theme) ? r.theme : "ice";
  $("room-banner").className = "room-banner rb-" + (BANNERS.includes(r.banner) ? r.banner : "none");
  (document.querySelector(".room-grid") as HTMLElement).dataset.cols = String([1, 2, 3].includes(r.cols) ? r.cols : 0);
  const hidden: string[] = Array.isArray(r.hidden) ? r.hidden : [];
  document.querySelectorAll<HTMLElement>("[data-widget]").forEach((el) => {
    el.classList.toggle("hidden", hidden.includes(el.dataset.widget || ""));
  });
  const st = $("room-status");
  st.textContent = r.status || "";
  st.classList.toggle("hidden", !r.status);
}

async function editRoomModal(): Promise<void> {
  const cur = { theme: room.theme || "ice", banner: room.banner || "disc", cols: room.cols || 0,
                hidden: new Set<string>(room.hidden || []) };
  const swatches = THEMES.map((t) =>
    `<button type="button" class="swatch" data-room-theme="${t}" data-pick="${t}" title="${t}" aria-label="${t}"></button>`).join("");
  const banners = BANNERS.map((b) => `<option value="${b}">${b === "none" ? "no ornament" : b}</option>`).join("");
  const widgets = WIDGETS.map(([id, label]) =>
    `<label class="check"><input type="checkbox" data-w="${id}" ${cur.hidden.has(id) ? "" : "checked"}> ${label}</label>`).join("");
  const { root, close } = openModal(`
    <h2>customize my room</h2>
    <label class="field"><span class="lbl">name</span>
      <input type="text" id="rm-name" value="${esc(room.name)}"></label>
    <label class="field"><span class="lbl">tagline (everyone can see it)</span>
      <input type="text" id="rm-tag" value="${esc(room.tagline || "")}"></label>
    <label class="field"><span class="lbl">status, e.g. "studying analisi 1" (max 60)</span>
      <input type="text" id="rm-status" maxlength="60" value="${esc(room.status || "")}"></label>
    <div class="field"><span class="lbl">color</span><div class="swatches" id="rm-swatches">${swatches}</div></div>
    <div class="row mb2">
      <label class="field grow"><span class="lbl">header ornament</span>
        <select id="rm-banner">${banners}</select></label>
      <label class="field grow"><span class="lbl">widget columns</span>
        <select id="rm-cols"><option value="0">auto</option><option value="1">1</option>
        <option value="2">2</option><option value="3">3</option></select></label>
    </div>
    <div class="field"><span class="lbl">widgets to show</span><div class="checks" id="rm-widgets">${widgets}</div></div>
    <div class="error-box hidden" id="rm-error"></div>
    <div class="actions">
      <button class="btn" id="rm-cancel">cancel</button>
      <button class="btn primary" id="rm-go">save</button>
    </div>`);
  const bannerSel = root.querySelector("#rm-banner") as HTMLSelectElement;
  const colsSel = root.querySelector("#rm-cols") as HTMLSelectElement;
  bannerSel.value = cur.banner;
  colsSel.value = String(cur.cols);
  const marks = () => root.querySelectorAll<HTMLElement>(".swatch").forEach((b) =>
    b.classList.toggle("on", b.dataset.pick === cur.theme));
  marks();
  // everything previews live; cancel puts the saved look back
  const preview = () => applyLook({ ...room, theme: cur.theme, banner: cur.banner, cols: cur.cols,
    hidden: [...cur.hidden], status: (root.querySelector("#rm-status") as HTMLInputElement).value.trim() });
  root.querySelectorAll<HTMLElement>(".swatch").forEach((b) => b.addEventListener("click", () => {
    cur.theme = b.dataset.pick!; marks(); preview();
  }));
  bannerSel.addEventListener("change", () => { cur.banner = bannerSel.value; preview(); });
  colsSel.addEventListener("change", () => { cur.cols = Number(colsSel.value); preview(); });
  root.querySelector("#rm-status")!.addEventListener("input", preview);
  root.querySelectorAll<HTMLInputElement>("[data-w]").forEach((c) => c.addEventListener("change", () => {
    if (c.checked) cur.hidden.delete(c.dataset.w!); else cur.hidden.add(c.dataset.w!);
    preview();
  }));
  const cancel = () => { applyLook(); close(); };
  root.querySelector("#rm-cancel")!.addEventListener("click", cancel);
  root.querySelector("#rm-go")!.addEventListener("click", async () => {
    try {
      const r = await patchRoom(room.id, {
        name: (root.querySelector("#rm-name") as HTMLInputElement).value.trim(),
        tagline: (root.querySelector("#rm-tag") as HTMLInputElement).value.trim(),
        status: (root.querySelector("#rm-status") as HTMLInputElement).value.trim(),
        theme: cur.theme, banner: cur.banner, cols: cur.cols, hidden: [...cur.hidden],
      });
      room = r.room;
      renderHead();
      close();
    } catch (e) {
      const b = root.querySelector("#rm-error") as HTMLElement;
      b.textContent = (e as Error).message;
      b.classList.remove("hidden");
    }
  });
}

async function roomsModal(): Promise<void> {
  let d: any;
  try {
    d = await listRooms();
  } catch (e) {
    alert((e as Error).message);
    return;
  }
  const rows = d.rooms.map((r: any) => `
    <div class="lb-row">
      <a class="lb-user" href="/room.html?id=${encodeURIComponent(r.id)}">${esc(r.name)}</a>
      <span class="dim small">@${esc(r.owner)}</span>
      <span class="faint small grow">${esc(r.tagline || "")}</span>
    </div>`).join("") || '<div class="dim">no rooms yet.</div>';
  const { root, close } = openModal(`<h2>rooms</h2>${rows}
    <div class="actions"><button class="btn" id="rl-close">close</button></div>`);
  root.querySelector("#rl-close")!.addEventListener("click", close);
}

// ---------------- save helper ----------------
function saveSection(section: string, data: unknown, quiet = false): void {
  if (!mine) return;
  saveRoomSection(room.id, section, data)
    .then((d) => { room = d.room; })
    .catch((e) => { if (!quiet) alert("save failed: " + (e as Error).message); });
}

// ---------------- pomodoro ----------------
interface PomoState {
  mode: "focus" | "break"; remain: number; running: boolean;
  sessions: number; workMin: number; breakMin: number;
}
function renderPomodoro(): void {
  const root = $("pomo-root");
  root.innerHTML = "";
  const st: PomoState = { mode: "focus", remain: 25 * 60, running: false,
    sessions: 0, workMin: 25, breakMin: 5 };
  const clock = document.createElement("div");
  clock.className = "pomo-big";
  const mode = document.createElement("div");
  mode.className = "micro mb1";
  const draw = () => {
    const m = Math.floor(st.remain / 60);
    const s = st.remain % 60;
    clock.textContent = `${m}:${String(s).padStart(2, "0")}`;
    mode.textContent = st.mode + (st.running ? " · running" : " · paused")
      + " · " + st.sessions + " focus session(s)";
  };
  const beep = () => {
    try {
      const ctx = new AudioContext();
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.frequency.value = 880;
      g.gain.setValueAtTime(0.12, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
      o.connect(g); g.connect(ctx.destination);
      o.start(); o.stop(ctx.currentTime + 0.3);
    } catch { /* no audio */ }
  };
  let timer: number | undefined;
  const tick = () => {
    st.remain -= 1;
    if (st.remain <= 0) {
      beep();
      if (st.mode === "focus") {
        st.sessions += 1;
        st.mode = "break";
        st.remain = st.breakMin * 60;
        postPomo(st.workMin * 60).catch(() => { /* offline: keep the timer going */ });
      } else {
        st.mode = "focus";
        st.remain = st.workMin * 60;
      }
    }
    draw();
  };
  const startBtn = document.createElement("button");
  startBtn.className = "btn primary";
  startBtn.textContent = "start";
  const pauseBtn = document.createElement("button");
  pauseBtn.className = "btn";
  pauseBtn.textContent = "pause";
  const resetBtn = document.createElement("button");
  resetBtn.className = "btn";
  resetBtn.textContent = "reset";
  startBtn.addEventListener("click", () => {
    if (st.running) return;
    st.running = true;
    timer = window.setInterval(tick, 1000);
    draw();
  });
  pauseBtn.addEventListener("click", () => {
    st.running = false;
    if (timer) { window.clearInterval(timer); timer = undefined; }
    draw();
  });
  resetBtn.addEventListener("click", () => {
    st.running = false;
    if (timer) { window.clearInterval(timer); timer = undefined; }
    st.remain = (st.mode === "focus" ? st.workMin : st.breakMin) * 60;
    draw();
  });
  const workInp = document.createElement("input");
  workInp.type = "number";
  workInp.min = "1";
  workInp.value = String(st.workMin);
  workInp.className = "small";
  workInp.title = "focus minutes";
  const breakInp = document.createElement("input");
  breakInp.type = "number";
  breakInp.min = "1";
  breakInp.value = String(st.breakMin);
  breakInp.className = "small";
  breakInp.title = "break minutes";
  workInp.addEventListener("change", () => {
    st.workMin = Math.max(1, +workInp.value || 25);
    if (!st.running && st.mode === "focus") { st.remain = st.workMin * 60; draw(); }
  });
  breakInp.addEventListener("change", () => {
    st.breakMin = Math.max(1, +breakInp.value || 5);
    if (!st.running && st.mode === "break") { st.remain = st.breakMin * 60; draw(); }
  });
  const row = document.createElement("div");
  row.className = "row mt2";
  row.append(startBtn, pauseBtn, resetBtn);
  const cfg = document.createElement("div");
  cfg.className = "row mt1 small dim";
  cfg.append(document.createTextNode("focus "), workInp,
    document.createTextNode(" min · break "), breakInp,
    document.createTextNode(" min"));
  root.append(mode, clock, row, cfg);

  // presets
  const presets = document.createElement("div");
  presets.className = "row mt1";
  presets.style.flexWrap = "wrap";
  for (const [label, wm, bm] of [
    ["classic 25/5", 25, 5], ["deep 50/10", 50, 10],
    ["quick 15/5", 15, 5], ["long 90/20", 90, 20],
  ] as Array<[string, number, number]>) {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "btn small";
    b.textContent = label;
    b.addEventListener("click", () => {
      st.workMin = wm;
      st.breakMin = bm;
      workInp.value = String(wm);
      breakInp.value = String(bm);
      st.running = false;
      if (timer) { window.clearInterval(timer); timer = undefined; }
      st.remain = wm * 60;
      st.mode = "focus";
      draw();
    });
    presets.appendChild(b);
  }
  root.appendChild(presets);
  draw();
}

// ---------------- fuzzy finder ----------------
function renderFind(): void {
  const q = $("find-q") as HTMLInputElement;
  const out = $("find-out");
  let timer = 0;
  const KIND_LABEL: Record<string, string> = {
    space: "space", note: "note", test: "test", post: "post",
    comment: "comment", chat: "chat", event: "event", room: "room", user: "user",
  };
  q.addEventListener("input", () => {
    window.clearTimeout(timer);
    timer = window.setTimeout(run, 300);
  });
  q.addEventListener("keydown", (e) => {
    if (e.key === "Enter") { window.clearTimeout(timer); run(); }
  });
  const run = () => {
    const query = q.value.trim();
    if (!query) { out.innerHTML = ""; return; }
    out.innerHTML = '<div class="dim">searching…</div>';
    find(query).then((d) => {
      out.innerHTML = "";
      if (!d.results.length) {
        out.innerHTML = '<div class="dim">nothing found.</div>';
        return;
      }
      for (const r of d.results) {
        const row = document.createElement("div");
        row.className = "find-hit";
        const kind = document.createElement("span");
        kind.className = "find-kind";
        kind.textContent = KIND_LABEL[r.kind] || r.kind;
        const link = document.createElement("a");
        link.href = r.link;
        link.textContent = r.label;
        const snip = document.createElement("div");
        snip.className = "faint xs mono";
        snip.textContent = r.snippet;
        row.append(kind, link, snip);
        out.appendChild(row);
      }
    }).catch(() => { out.innerHTML = '<div class="error-box">search failed</div>'; });
  };
}

// ---------------- flashcards ----------------
let curDeck: any = null;
let curCard = 0;
let flipped = false;

function renderFlashcards(): void {
  const root = $("flash-root");
  root.innerHTML = "";
  const decks = room.decks || {};
  const keys = Object.keys(decks);

  const head = document.createElement("div");
  head.className = "row mb2";
  const sel = document.createElement("select");
  sel.className = "grow";
  const none = document.createElement("option");
  none.value = "";
  none.textContent = decks && keys.length ? "pick a deck" : "no decks yet";
  sel.appendChild(none);
  for (const k of keys) {
    const o = document.createElement("option");
    o.value = k;
    o.textContent = decks[k].name + " (" + decks[k].cards.length + ")";
    sel.appendChild(o);
  }
  head.appendChild(sel);
  if (mine) {
    const imp = document.createElement("button");
    imp.className = "btn small";
    imp.textContent = "import .txt";
    imp.addEventListener("click", () => { void importDeckModal(); });
    const mk = document.createElement("button");
    mk.className = "btn small";
    mk.textContent = "+ empty deck";
    mk.addEventListener("click", () => {
      const name = window.prompt("deck name?");
      if (!name) return;
      const did = "d" + Math.random().toString(36).slice(2, 10);
      const decksCopy = JSON.parse(JSON.stringify(room.decks || {}));
      decksCopy[did] = { id: did, name, cards: [] };
      saveSection("decks", decksCopy);
    });
    head.append(imp, mk);
  }
  root.appendChild(head);

  const body = document.createElement("div");
  body.id = "flash-body";
  root.appendChild(body);

  const drawCard = () => {
    body.innerHTML = "";
    if (!curDeck || !curDeck.cards.length) {
      body.innerHTML = mine
        ? '<div class="dim">no deck selected. import a .txt (or create an empty deck).</div>'
        : '<div class="dim">this room has no flashcards.</div>';
      return;
    }
    const cards = curDeck.cards;
    curCard = Math.min(curCard, cards.length - 1);
    const c = cards[curCard];
    const card = document.createElement("div");
    card.className = "flash-card";
    card.innerHTML = renderMarkdown(flipped ? c.back : c.front);
    card.addEventListener("click", () => { flipped = !flipped; drawCard(); });
    const meta = document.createElement("div");
    meta.className = "micro mt2 dim";
    meta.textContent = `${curCard + 1} / ${cards.length} · `
      + `${cards.filter((x: any) => x.known).length} known`
      + (flipped ? " · showing back" : " · click to flip");
    const btns = document.createElement("div");
    btns.className = "row mt1";
    const prev = document.createElement("button");
    prev.className = "btn small";
    prev.textContent = "◂";
    prev.addEventListener("click", () => {
      curCard = (curCard - 1 + cards.length) % cards.length;
      flipped = false;
      drawCard();
    });
    const next = document.createElement("button");
    next.className = "btn small";
    next.textContent = "▸";
    next.addEventListener("click", () => {
      curCard = (curCard + 1) % cards.length;
      flipped = false;
      drawCard();
    });
    const shuf = document.createElement("button");
    shuf.className = "btn small";
    shuf.textContent = "shuffle";
    shuf.addEventListener("click", () => {
      cards.sort(() => Math.random() - 0.5);
      curCard = 0;
      flipped = false;
      if (mine) saveSection("decks", room.decks);
      drawCard();
    });
    btns.append(prev, next, shuf);
    if (mine) {
      const known = document.createElement("button");
      known.className = "btn small" + (c.known ? " active" : "");
      known.textContent = c.known ? "known ✓" : "mark known";
      known.addEventListener("click", () => {
        c.known = !c.known;
        saveSection("decks", room.decks);
        drawCard();
      });
      const del = document.createElement("button");
      del.className = "btn small danger";
      del.textContent = "drop card";
      del.addEventListener("click", () => {
        cards.splice(curCard, 1);
        curCard = 0;
        flipped = false;
        saveSection("decks", room.decks);
        drawCard();
      });
      btns.append(known, del);
    }
    body.append(card, meta, btns);
  };
  sel.addEventListener("change", () => {
    curDeck = room.decks[sel.value] || null;
    curCard = 0;
    flipped = false;
    drawCard();
  });
  drawCard();
}

async function importDeckModal(): Promise<void> {
  const { root, close } = openModal(`
    <h2>import flashcards (.txt)</h2>
    <p class="dim small">same idea as tests: <a href="${cardTemplateUrl(room.id)}" target="_blank">download the template</a>,
    give it to an ai model, paste the result here.</p>
    <label class="field"><span class="lbl">deck name (optional, overrides # name:)</span>
      <input type="text" id="dk-name"></label>
    <textarea id="dk-txt" rows="12" spellcheck="false" placeholder="# name: Calc cards

front: derivative of sin(x)
back: cos(x)"></textarea>
    <div class="error-box hidden" id="dk-error"></div>
    <div class="actions">
      <button class="btn" id="dk-cancel">cancel</button>
      <button class="btn primary" id="dk-go">import</button>
    </div>`);
  root.querySelector("#dk-cancel")!.addEventListener("click", close);
  root.querySelector("#dk-go")!.addEventListener("click", async () => {
    try {
      const d = await importDeck(room.id,
        (root.querySelector("#dk-txt") as HTMLTextAreaElement).value,
        (root.querySelector("#dk-name") as HTMLInputElement).value.trim());
      room = d.room;
      renderFlashcards();
      close();
    } catch (e) {
      const b = root.querySelector("#dk-error") as HTMLElement;
      b.textContent = (e as Error).message;
      b.classList.remove("hidden");
    }
  });
}

// ---------------- to-do lists ----------------
function renderTodos(): void {
  const root = $("todo-root");
  root.innerHTML = "";
  const todos: any[] = room.todos || [];
  const draw = () => {
    root.innerHTML = "";
    for (const lst of todos) {
      const box = document.createElement("div");
      box.className = "panel mb2";
      const head = document.createElement("div");
      head.className = "row mb1";
      const name = document.createElement("strong");
      name.textContent = lst.name || "list";
      head.appendChild(name);
      if (mine) {
        const del = document.createElement("button");
        del.className = "btn small danger";
        del.textContent = "x";
        del.title = "delete list";
        del.addEventListener("click", () => {
          todos.splice(todos.indexOf(lst), 1);
          saveSection("todos", todos);
        });
        head.appendChild(del);
      }
      box.appendChild(head);
      for (const it of lst.items || []) {
        const row = document.createElement("div");
        row.className = "row mb1";
        const cb = document.createElement("input");
        cb.type = "checkbox";
        cb.checked = !!it.done;
        cb.disabled = !mine;
        cb.addEventListener("change", () => {
          it.done = cb.checked;
          saveSection("todos", todos);
        });
        const label = document.createElement("span");
        label.className = "grow" + (it.done ? " dim" : "");
        label.textContent = it.text;
        if (it.done) label.style.textDecoration = "line-through";
        row.append(cb, label);
        if (mine) {
          const del = document.createElement("button");
          del.className = "btn small danger";
          del.textContent = "x";
          del.addEventListener("click", () => {
            lst.items.splice(lst.items.indexOf(it), 1);
            saveSection("todos", todos);
          });
          row.appendChild(del);
        }
        box.appendChild(row);
      }
      if (mine) {
        const addRow = document.createElement("div");
        addRow.className = "row";
        const inp = document.createElement("input");
        inp.type = "text";
        inp.className = "grow small";
        inp.placeholder = "add item…";
        const go = document.createElement("button");
        go.className = "btn small";
        go.textContent = "+";
        const add = () => {
          const text = inp.value.trim();
          if (!text) return;
          lst.items = lst.items || [];
          lst.items.push({ id: "i" + Math.random().toString(36).slice(2, 10),
            text, done: false });
          saveSection("todos", todos);
          inp.value = "";
        };
        go.addEventListener("click", add);
        inp.addEventListener("keydown", (e) => { if (e.key === "Enter") add(); });
        addRow.append(inp, go);
        box.appendChild(addRow);
      }
      root.appendChild(box);
    }
    if (mine) {
      const addList = document.createElement("div");
      addList.className = "row";
      const inp = document.createElement("input");
      inp.type = "text";
      inp.className = "grow small";
      inp.placeholder = "new list name…";
      const go = document.createElement("button");
      go.className = "btn small primary";
      go.textContent = "+ list";
      const add = () => {
        const name = inp.value.trim();
        if (!name) return;
        todos.push({ id: "l" + Math.random().toString(36).slice(2, 10),
          name, items: [] });
        saveSection("todos", todos);
        inp.value = "";
      };
      go.addEventListener("click", add);
      inp.addEventListener("keydown", (e) => { if (e.key === "Enter") add(); });
      addList.append(inp, go);
      root.appendChild(addList);
    }
    if (!todos.length && !mine) {
      root.innerHTML = '<div class="dim">nothing on the to-do lists.</div>';
    }
  };
  draw();
}

// ---------------- graph calculator ----------------
const FUNCS: Record<string, (v: number) => number> = {
  sin: Math.sin, cos: Math.cos, tan: Math.tan,
  asin: Math.asin, acos: Math.acos, atan: Math.atan,
  sqrt: Math.sqrt, abs: Math.abs, log: Math.log10, ln: Math.log,
  exp: Math.exp, floor: Math.floor, ceil: Math.ceil,
};
const CONSTS: Record<string, number> = { pi: Math.PI, e: Math.E };

function compileExpr(src: string): (x: number) => number {
  let i = 0;
  const peek = () => src[i] || "";
  const ws = () => { while (src[i] === " " || src[i] === "\t") i++; };
  const expr = (): ((x: number) => number) => {
    let left = term();
    for (;;) {
      ws();
      const c = peek();
      if (c === "+") { i++; const r = term(); const l = left; left = (x) => l(x) + r(x); }
      else if (c === "-") { i++; const r = term(); const l = left; left = (x) => l(x) - r(x); }
      else break;
    }
    return left;
  };
  const term = (): ((x: number) => number) => {
    let left = pow();
    for (;;) {
      ws();
      const c = peek();
      if (c === "*") { i++; const r = pow(); const l = left; left = (x) => l(x) * r(x); }
      else if (c === "/") { i++; const r = pow(); const l = left; left = (x) => l(x) / r(x); }
      else break;
    }
    return left;
  };
  const pow = (): ((x: number) => number) => {
    const base = unary();
    ws();
    if (peek() === "^") { i++; const e = pow(); return (x) => Math.pow(base(x), e(x)); }
    return base;
  };
  const unary = (): ((x: number) => number) => {
    ws();
    if (peek() === "-") { i++; const a = unary(); return (x) => -a(x); }
    if (peek() === "+") { i++; return unary(); }
    return atom();
  };
  const atom = (): ((x: number) => number) => {
    ws();
    const c = peek();
    if (c === "(") { i++; const e = expr(); ws(); if (peek() === ")") i++; return e; }
    if (c === "x") { i++; return (x) => x; }
    if (/[0-9.]/.test(c)) {
      let num = "";
      while (/[0-9.]/.test(peek())) num += src[i++];
      const v = parseFloat(num);
      return () => v;
    }
    const m = src.slice(i).match(/^[a-zA-Z]+/);
    if (m) {
      const name = m[0];
      i += name.length;
      const lower = name.toLowerCase();
      if (lower in FUNCS) {
        ws(); if (peek() === "(") i++;
        const a = expr(); ws(); if (peek() === ")") i++;
        return (x) => FUNCS[lower](a(x));
      }
      if (lower in CONSTS) return () => CONSTS[lower];
    }
    throw new Error("cannot parse: " + src.slice(Math.max(0, i - 4), i + 8));
  };
  const f = expr();
  ws();
  if (i < src.length) throw new Error("unexpected: " + src.slice(i, i + 10));
  return f;
}

function renderGraph(): void {
  const root = $("graph-root");
  root.innerHTML = "";
  const fns: Array<{ expr: string; color: string; f: (x: number) => number }> = [];
  let xmin = -10, xmax = 10;
  const canvas = document.createElement("canvas");
  canvas.width = 700;
  canvas.height = 320;
  canvas.className = "chart-box";
  root.appendChild(canvas);
  const ctx = canvas.getContext("2d")!;

  const drawChart = () => {
    const w = canvas.width, h = canvas.height;
    ctx.fillStyle = getComputedStyle(document.body).getPropertyValue("--bg-inset").trim() || "#ffffff";
    ctx.fillRect(0, 0, w, h);
    const X = (v: number) => ((v - xmin) / (xmax - xmin)) * w;
    ctx.strokeStyle = "rgba(128,138,150,.35)";
    ctx.lineWidth = 1;
    ctx.font = "10px monospace";
    for (let g = 0; g <= 10; g++) {
      const vx = xmin + (xmax - xmin) * g / 10;
      ctx.beginPath();
      ctx.moveTo(X(vx), 0); ctx.lineTo(X(vx), h);
      ctx.stroke();
      ctx.fillStyle = "rgba(128,138,150,.9)";
      ctx.fillText(vx.toFixed(1), X(vx) + 2, 10);
    }
    const samples = 500;
    const vals: number[][] = [];
    let ymin = Infinity, ymax = -Infinity;
    for (const fn of fns) {
      const pts: number[] = [];
      for (let s = 0; s <= samples; s++) {
        const x = xmin + (xmax - xmin) * s / samples;
        let y = NaN;
        try { y = fn.f(x); } catch { /* undefined here */ }
        if (isFinite(y)) {
          y = Math.max(-1e6, Math.min(1e6, y));
          ymin = Math.min(ymin, y); ymax = Math.max(ymax, y);
        }
        pts.push(y);
      }
      vals.push(pts);
    }
    if (!isFinite(ymin)) { ymin = -10; ymax = 10; }
    if (ymax - ymin < 1e-9) { ymax += 1; ymin -= 1; }
    const Y = (v: number) => h - ((v - ymin) / (ymax - ymin)) * h;
    for (let g = 0; g <= 8; g++) {
      const vy = ymin + (ymax - ymin) * g / 8;
      ctx.strokeStyle = "rgba(128,138,150,.35)";
      ctx.beginPath();
      ctx.moveTo(0, Y(vy)); ctx.lineTo(w, Y(vy));
      ctx.stroke();
      ctx.fillStyle = "rgba(128,138,150,.9)";
      ctx.fillText(vy.toFixed(1), 2, Y(vy) - 2);
    }
    fns.forEach((fn, fi) => {
      ctx.strokeStyle = fn.color;
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      let started = false;
      for (let s = 0; s <= samples; s++) {
        const y = vals[fi][s];
        const x = xmin + (xmax - xmin) * s / samples;
        if (isNaN(y)) { started = false; continue; }
        if (!started) { ctx.moveTo(X(x), Y(y)); started = true; }
        else ctx.lineTo(X(x), Y(y));
      }
      ctx.stroke();
    });
  };

  const list = document.createElement("div");
  list.className = "mt2";
  root.appendChild(list);
  const drawList = () => {
    list.innerHTML = "";
    fns.forEach((fn, i) => {
      const row = document.createElement("div");
      row.className = "row mb1";
      const chip = document.createElement("span");
      chip.className = "cal-dot";
      chip.style.background = fn.color;
      const label = document.createElement("span");
      label.className = "grow small mono";
      label.textContent = "y = " + fn.expr;
      row.append(chip, label);
      if (mine) {
        const del = document.createElement("button");
        del.className = "btn small danger";
        del.textContent = "x";
        del.addEventListener("click", () => {
          fns.splice(i, 1);
          drawList();
          drawChart();
        });
        row.appendChild(del);
      }
      list.appendChild(row);
    });
  };

  if (mine) {
    const form = document.createElement("div");
    form.className = "row mt1";
    const inp = document.createElement("input");
    inp.type = "text";
    inp.className = "grow small";
    inp.placeholder = "f(x), e.g. sin(x)*x or x^2 - 3";
    const add = document.createElement("button");
    add.className = "btn small primary";
    add.textContent = "+ plot";
    const err = document.createElement("div");
    err.className = "error-box hidden";
    form.append(inp, add);
    root.appendChild(form);
    root.appendChild(err);
    const tryAdd = () => {
      const exprStr = inp.value.trim();
      if (!exprStr) return;
      try {
        const f = compileExpr(exprStr);
        fns.push({ expr: exprStr, color: POSTIT_COLORS[fns.length % POSTIT_COLORS.length], f });
        inp.value = "";
        err.classList.add("hidden");
        drawList();
        drawChart();
      } catch (e) {
        err.textContent = (e as Error).message;
        err.classList.remove("hidden");
      }
    };
    add.addEventListener("click", tryAdd);
    inp.addEventListener("keydown", (e) => { if (e.key === "Enter") tryAdd(); });
    const zoomRow = document.createElement("div");
    zoomRow.className = "row mt1";
    for (const [label, act] of [
      ["zoom in", () => { const mid = (xmin + xmax) / 2; const half = (xmax - xmin) / 4; xmin = mid - half; xmax = mid + half; drawChart(); }],
      ["zoom out", () => { const mid = (xmin + xmax) / 2; const half = (xmax - xmin); xmin = mid - half; xmax = mid + half; drawChart(); }],
      ["reset", () => { xmin = -10; xmax = 10; drawChart(); }],
    ] as Array<[string, () => void]>) {
      const b = document.createElement("button");
      b.className = "btn small";
      b.textContent = label;
      b.addEventListener("click", act);
      zoomRow.appendChild(b);
    }
    root.appendChild(zoomRow);
  }
  if (!mine && fns.length === 0) {
    list.innerHTML = '<div class="dim">no functions plotted.</div>';
  }
  drawList();
  drawChart();
}

// ---------------- post-its ----------------
function renderPostits(): void {
  const zone = $("postit-zone");
  zone.innerHTML = "";
  const postits: any[] = room.postits || [];
  const zoneEl = zone;
  let dragIdx = -1;
  let offX = 0, offY = 0;

  const draw = () => {
    zoneEl.querySelectorAll(".postit").forEach((p) => p.remove());
    for (const p of postits) {
      const el = document.createElement("div");
      el.className = "postit";
      el.style.background = p.color;
      el.style.left = p.x + "px";
      el.style.top = p.y + "px";
      el.style.color = "#111318";
      el.textContent = p.text;
      el.title = mine ? "drag to move · double-click to edit" : "";
      if (mine) {
        el.addEventListener("pointerdown", (e) => {
          const rect = el.getBoundingClientRect();
          const zoneRect = zoneEl.getBoundingClientRect();
          dragIdx = postits.indexOf(p);
          offX = e.clientX - rect.left;
          offY = e.clientY - rect.top;
          el.setPointerCapture(e.pointerId);
          el.style.cursor = "grabbing";
        });
        el.addEventListener("pointermove", (e) => {
          if (dragIdx < 0) return;
          const zoneRect = zoneEl.getBoundingClientRect();
          const x = Math.max(0, Math.min(zoneRect.width - 40, e.clientX - zoneRect.left - offX));
          const y = Math.max(0, Math.min(zoneRect.height - 30, e.clientY - zoneRect.top - offY));
          p.x = Math.round(x);
          p.y = Math.round(y);
          el.style.left = p.x + "px";
          el.style.top = p.y + "px";
        });
        const end = () => {
          if (dragIdx >= 0) {
            dragIdx = -1;
            el.style.cursor = "grab";
            saveSection("postits", postits);
          }
        };
        el.addEventListener("pointerup", end);
        el.addEventListener("pointercancel", end);
        el.addEventListener("dblclick", () => {
          const val = window.prompt("post-it text:", p.text);
          if (val === null) return;
          p.text = val;
          saveSection("postits", postits);
          draw();
        });
        const actions = document.createElement("div");
        actions.className = "pi-actions";
        const col = document.createElement("button");
        col.className = "btn small";
        col.textContent = "◐";
        col.title = "cycle color";
        col.addEventListener("click", () => {
          p.color = POSTIT_COLORS[(POSTIT_COLORS.indexOf(p.color) + 1) % POSTIT_COLORS.length];
          saveSection("postits", postits);
          draw();
        });
        const del = document.createElement("button");
        del.className = "btn small danger";
        del.textContent = "x";
        del.title = "delete post-it";
        del.addEventListener("click", () => {
          postits.splice(postits.indexOf(p), 1);
          saveSection("postits", postits);
          draw();
        });
        actions.append(col, del);
        el.appendChild(actions);
      }
      zoneEl.appendChild(el);
    }
    if (mine) {
      const addBtn = document.createElement("button");
      addBtn.className = "btn small";
      addBtn.style.position = "absolute";
      addBtn.style.left = "8px";
      addBtn.style.bottom = "8px";
      addBtn.textContent = "+ post-it";
      addBtn.addEventListener("click", () => {
        postits.push({ id: "p" + Math.random().toString(36).slice(2, 10),
          x: 20 + Math.random() * 120, y: 20 + Math.random() * 120,
          color: POSTIT_COLORS[postits.length % POSTIT_COLORS.length], text: "" });
        saveSection("postits", postits);
        draw();
      });
      zoneEl.appendChild(addBtn);
    }
  };
  draw();
}

// ---------------- annotate editor ----------------
function renderEditor(): void {
  const root = $("editor-root");
  root.innerHTML = "";
  const notes: any[] = room.notes || [];
  let curId: string | null = notes.length ? notes[0].id : null;

  const preview = document.createElement("div");
  preview.className = "note-body preview mb2";
  const ta = document.createElement("textarea");
  ta.rows = 8;
  ta.spellcheck = false;
  ta.placeholder = "write and annotate… select text and use == to highlight it";
  const errBox = document.createElement("div");
  errBox.className = "error-box hidden";
  const toolbar = document.createElement("div");
  toolbar.className = "row mb1";
  const wrap = (a: string, b: string) => {
    const s = ta.selectionStart, e = ta.selectionEnd;
    const sel = ta.value.slice(s, e);
    ta.value = ta.value.slice(0, s) + a + sel + b + ta.value.slice(e);
    ta.focus();
    ta.selectionStart = s + a.length;
    ta.selectionEnd = s + a.length + sel.length;
    update();
  };
  for (const [label, a, b] of [
    ["bold", "**", "**"], ["italic", "*", "*"], ["code", "`", "`"],
    ["highlight", "==", "=="], ["math", "$", "$"],
  ] as Array<[string, string, string]>) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "btn small";
    btn.textContent = label;
    btn.addEventListener("click", () => wrap(a, b));
    toolbar.appendChild(btn);
  }

  const update = () => {
    if (!mine) return;
    preview.innerHTML = renderMarkdown(ta.value);
  };

  const draw = () => {
    root.innerHTML = "";
    if (!mine) {
      if (!notes.length) {
        root.innerHTML = '<div class="dim">no annotations.</div>';
        return;
      }
      for (const n of notes) {
        const box = document.createElement("div");
        box.className = "panel mb2";
        box.innerHTML = renderMarkdown(n.text);
        root.appendChild(box);
      }
      return;
    }
    const head = document.createElement("div");
    head.className = "row mb1";
    const sel = document.createElement("select");
    sel.className = "grow";
    for (const n of notes) {
      const o = document.createElement("option");
      o.value = n.id;
      o.textContent = (n.text || "(empty note)").slice(0, 40) || "empty note";
      sel.appendChild(o);
    }
    if (!notes.length) {
      const o = document.createElement("option");
      o.value = "";
      o.textContent = "no notes yet";
      sel.appendChild(o);
    }
    sel.value = curId || "";
    head.appendChild(sel);
    const mk = document.createElement("button");
    mk.className = "btn small";
    mk.textContent = "+ note";
    mk.addEventListener("click", () => {
      const n = { id: "n" + Math.random().toString(36).slice(2, 10), text: "", updated: Date.now() / 1000 };
      notes.push(n);
      curId = n.id;
      draw();
    });
    const del = document.createElement("button");
    del.className = "btn small danger";
    del.textContent = "delete note";
    del.addEventListener("click", () => {
      const i = notes.findIndex((x) => x.id === curId);
      if (i >= 0) {
        notes.splice(i, 1);
        curId = notes.length ? notes[0].id : null;
        draw();
      }
    });
    head.append(mk, del);
    root.appendChild(head);

    const cur = notes.find((x) => x.id === curId) || null;
    ta.value = cur ? cur.text : "";
    preview.innerHTML = renderMarkdown(ta.value);
    root.append(toolbar, ta, preview, errBox);

    const saveBtn = document.createElement("button");
    saveBtn.className = "btn primary mt1";
    saveBtn.textContent = "save note";
    saveBtn.addEventListener("click", () => {
      if (!cur) return;
      cur.text = ta.value;
      cur.updated = Date.now() / 1000;
      saveSection("notes", notes);
      draw();
    });
    root.appendChild(saveBtn);

    sel.addEventListener("change", () => { curId = sel.value; draw(); });
    ta.addEventListener("input", update);
  };
  draw();
}

boot();
