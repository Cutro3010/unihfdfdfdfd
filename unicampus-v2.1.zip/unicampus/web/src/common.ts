// Shared UI helpers: theme, notifications bell, user area, modals, time.

import { api, getToken, setToken, me, notifications, notificationsRead, User } from "./api.js";

// ---------------- theme ----------------
export function currentTheme(): string {
  return document.documentElement.getAttribute("data-theme") || "dark";
}

export function applyTheme(t: string): void {
  document.documentElement.setAttribute("data-theme", t);
  try { localStorage.setItem("uni-theme", t); } catch { /* ignore */ }
  const st = document.getElementById("st-theme");
  if (st) st.textContent = t;
}

export function initTheme(): void {
  const btn = document.getElementById("theme-btn");
  if (!btn) return;
  btn.textContent = "theme: " + currentTheme();
  btn.addEventListener("click", () => {
    applyTheme(currentTheme() === "dark" ? "light" : "dark");
    btn.textContent = "theme: " + currentTheme();
  });
}

// ---------------- user area ----------------
export async function initUserArea(): Promise<User | null> {
  const area = document.getElementById("user-area");
  let user: User | null = null;
  try {
    user = await me();
  } catch { /* offline */ }
  if (user) initChatBadge();
  if (!area) return user;
  if (user) {
    area.innerHTML = "";
    const who = document.createElement("a");
    who.className = "mono small";
    who.href = "/user.html?name=" + encodeURIComponent(user.username);
    who.textContent = "@" + user.username;
    const out = document.createElement("button");
    out.className = "btn small";
    out.textContent = "logout";
    out.addEventListener("click", async () => {
      try { await api("logout", { method: "POST" }); } catch { /* ignore */ }
      setToken("");
      location.href = "/";
    });
    area.append(who, out);
  } else {
    const b = document.createElement("button");
    b.className = "btn small";
    b.textContent = "login";
    b.addEventListener("click", () => location.href = "/");
    area.replaceChildren(b);
  }
  const st = document.getElementById("st-user");
  if (st) st.textContent = user ? user.username : "guest";
  return user;
}

// ---------------- notifications bell ----------------
let unreadCount = 0;

async function loadNotifications(): Promise<void> {
  const dd = document.getElementById("bell-dd");
  const badge = document.getElementById("bell-badge");
  if (!dd || !badge) return;
  let data: any;
  try {
    data = await notifications();
  } catch {
    return;
  }
  unreadCount = data.unread;
  badge.textContent = String(unreadCount);
  badge.classList.toggle("hidden", unreadCount === 0);
  const list: any[] = data.notifications || [];
  dd.innerHTML = "";
  if (list.length === 0) {
    const e = document.createElement("div");
    e.className = "dd-empty";
    e.textContent = "no notifications";
    dd.appendChild(e);
    return;
  }
  for (const n of list) {
    const it = document.createElement("div");
    it.className = "dd-item" + (n.read ? "" : " dd-unread");
    const link = document.createElement("a");
    link.href = n.space
      ? `/space.html?id=${n.space}&path=${encodeURIComponent(n.path || "")}${n.anchor || ""}`
      : "/";
    if (n.type === "mention") {
      link.textContent = `@${n.actor} mentioned you in ${n.space_name} · ${n.path}`;
    } else if (n.type === "reply") {
      link.textContent = `@${n.actor} replied to your comment in ${n.space_name} · ${n.path}`;
    } else if (n.type === "share") {
      link.textContent = `@${n.actor} shared ${n.space_name} with you (viewer)`;
    } else if (n.type === "event" || n.type === "event_soon" || n.type === "event_today") {
      link.href = "/calendar.html";
      link.textContent = `calendar · ${n.text}`;
    } else if (n.type === "deadline_today" || n.type === "deadline_soon") {
      link.textContent = `reminder · ${n.space_name} · ${n.text}`;
    } else {
      link.textContent = `@${n.actor}: ${n.text}`;
    }
    it.appendChild(link);
    dd.appendChild(it);
  }
}

export function initBell(): void {
  const btn = document.getElementById("bell-btn");
  const dd = document.getElementById("bell-dd");
  if (!btn || !dd) return;
  btn.addEventListener("click", async () => {
    const wasHidden = dd.classList.contains("hidden");
    dd.classList.toggle("hidden");
    if (!wasHidden) return;
    await loadNotifications();
    const ids = await notifications().then((d) => (d.notifications || []).map((n: any) => n.id)).catch(() => []);
    if (ids.length) await notificationsRead(ids).catch(() => {});
    const badge = document.getElementById("bell-badge");
    if (badge) badge.classList.add("hidden");
  });
  document.addEventListener("click", (e) => {
    if (!btn.contains(e.target as Node) && !dd.contains(e.target as Node)) {
      dd.classList.add("hidden");
    }
  });
  loadNotifications();
  setInterval(loadNotifications, 30000);
}

// ---------------- global chat unread badge ----------------
// Lives in the topbar nav on every page: polls the chat list so new
// private messages are visible without reloading anything.
let chatBadgeTimer: number | undefined;

async function refreshChatBadge(): Promise<void> {
  const badge = document.getElementById("chat-badge");
  if (!badge) return;
  let d: any;
  try {
    d = await api("chats");
  } catch {
    return;
  }
  const total = (d.chats || []).reduce((n: number, c: any) => n + (c.unread || 0), 0);
  badge.textContent = String(total);
  badge.classList.toggle("hidden", total === 0);
}

export function initChatBadge(): void {
  if (chatBadgeTimer !== undefined) return;
  void refreshChatBadge();
  chatBadgeTimer = window.setInterval(() => { void refreshChatBadge(); }, 15000);
}

// ---------------- modals ----------------
export function openModal(html: string, wide = false): { root: HTMLElement; close: () => void } {
  const mount = document.getElementById("modal-root")!;
  const backdrop = document.createElement("div");
  backdrop.className = "modal-backdrop";
  const box = document.createElement("div");
  box.className = "modal" + (wide ? " modal-wide" : "");
  box.innerHTML = html;
  backdrop.appendChild(box);
  mount.appendChild(backdrop);
  const close = () => backdrop.remove();
  backdrop.addEventListener("click", (e) => { if (e.target === backdrop) close(); });
  document.addEventListener("keydown", function onEsc(e: KeyboardEvent) {
    if (e.key === "Escape") { close(); document.removeEventListener("keydown", onEsc); }
  });
  return { root: box, close };
}

// ---------------- time ----------------
export function fmtTime(t: number): string {
  if (!t) return "-";
  const d = Date.now() / 1000 - t;
  if (d < 60) return "just now";
  if (d < 3600) return `${Math.floor(d / 60)}m ago`;
  if (d < 86400) return `${Math.floor(d / 3600)}h ago`;
  if (d < 86400 * 30) return `${Math.floor(d / 86400)}d ago`;
  return new Date(t * 1000).toLocaleDateString();
}

export function fmtDur(sec: number): string {
  sec = Math.max(0, Math.floor(sec));
  if (sec < 60) return `${sec}s`;
  if (sec < 3600) return `${Math.floor(sec / 60)}m ${sec % 60}s`;
  return `${Math.floor(sec / 3600)}h ${Math.floor((sec % 3600) / 60)}m`;
}

export function fmtDate(t: number): string {
  return new Date(t * 1000).toLocaleDateString(undefined,
    { weekday: "short", month: "short", day: "numeric" });
}

export function fmtDateTime(t: number): string {
  return new Date(t * 1000).toLocaleString(undefined,
    { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

// ---------------- deadlines ----------------
export const DAY = 86400;

export function dueState(due: number, now: number): string {
  if (now > due + DAY) return "overdue";
  if (now > due) return "today";
  if (now > due - DAY) return "soon";
  return "far";
}

export function dueLabel(due: number, now: number): string {
  if (now > due + DAY) return "overdue";
  if (now > due) return "due today";
  if (now > due - DAY) return `due in ${Math.ceil((due - now) / 3600)}h`;
  return `due in ${Math.ceil((due - now) / DAY)}d`;
}

// ---------------- @mention autocomplete ----------------
export function wireMentionAutocomplete(ta: HTMLTextAreaElement): void {
  const wrap = document.createElement("div");
  wrap.className = "dd-rel";
  ta.parentElement!.insertBefore(wrap, ta);
  wrap.appendChild(ta);
  const dd = document.createElement("div");
  dd.className = "dropdown mention hidden";
  wrap.appendChild(dd);
  ta.addEventListener("input", () => {
    const pos = ta.selectionStart;
    const m = ta.value.slice(0, pos).match(/@([A-Za-z0-9_-]{0,32})$/);
    if (!m || !m[0]) { dd.classList.add("hidden"); return; }
    api(`users?prefix=${encodeURIComponent(m[1])}`).then((d) => {
      const list: string[] = d.users;
      dd.innerHTML = "";
      if (!list.length) { dd.classList.add("hidden"); return; }
      for (const name of list.slice(0, 8)) {
        const it = document.createElement("div");
        it.className = "dd-item";
        it.textContent = "@" + name;
        it.addEventListener("mousedown", (e) => {
          e.preventDefault();
          insertMention(ta, name);
          dd.classList.add("hidden");
        });
        dd.appendChild(it);
      }
      dd.classList.remove("hidden");
    }).catch(() => { /* ignore */ });
  });
  document.addEventListener("click", (e) => {
    if (!wrap.contains(e.target as Node)) dd.classList.add("hidden");
  });
}

function insertMention(ta: HTMLTextAreaElement, name: string): void {
  const pos = ta.selectionStart;
  const before = ta.value.slice(0, pos);
  const m = before.match(/@[A-Za-z0-9_-]*$/);
  if (!m) return;
  const start = pos - m[0].length;
  const after = ta.value.slice(pos);
  ta.value = before.slice(0, start) + "@" + name + " " + after;
  ta.selectionStart = ta.selectionEnd = start + name.length + 2;
  ta.focus();
}
