// Exercises page: list tests, build tests (form or .txt import), take them
// with a timer, see results and per-test scoreboards.

import {
  listTests, getTest, createTest, importTestTxt, deleteTest, submitTest,
  getTestResults, testTemplateUrl, testExportUrl, downloadFile, getLeaderboard,
  TestSummary, User, api,
} from "./api.js";
import { renderMarkdown, esc } from "./render.js";
import {
  initTheme, initBell, initUserArea, fmtTime, fmtDur, fmtDate, fmtDateTime, openModal,
} from "./common.js";

let user: User | null = null;
let subject = "";
let tag = "";
let query = "";

const $ = (id: string) => document.getElementById(id)!;

// ---------------- boot ----------------
async function boot(): Promise<void> {
  initTheme();
  initBell();
  user = await initUserArea();
  wireTop();
  await loadTests();
}

function wireTop(): void {
  const q = $("t-search") as HTMLInputElement;
  q.addEventListener("keydown", (e) => {
    if (e.key === "Enter") { query = q.value.trim(); void loadTests(); }
  });
  const sel = $("t-subject") as HTMLSelectElement;
  sel.addEventListener("change", () => { subject = sel.value; void loadTests(); });
  $("t-new").addEventListener("click", () => {
    if (!user) { alert("login first"); return; }
    void newTestModal();
  });
}

// ---------------- list ----------------
async function loadTests(): Promise<void> {
  const grid = $("t-grid");
  grid.innerHTML = '<div class="dim">loading…</div>';
  let tests: TestSummary[];
  try {
    tests = (await listTests(query, subject, tag)).tests;
  } catch (e) {
    grid.innerHTML = `<div class="error-box">${esc((e as Error).message)}</div>`;
    return;
  }
  await renderSubjects(tests);
  await renderTags();
  grid.innerHTML = "";
  if (!tests.length) {
    grid.innerHTML = '<div class="dim">no tests yet — create one, or import an ai-made .txt.</div>';
    return;
  }
  for (const t of tests) {
    const card = document.createElement("div");
    card.className = "test-card";

    const head = document.createElement("div");
    head.className = "row";
    const title = document.createElement("span");
    title.className = "tc-title grow";
    title.textContent = t.title;
    const owner = document.createElement("a");
    owner.className = "dim small";
    owner.href = "/user.html?name=" + encodeURIComponent(t.owner);
    owner.textContent = "@" + t.owner;
    head.append(title, owner);
    card.appendChild(head);

    if (t.subject) {
      const subj = document.createElement("div");
      subj.className = "tc-subject";
      subj.textContent = t.subject;
      card.appendChild(subj);
    }
    if (t.description) {
      const desc = document.createElement("div");
      desc.className = "dim small";
      desc.textContent = t.description;
      card.appendChild(desc);
    }
    if (t.tags.length) {
      const tags = document.createElement("div");
      for (const tg of t.tags) {
        const pill = document.createElement("span");
        pill.className = "tag";
        pill.textContent = "#" + tg;
        pill.addEventListener("click", () => { tag = tg; void loadTests(); });
        tags.appendChild(pill);
      }
      card.appendChild(tags);
    }

    const meta = document.createElement("div");
    meta.className = "tc-meta dim small mono";
    meta.textContent = `${t.n_questions} question(s) · ${t.completions} completion(s)`
      + (t.avg_correct !== null ? ` · avg ${t.avg_correct}/${t.n_questions}` : "")
      + (t.public ? " · public" : " · private");
    card.appendChild(meta);

    const actions = document.createElement("div");
    actions.className = "tc-actions";
    const take = document.createElement("button");
    take.className = "btn primary";
    take.textContent = user ? "take" : "login to take";
    take.disabled = !user;
    take.addEventListener("click", () => { void takeTest(t.id); });
    actions.appendChild(take);
    const res = document.createElement("button");
    res.className = "btn small";
    res.textContent = "results";
    res.addEventListener("click", () => { void resultsModal(t.id); });
    actions.appendChild(res);
    if (user && t.owner === user.username) {
      const ex = document.createElement("button");
      ex.className = "btn small";
      ex.textContent = "export .txt";
      ex.addEventListener("click", () => {
        downloadFile(testExportUrl(t.id), t.title + ".txt").catch((e) => alert((e as Error).message));
      });
      actions.appendChild(ex);
      const del = document.createElement("button");
      del.className = "btn small danger";
      del.textContent = "delete";
      del.addEventListener("click", () => {
        if (!window.confirm(`delete test "${t.title}"? results are removed too.`)) return;
        deleteTest(t.id).then(() => loadTests()).catch((e) => alert((e as Error).message));
      });
      actions.appendChild(del);
    }
    card.appendChild(actions);
    grid.appendChild(card);
  }
}

async function renderSubjects(tests: TestSummary[]): Promise<void> {
  const sel = $("t-subject") as HTMLSelectElement;
  const subjects = new Set<string>();
  for (const t of tests) if (t.subject) subjects.add(t.subject);
  const cur = sel.value;
  sel.innerHTML = '<option value="">all subjects</option>';
  for (const s of Array.from(subjects).sort()) {
    const o = document.createElement("option");
    o.value = s;
    o.textContent = s;
    sel.appendChild(o);
  }
  sel.value = cur || subject || "";
}

async function renderTags(): Promise<void> {
  const box = $("t-tags");
  box.innerHTML = "";
  let tests: TestSummary[];
  try {
    tests = (await listTests("", "", "")).tests;
  } catch { return; }
  const counts = new Map<string, number>();
  for (const t of tests) for (const tg of t.tags) counts.set(tg, (counts.get(tg) || 0) + 1);
  for (const [tg, n] of Array.from(counts.entries()).sort((a, b) => b[1] - a[1]).slice(0, 24)) {
    const pill = document.createElement("span");
    pill.className = "tag" + (tag === tg ? " active" : "");
    pill.textContent = `#${tg} (${n})`;
    pill.addEventListener("click", () => { tag = tag === tg ? "" : tg; void loadTests(); });
    box.appendChild(pill);
  }
}

// ---------------- create (builder + txt import) ----------------
function newTestModal(): void {
  const { root, close } = openModal(`
    <h2>new test</h2>
    <div class="tab-row">
      <button class="tab active" id="nt-tab-form">builder</button>
      <button class="tab" id="nt-tab-txt">import .txt (ai preset)</button>
    </div>
    <div id="nt-form">
      <label class="field"><span class="lbl">title</span>
        <input type="text" id="nt-title"></label>
      <div class="row">
        <label class="field grow"><span class="lbl">subject (optional)</span>
          <input type="text" id="nt-subject" placeholder="math"></label>
        <label class="field grow"><span class="lbl">tags (comma separated)</span>
          <input type="text" id="nt-tags"></label>
      </div>
      <label class="field"><span class="lbl">description (optional)</span>
        <input type="text" id="nt-desc"></label>
      <label class="row small"><input type="checkbox" id="nt-public" checked>
        <span>public (any logged-in user can take it)</span></label>
      <div id="nt-qs"></div>
      <button class="btn small" id="nt-addq">+ question</button>
    </div>
    <div id="nt-txt" class="hidden">
      <p class="dim small">paste a test in the uniheaven .txt format. you can give this
      format to an ai model and ask it to generate questions for you.
      <a href="${testTemplateUrl}" target="_blank">download the template</a> to see it
      (or copy the example below).</p>
      <textarea id="nt-paste" rows="14" spellcheck="false" placeholder="# title: ...
Q1 (mc)
a question?
- wrong
+ right
"></textarea>
    </div>
    <div class="error-box hidden" id="nt-error"></div>
    <div class="actions">
      <button class="btn" id="nt-cancel">cancel</button>
      <button class="btn primary" id="nt-go">create</button>
    </div>`, true);

  const qbox = root.querySelector("#nt-qs")!;
  const qs: HTMLElement[] = [];

  const addQuestion = () => {
    const q = document.createElement("div");
    q.className = "q-editor";
    q.innerHTML = `
      <div class="row mb1">
        <select class="q-type">
          <option value="mc">multiple choice</option>
          <option value="tf">true / false</option>
          <option value="open">open answer</option>
        </select>
        <button class="btn small danger q-del">remove</button>
      </div>
      <label class="field"><span class="lbl">question ($math$ ok, no images)</span>
        <textarea class="q-text" rows="2" spellcheck="false"></textarea></label>
      <div class="q-choices"></div>
      <label class="field"><span class="lbl">explanation (optional, shown after submit)</span>
        <input type="text" class="q-explain"></label>`;
    const typeSel = q.querySelector(".q-type") as HTMLSelectElement;
    const choices = q.querySelector(".q-choices") as HTMLElement;

    const renderChoices = () => {
      choices.innerHTML = "";
      if (typeSel.value === "mc") {
        const list: Array<{ input: HTMLInputElement; radio: HTMLInputElement }> = [];
        const draw = () => {
          choices.innerHTML = "";
          for (const c of list) {
            const row = document.createElement("div");
            row.className = "choice-row";
            const radio = document.createElement("input");
            radio.type = "radio";
            radio.name = "q-choice-" + Math.random().toString(36).slice(2);
            radio.checked = c.radio.checked;
            radio.addEventListener("change", () => { c.radio.checked = true; });
            const inp = document.createElement("input");
            inp.type = "text";
            inp.value = c.input.value;
            inp.placeholder = "choice text";
            inp.addEventListener("input", () => { c.input.value = inp.value; });
            const del = document.createElement("button");
            del.className = "btn small danger";
            del.textContent = "x";
            del.addEventListener("click", () => {
              list.splice(list.indexOf(c), 1);
              draw();
            });
            row.append(radio, inp, del);
            choices.appendChild(row);
          }
          const addBtn = document.createElement("button");
          addBtn.className = "btn small";
          addBtn.textContent = "+ choice";
          addBtn.addEventListener("click", () => {
            const inp = document.createElement("input");
            inp.type = "text";
            const radio = document.createElement("input");
            radio.type = "radio";
            list.push({ input: inp, radio });
            draw();
          });
          choices.appendChild(addBtn);
        };
        for (let i = 0; i < 3; i++) {
          const inp = document.createElement("input");
          inp.type = "text";
          const radio = document.createElement("input");
          radio.type = "radio";
          if (i === 0) radio.checked = true;
          list.push({ input: inp, radio });
        }
        draw();
      } else if (typeSel.value === "tf") {
        const sel = document.createElement("select");
        sel.className = "q-answer";
        sel.innerHTML = '<option value="true">true</option><option value="false">false</option>';
        const lab = document.createElement("span");
        lab.className = "lbl small dim";
        lab.textContent = "answer: ";
        choices.append(lab, sel);
      } else {
        const inp = document.createElement("input");
        inp.type = "text";
        inp.className = "q-answer";
        inp.placeholder = "accepted answer (|| separates alternatives)";
        choices.appendChild(inp);
      }
    };
    typeSel.addEventListener("change", renderChoices);
    renderChoices();
    q.querySelector(".q-del")!.addEventListener("click", () => {
      q.remove();
      qs.splice(qs.indexOf(q), 1);
    });
    qbox.appendChild(q);
    qs.push(q);
  };
  addQuestion();
  root.querySelector("#nt-addq")!.addEventListener("click", addQuestion);

  const tabForm = root.querySelector("#nt-tab-form") as HTMLElement;
  const tabTxt = root.querySelector("#nt-tab-txt") as HTMLElement;
  const form = root.querySelector("#nt-form") as HTMLElement;
  const txtBox = root.querySelector("#nt-txt") as HTMLElement;
  tabForm.addEventListener("click", () => {
    tabForm.classList.add("active"); tabTxt.classList.remove("active");
    form.classList.remove("hidden"); txtBox.classList.add("hidden");
  });
  tabTxt.addEventListener("click", () => {
    tabTxt.classList.add("active"); tabForm.classList.remove("active");
    txtBox.classList.remove("hidden"); form.classList.add("hidden");
  });

  const errBox = root.querySelector("#nt-error") as HTMLElement;
  const fail = (m: string) => { errBox.textContent = m; errBox.classList.remove("hidden"); };
  root.querySelector("#nt-cancel")!.addEventListener("click", close);
  root.querySelector("#nt-go")!.addEventListener("click", async () => {
    errBox.classList.add("hidden");
    const isTxt = txtBox.classList.contains("hidden") === false;
    try {
      if (isTxt) {
        const txt = (root.querySelector("#nt-paste") as HTMLTextAreaElement).value;
        await importTestTxt(txt);
      } else {
        const questions: Array<Record<string, unknown>> = [];
        for (const qe of qs) {
          const qtype = (qe.querySelector(".q-type") as HTMLSelectElement).value;
          const text = (qe.querySelector(".q-text") as HTMLTextAreaElement).value.trim();
          if (!text) { fail("every question needs text"); return; }
          if (qtype === "mc") {
            const choices: string[] = [];
            const answer: string[] = [];
            qe.querySelectorAll<HTMLElement>(".choice-row").forEach((row) => {
              const radio = row.querySelector("input[type=radio]") as HTMLInputElement;
              const inp = row.querySelector("input[type=text]") as HTMLInputElement;
              const c = inp.value.trim();
              if (c) { choices.push(c); if (radio.checked) answer.push(c); }
            });
            if (!answer.length) { fail("mark at least one correct choice"); return; }
            questions.push({ type: "mc", text, choices, answer,
              explanation: (qe.querySelector(".q-explain") as HTMLInputElement).value.trim() });
          } else if (qtype === "tf") {
            questions.push({ type: "tf", text,
              answer: (qe.querySelector(".q-answer") as HTMLSelectElement).value,
              explanation: (qe.querySelector(".q-explain") as HTMLInputElement).value.trim() });
          } else {
            questions.push({ type: "open", text,
              answer: (qe.querySelector(".q-answer") as HTMLInputElement).value,
              explanation: (qe.querySelector(".q-explain") as HTMLInputElement).value.trim() });
          }
        }
        if (!questions.length) { fail("add at least one question"); return; }
        await createTest({
          title: (root.querySelector("#nt-title") as HTMLInputElement).value.trim(),
          subject: (root.querySelector("#nt-subject") as HTMLInputElement).value.trim(),
          tags: (root.querySelector("#nt-tags") as HTMLInputElement).value.split(",")
            .map((t) => t.trim()).filter(Boolean),
          description: (root.querySelector("#nt-desc") as HTMLInputElement).value.trim(),
          public: (root.querySelector("#nt-public") as HTMLInputElement).checked,
          questions,
        });
      }
      close();
      await loadTests();
    } catch (e) {
      fail((e as Error).message);
    }
  });
}

// ---------------- take a test ----------------
function renderQuestionView(q: any, i: number, review?: any): HTMLElement {
  const block = document.createElement("div");
  block.className = "q-block" + (review ? (review.ok ? " q-result" : " q-result bad") : "");
  const head = document.createElement("div");
  head.className = "q-head";
  const num = document.createElement("span");
  num.className = "q-num";
  num.textContent = "Q" + (i + 1);
  const t = document.createElement("span");
  t.className = "q-type";
  t.textContent = q.type === "mc" ? "multiple choice" : q.type === "tf" ? "true / false" : "open answer";
  head.append(num, t);
  block.appendChild(head);
  const text = document.createElement("div");
  text.className = "note-body";
  text.innerHTML = renderMarkdown(q.text, { noImages: true });
  block.appendChild(text);

  if (!review) {
    if (q.type === "mc") {
      q.choices.forEach((c: string, ci: number) => {
        const row = document.createElement("label");
        row.className = "q-choice";
        const radio = document.createElement("input");
        radio.type = "radio";
        radio.name = "q-" + q.id;
        radio.value = c;
        radio.dataset.qid = q.id;
        const span = document.createElement("span");
        span.className = "note-body";
        span.innerHTML = renderMarkdown(c, { noImages: true });
        row.append(radio, span);
        block.appendChild(row);
      });
    } else if (q.type === "tf") {
      for (const v of ["true", "false"]) {
        const row = document.createElement("label");
        row.className = "q-choice";
        const radio = document.createElement("input");
        radio.type = "radio";
        radio.name = "q-" + q.id;
        radio.value = v;
        radio.dataset.qid = q.id;
        const span = document.createElement("span");
        span.textContent = v;
        row.append(radio, span);
        block.appendChild(row);
      }
    } else {
      const inp = document.createElement("input");
      inp.type = "text";
      inp.dataset.qid = q.id;
      inp.className = "grow";
      inp.placeholder = "your answer";
      block.appendChild(inp);
    }
  } else {
    const given = document.createElement("div");
    given.className = "dim small mt1";
    given.textContent = review.given === undefined || review.given === ""
      ? "not answered" : "your answer: " + review.given;
    const right = document.createElement("div");
    right.className = "small mt1";
    right.innerHTML = "correct: <strong>" + esc(Array.isArray(review.answer)
      ? review.answer.join(" / ") : String(review.answer)) + "</strong>";
    block.append(given, right);
    if (review.explanation) {
      const ex = document.createElement("div");
      ex.className = "q-explain note-body";
      ex.innerHTML = renderMarkdown(review.explanation, { noImages: true });
      block.appendChild(ex);
    }
  }
  return block;
}

async function takeTest(id: string): Promise<void> {
  let test: any;
  try {
    test = await getTest(id);
  } catch (e) {
    alert((e as Error).message);
    return;
  }
  const { root, close } = openModal(`
    <div class="row mb2">
      <span class="tc-title grow">${esc(test.title)}</span>
      <span class="timer-chip" id="tk-timer">0:00</span>
    </div>
    <div id="tk-qs"></div>
    <div class="actions">
      <button class="btn" id="tk-cancel">cancel</button>
      <button class="btn primary" id="tk-submit">submit</button>
    </div>`, true);
  const started = Date.now();
  const timerEl = root.querySelector("#tk-timer") as HTMLElement;
  const tick = window.setInterval(() => {
    const s = Math.floor((Date.now() - started) / 1000);
    timerEl.textContent = `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
  }, 500);
  const box = root.querySelector("#tk-qs")!;
  for (let i = 0; i < test.questions.length; i++) {
    box.appendChild(renderQuestionView(test.questions[i], i));
  }
  root.querySelector("#tk-cancel")!.addEventListener("click", () => {
    window.clearInterval(tick);
    close();
  });
  root.querySelector("#tk-submit")!.addEventListener("click", async () => {
    const seconds = Math.floor((Date.now() - started) / 1000);
    const answers: Record<string, string> = {};
    root.querySelectorAll<HTMLElement>("[data-qid]").forEach((el) => {
      const i = el as HTMLInputElement;
      if (i.type === "radio" && i.checked) answers[i.dataset.qid!] = i.value;
      if (i.type === "text") answers[i.dataset.qid!] = i.value.trim();
    });
    if (!window.confirm("submit your answers?")) return;
    window.clearInterval(tick);
    let d: any;
    try {
      d = await submitTest(id, answers, seconds);
    } catch (e) {
      alert((e as Error).message);
      return;
    }
    box.innerHTML = "";
    const score = document.createElement("div");
    score.className = "score-big mb2";
    score.innerHTML = `<span class="${d.score === d.total ? "ok" : d.score === 0 ? "bad" : ""}">${d.score}/${d.total}</span>`
      + ` <span class="dim small">correct · ${fmtDur(seconds)}</span>`;
    box.appendChild(score);
    test.questions.forEach((q: any, i: number) => {
      const det = d.details.find((x: any) => x.id === q.id);
      const given = answers[q.id];
      box.appendChild(renderQuestionView(q, i, { ...det, given }));
    });
    const again = document.createElement("button");
    again.className = "btn small mt2";
    again.textContent = "retake";
    again.addEventListener("click", () => { close(); void takeTest(id); });
    box.appendChild(again);
  });
}

// ---------------- results ----------------
async function resultsModal(id: string): Promise<void> {
  let d: any;
  try {
    d = await getTestResults(id);
  } catch (e) {
    alert((e as Error).message);
    return;
  }
  const rows = d.results.map((r: any, i: number) => `
    <div class="lb-row">
      <span class="rank ${i === 0 ? "gold" : i === 1 ? "silver" : i === 2 ? "bronze" : ""}">${i + 1}</span>
      <a class="lb-user" href="/user.html?name=${encodeURIComponent(r.user)}">@${esc(r.user)}</a>
      <span class="lb-val">${r.correct}/${d.total}</span>
      <span class="lb-val">${fmtDur(r.seconds)}</span>
      <span class="lb-val">${fmtTime(r.ts)}</span>
    </div>`).join("") || '<div class="dim">no completions yet — be the first.</div>';
  const { root, close } = openModal(`
    <h2>results</h2>
    <div class="row mb1 small dim mono">
      <span class="rank"></span><span class="grow">user</span>
      <span class="lb-val">score</span><span class="lb-val">time</span><span class="lb-val">when</span>
    </div>
    ${rows}
    <div class="actions"><button class="btn" id="rs-close">close</button></div>`);
  root.querySelector("#rs-close")!.addEventListener("click", close);
}

boot();
