// Space page: file tree, note view/editor with KaTeX preview, comments with
// @mention autocomplete, branches, history/diff, merge resolver, fork/star.

import {
  getSpace, getTree, getNote, putNote, deleteNote, getComments, postComment,
  getHistory, getNoteHistory, getDiff, createBranch, mergeBranch, forkSpace, starSpace,
  patchSpace, exportUrl, exportTxtUrl, downloadFile, postReading,
  restoreNote, importFiles, importZip,
  Space, User, api, ApiError,
} from "./api.js";
import { renderMarkdown, esc } from "./render.js";
import { exportNotePdf } from "./pdf.js";
import {
  initTheme, initBell, initUserArea, fmtTime, openModal,
  wireMentionAutocomplete, dueState, dueLabel,
} from "./common.js";

const qp = new URLSearchParams(location.search);
const sid = qp.get("id") || "";

let user: User | null = null;
let space: Space;
let branch = "main";
let rev = 0;
let tree: Record<string, string> = {};
let curPath = "";
let curSha = "";
let curContent = "";
let viewingRev: number | undefined;
let expanded = new Set<string>();
let parentForReply: string | null = null;

const $ = (id: string) => document.getElementById(id)!;

// ---------------- boot ----------------
async function boot(): Promise<void> {
  initTheme();
  initBell();
  if (!sid) { location.href = "/"; return; }
  try {
    user = await initUserArea();
    space = await getSpace(sid);
  } catch (e) {
    $("content").innerHTML =
      `<div class="error-box">cannot open space: ${esc((e as Error).message)}</div>`;
    return;
  }
  renderSpaceMeta();
  await loadTree();
  wireTopButtons();
  wireEditor();
  wireNewNote();
  wireDelete();
  initBranchMergeButtons();
  const initialPath = qp.get("path");
  if (initialPath) await openNote(initialPath);
  else showEmptyState();
}

// ---------------- meta + chrome ----------------
function renderSpaceMeta(): void {
  $("space-title").textContent = space.name;
  const desc = $("desc");
  desc.innerHTML = "";
  desc.textContent = space.description || "(no description)";
  if (space.forked_from) {
    const d = document.createElement("div");
    d.className = "xs faint mt1";
    d.textContent = `forked from @${space.forked_from.owner} · rev ${space.forked_from.rev}`;
    desc.appendChild(d);
  }
  $("st-owner").textContent = "owner " + space.owner;

  const sel = $("branch-select") as HTMLSelectElement;
  sel.innerHTML = "";
  for (const b of Object.keys(space.branches)) {
    const o = document.createElement("option");
    o.value = b;
    o.textContent = "branch: " + b;
    sel.appendChild(o);
  }
  sel.value = branch;
  sel.onchange = async () => {
    branch = sel.value;
    await loadTree();
    if (curPath) await openNote(curPath);
    else showEmptyState();
  };

  const star = $("star-btn");
  star.textContent = (space.starred ? "★ " : "☆ ") + space.star_count;
  star.onclick = async () => {
    if (!user) return;
    try {
      const d = await starSpace(sid, !space.starred);
      space.starred = !space.starred;
      space.star_count = d.star_count;
      star.textContent = (space.starred ? "★ " : "☆ ") + space.star_count;
    } catch { /* ignore */ }
  };

  $("tags-btn").classList.toggle("hidden", !space.can_edit);
  $("new-note-btn").classList.toggle("hidden", !space.can_edit);
  $("import-btn").classList.toggle("hidden", !space.can_edit);
  $("fork-btn").classList.toggle("hidden", !user || space.can_edit);
}

function wireTopButtons(): void {
  ($("star-btn") as HTMLButtonElement).disabled = !user;
  $("fork-btn").onclick = async () => {
    try {
      const f = await forkSpace(sid);
      location.href = "/space.html?id=" + f.id;
    } catch (e) {
      alert((e as Error).message);
    }
  };
  $("export-btn").onclick = () => { downloadFile(exportUrl(sid, branch), "space.zip").catch((e) => alert((e as Error).message)); };
  $("txt-btn").onclick = () => { downloadFile(exportTxtUrl(sid, branch), "space.txt").catch((e) => alert((e as Error).message)); };
  $("pdf-btn").onclick = () => {
    if (!curPath) return;
    exportNotePdf({ spaceName: space.name, path: curPath, branch, content: curContent })
      .catch((e) => alert("pdf export failed: " + (e as Error).message));
  };
  $("import-btn").onclick = () => { void importModal(); };
  $("tags-btn").onclick = () => { void tagsModal(); };
  $("history-btn").onclick = () => { void historyModal(); };
  $("nh-btn").onclick = () => { void noteHistoryModal(); };
}

// ---------------- tree ----------------
interface TNode { name: string; path: string; dir: boolean; children: TNode[]; }

function buildTree(): TNode[] {
  const roots: TNode[] = [];
  for (const p of Object.keys(tree)) {
    const parts = p.split("/");
    let level = roots;
    let acc = "";
    for (let i = 0; i < parts.length; i++) {
      const name = parts[i];
      const full = acc ? acc + "/" + name : name;
      const isDir = i < parts.length - 1;
      let node = level.find((n) => n.name === name && n.dir === isDir);
      if (!node) {
        node = { name, path: full, dir: isDir, children: [] };
        level.push(node);
      }
      acc = full;
      if (isDir) level = node.children;
    }
  }
  const sortLvl = (l: TNode[]) => {
    l.sort((a, b) => (a.dir === b.dir ? a.name.localeCompare(b.name) : a.dir ? -1 : 1));
    l.forEach((n) => sortLvl(n.children));
  };
  sortLvl(roots);
  return roots;
}

function renderTree(): void {
  const box = $("tree");
  box.innerHTML = "";
  const render = (nodes: TNode[], depth: number, parent: HTMLElement) => {
    for (const n of nodes) {
      const row = document.createElement("div");
      row.className = "tree-row" + (n.path === curPath && !n.dir ? " selected" : "");
      const nameEl = document.createElement("span");
      nameEl.className = "grow";
      nameEl.textContent = (n.dir ? (expanded.has(n.path) ? "▾ " : "▸ ") : "· ") + n.name;
      row.appendChild(nameEl);
      if (n.dir && space.can_edit) wireFolderDelete(row, n.path);
      row.onclick = () => {
        if (n.dir) {
          if (expanded.has(n.path)) expanded.delete(n.path);
          else expanded.add(n.path);
          renderTree();
        } else {
          void openNote(n.path);
        }
      };
      parent.appendChild(row);
      if (n.dir && expanded.has(n.path)) {
        const sub = document.createElement("div");
        sub.className = "tree-indent";
        render(n.children, depth + 1, sub);
        parent.appendChild(sub);
      }
    }
  };
  render(buildTree(), 0, box);
}

async function loadTree(): Promise<void> {
  try {
    const d = await getTree(sid, branch);
    tree = d.tree;
    rev = d.rev;
    $("st-rev").textContent = `rev ${rev}`;
    $("st-branch").textContent = "branch " + branch;
  } catch (e) {
    $("tree").innerHTML = `<div class="dim">${esc((e as Error).message)}</div>`;
  }
  renderTree();
}

// ---------------- note ----------------
function showEmptyState(): void {
  curPath = "";
  $("viewer").innerHTML = '<div class="dim">select a note, or press + to create one.</div>';
  $("comments").classList.add("hidden");
  $("note-path").textContent = "";
  $("note-meta").textContent = "";
  const due = $("note-due");
  due.classList.add("hidden");
  due.textContent = "";
  ($("due-input") as HTMLInputElement).value = "";
  $("edit-btn").classList.add("hidden");
  $("save-btn").classList.add("hidden");
  $("cancel-btn").classList.add("hidden");
  $("delete-btn").classList.add("hidden");
  $("nh-btn").classList.add("hidden");
  $("editor").classList.add("hidden");
  $("commit-row").classList.add("hidden");
}

async function openNote(path: string, oldRev?: number): Promise<void> {
  let d: any;
  try {
    d = await getNote(sid, path, branch, oldRev);
  } catch (e) {
    showEmptyState();
    $("viewer").innerHTML =
      `<div class="error-box">${esc((e as Error).message)}</div>`;
    return;
  }
  curPath = path;
  curSha = d.sha;
  curContent = d.content;
  viewingRev = oldRev;
  $("note-path").textContent = path;
  $("note-meta").textContent = oldRev !== undefined
    ? `viewing rev ${oldRev} (read-only)` : "sha " + curSha.slice(0, 12);
  $("viewer").innerHTML = renderMarkdown(d.content);
  $("editor").classList.add("hidden");
  $("commit-row").classList.add("hidden");
  $("save-btn").classList.add("hidden");
  $("cancel-btn").classList.add("hidden");
  $("edit-btn").classList.toggle("hidden", !space.can_edit || oldRev !== undefined);
  $("delete-btn").classList.toggle("hidden", !space.can_edit || oldRev !== undefined);
  $("nh-btn").classList.toggle("hidden", !space.can_edit || oldRev !== undefined);
  renderDue(d.content);
  renderTree();
  void loadComments();
  postReading(sid, path, location.hash).catch(() => { /* ignore */ });
}

// ---------------- deadline badge ----------------
const DUE_LINE = /^@due\s+(\d{4}-\d{2}-\d{2})\s*$/m;

function parseDue(content: string): string | null {
  const m = content.match(DUE_LINE);
  return m ? m[1] : null;
}

function dueEpoch(date: string): number {
  return new Date(date + "T00:00:00").getTime() / 1000;
}

function renderDue(content: string): void {
  const badge = $("note-due");
  const due = parseDue(content);
  ($("due-input") as HTMLInputElement).value = due || "";
  if (!due) {
    badge.classList.add("hidden");
    badge.textContent = "";
    return;
  }
  const t = dueEpoch(due);
  const now = Date.now() / 1000;
  badge.textContent = dueLabel(t, now);
  badge.className = "due " + dueState(t, now);
  badge.classList.remove("hidden");
}

function wireDelete(): void {
  $("delete-btn").onclick = () => {
    const { root, close } = openModal(`
      <h2>delete note</h2>
      <p class="dim">Delete <span class="mono">${esc(curPath)}</span> from branch
      <span class="mono">${esc(branch)}</span>?<br>
      A new revision without the file is created; history keeps it.</p>
      <div class="error-box hidden" id="dl-error"></div>
      <div class="actions">
        <button class="btn" id="dl-cancel">cancel</button>
        <button class="btn danger" id="dl-go">delete</button>
      </div>`);
    root.querySelector("#dl-cancel")!.addEventListener("click", close);
    root.querySelector("#dl-go")!.addEventListener("click", () => {
      deleteNote(sid, curPath, branch)
        .then(async () => {
          close();
          await loadTree();
          showEmptyState();
          $("viewer").innerHTML =
            '<div class="dim">note deleted — history keeps it.</div>';
        })
        .catch((e) => {
          const box = root.querySelector("#dl-error") as HTMLElement;
          box.textContent = (e as Error).message;
          box.classList.remove("hidden");
        });
    });
  };
}

function wireFolderDelete(row: HTMLElement, dirPath: string): void {
  const del = document.createElement("button");
  del.className = "btn small danger";
  del.textContent = "x";
  del.title = "delete folder (all notes inside)";
  del.addEventListener("click", (e) => {
    e.stopPropagation();
    const { root, close } = openModal(`
      <h2>delete folder</h2>
      <p class="dim">Delete everything under <span class="mono">${esc(dirPath)}/</span>?
      History keeps the files.</p>
      <div class="error-box hidden" id="df-error"></div>
      <div class="actions">
        <button class="btn" id="df-cancel">cancel</button>
        <button class="btn danger" id="df-go">delete</button>
      </div>`);
    root.querySelector("#df-cancel")!.addEventListener("click", close);
    root.querySelector("#df-go")!.addEventListener("click", () => {
      deleteNote(sid, dirPath + "/", branch)
        .then(async () => {
          close();
          await loadTree();
          if (curPath === dirPath || curPath.startsWith(dirPath + "/")) {
            showEmptyState();
          }
        })
        .catch((e2) => {
          const box = root.querySelector("#df-error") as HTMLElement;
          box.textContent = (e2 as Error).message;
          box.classList.remove("hidden");
        });
    });
  });
  row.appendChild(del);
}

function wireEditor(): void {
  const ta = $("editor-ta") as HTMLTextAreaElement;
  $("edit-btn").onclick = () => {
    ta.value = curContent;
    $("editor").classList.remove("hidden");
    $("commit-row").classList.remove("hidden");
    $("viewer").classList.add("hidden");
    $("edit-btn").classList.add("hidden");
    $("save-btn").classList.remove("hidden");
    $("cancel-btn").classList.remove("hidden");
    previewEditor();
    ta.focus();
  };
  $("cancel-btn").onclick = () => {
    $("viewer").innerHTML = renderMarkdown(curContent);
    $("viewer").classList.remove("hidden");
    $("editor").classList.add("hidden");
    $("commit-row").classList.add("hidden");
    $("save-btn").classList.add("hidden");
    $("cancel-btn").classList.add("hidden");
    $("edit-btn").classList.remove("hidden");
  };
  let timer = 0;
  ta.addEventListener("input", () => {
    clearTimeout(timer);
    timer = window.setTimeout(previewEditor, 150);
  });
  $("save-btn").onclick = () => { void saveNote(); };
  ta.addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === "s") {
      e.preventDefault();
      void saveNote();
    }
  });
}

function previewEditor(): void {
  $("editor-preview").innerHTML =
    renderMarkdown(($("editor-ta") as HTMLTextAreaElement).value);
}

async function saveNote(): Promise<void> {
  if (!curPath) return;
  const ta = $("editor-ta") as HTMLTextAreaElement;
  const msg = ($("msg-input") as HTMLInputElement).value.trim();
  const dueVal = ($("due-input") as HTMLInputElement).value;
  let content = ta.value.split("\n").filter((l) => !/^@due\s/.test(l)).join("\n");
  if (dueVal) content = `@due ${dueVal}\n` + content;
  try {
    await putNote(sid, branch, curPath, content, msg);
    await loadTree();
    await openNote(curPath);
  } catch (e) {
    alert((e as Error).message);
  }
}

// ---------------- note templates ----------------
const TEMPLATES: Record<string, string> = {
  blank: "",
  lecture: `# Lecture — <topic>

course: <course> · date: <date>

## overview
- <what this lecture covers>

## definitions
- **<term>** — <definition>

## theorem
**Theorem.** <statement>

*proof.* <sketch>

## examples
1. <example>

## questions
- <open question>
`,
  summary: `# <topic> — summary

## key ideas
- <idea>

## formulas
$$
<formula>
$$

## pitfalls
- <common mistake>

## links
- <related note path>
`,
  lab: `# Lab — <title>

## goal
<what to measure or show>

## setup
- <equipment, versions>

## procedure
1. <step>

## results
| measurement | value |
| --- | --- |
| <name> | <value> |

## conclusion
<what you learned>
`,
};

function wireNewNote(): void {
  $("new-note-btn").onclick = () => {
    const folder = curPath.includes("/")
      ? curPath.slice(0, curPath.lastIndexOf("/")) + "/" : "";
    const { root, close } = openModal(`
      <h2>new note</h2>
      <label class="field"><span class="lbl">path (folders allowed: a/b/note.md)</span>
        <input type="text" id="nn-path" value="${esc(folder)}"></label>
      <label class="field"><span class="lbl">template</span>
        <select id="nn-template">
          <option value="blank">blank</option>
          <option value="lecture">lecture</option>
          <option value="summary">summary</option>
          <option value="lab">lab report</option>
        </select></label>
      <label class="field"><span class="lbl">deadline (optional, becomes an @due line)</span>
        <input type="date" id="nn-due"></label>
      <div class="error-box hidden" id="nn-error"></div>
      <div class="actions">
        <button class="btn" id="nn-cancel">cancel</button>
        <button class="btn primary" id="nn-create">create</button>
      </div>`);
    root.querySelector("#nn-cancel")!.addEventListener("click", close);
    root.querySelector("#nn-create")!.addEventListener("click", () => {
      const path = (root.querySelector("#nn-path") as HTMLInputElement).value.trim();
      if (!path) return;
      const tpl = (root.querySelector("#nn-template") as HTMLSelectElement).value;
      let content = TEMPLATES[tpl] || "";
      const due = (root.querySelector("#nn-due") as HTMLInputElement).value;
      if (due) content = `@due ${due}\n` + content;
      if (!content) content = "# New note\n\n";
      putNote(sid, branch, path, content, "create note")
        .then(async () => {
          close();
          await loadTree();
          await openNote(path);
        })
        .catch((e) => {
          const box = root.querySelector("#nn-error") as HTMLElement;
          box.textContent = (e as Error).message;
          box.classList.remove("hidden");
        });
    });
  };
}

// ---------------- comments (reddit-style threads) ----------------
interface Comment {
  id: string; path: string; author: string; time: number;
  text: string; parent_id: string | null;
}

async function loadComments(): Promise<void> {
  const box = $("comments");
  if (!curPath) { box.classList.add("hidden"); return; }
  box.classList.remove("hidden");
  box.innerHTML = "";
  let cm: Comment[];
  try {
    cm = (await getComments(sid, curPath)).comments;
  } catch {
    return;
  }
  const head = document.createElement("div");
  head.className = "micro mt4 mb2";
  head.textContent = `comments (${cm.length})`;
  box.appendChild(head);

  const byParent = new Map<string, Comment[]>();
  const tops: Comment[] = [];
  for (const c of cm) {
    if (c.parent_id && cm.some((x) => x.id === c.parent_id)) {
      if (!byParent.has(c.parent_id)) byParent.set(c.parent_id, []);
      byParent.get(c.parent_id)!.push(c);
    } else {
      tops.push(c);
    }
  }
  const collapsed = new Set<string>();
  const targetId = location.hash.startsWith("#comment-")
    ? location.hash.slice(9) : null;

  const renderComment = (c: Comment, parent: HTMLElement): void => {
    const card = document.createElement("div");
    card.className = "comment" + (c.id === targetId ? " target" : "");
    card.id = "comment-" + c.id;
    const chead = document.createElement("div");
    chead.className = "c-head";
    const who = document.createElement("a");
    who.className = "c-author";
    who.href = "/user.html?name=" + encodeURIComponent(c.author);
    who.textContent = "@" + c.author;
    const when = document.createElement("span");
    when.className = "c-time";
    when.textContent = fmtTime(c.time);
    const replyMark = document.createElement("span");
    replyMark.className = "faint xs mono";
    replyMark.textContent = c.parent_id ? "reply" : "";
    chead.append(who, when, replyMark);
    const body = document.createElement("div");
    body.className = "c-text";
    body.innerHTML = renderMarkdown(c.text, { colors: true });
    const actions = document.createElement("div");
    actions.className = "p-actions";
    const replyBtn = document.createElement("button");
    replyBtn.className = "btn small";
    replyBtn.textContent = "reply";
    replyBtn.onclick = () => {
      parentForReply = c.id;
      updateReplyChip();
      ($("comment-ta") as HTMLTextAreaElement).focus();
    };
    actions.appendChild(replyBtn);

    const kids = byParent.get(c.id) || [];
    let wrap: HTMLElement | null = null;
    if (kids.length) {
      const toggle = document.createElement("button");
      toggle.className = "btn small";
      toggle.textContent = "− thread";
      toggle.title = "collapse this thread";
      toggle.onclick = () => {
        if (collapsed.has(c.id)) {
          collapsed.delete(c.id);
          toggle.textContent = "− thread";
        } else {
          collapsed.add(c.id);
          toggle.textContent = `+ ${kids.length}`;
        }
        if (wrap) wrap.classList.toggle("hidden", collapsed.has(c.id));
      };
      actions.appendChild(toggle);
      wrap = document.createElement("div");
      wrap.className = "comment-replies";
      for (const kid of kids) renderComment(kid, wrap);
      card.append(chead, body, actions, wrap);
    } else {
      card.append(chead, body, actions);
    }
    parent.appendChild(card);
  };
  for (const t of tops) renderComment(t, box);

  const form = document.createElement("div");
  form.className = "comment-form";
  const chip = document.createElement("div");
  chip.className = "micro mb1 hidden";
  chip.id = "reply-chip";
  const ta = document.createElement("textarea");
  ta.id = "comment-ta";
  ta.placeholder = "write a comment… @name mentions a user, $math$ works too";
  const post = document.createElement("button");
  post.className = "btn primary mt1";
  post.textContent = "post comment";
  post.onclick = () => {
    const text = ta.value.trim();
    if (!text) return;
    postComment(sid, curPath, text, parentForReply)
      .then(() => {
        parentForReply = null;
        ta.value = "";
        void loadComments();
      })
      .catch((e) => alert((e as Error).message));
  };
  form.append(chip, ta, post);
  box.appendChild(form);
  wireMentionAutocomplete(ta);
  updateReplyChip();

  if (targetId) {
    const el = document.getElementById("comment-" + targetId);
    if (el) window.setTimeout(() => el.scrollIntoView({ block: "center" }), 100);
  }
}

function updateReplyChip(): void {
  const chip = document.getElementById("reply-chip");
  if (!chip) return;
  chip.innerHTML = "";
  if (parentForReply) {
    chip.classList.remove("hidden");
    chip.append(document.createTextNode("replying to a comment — "));
    const cancel = document.createElement("a");
    cancel.href = "#";
    cancel.textContent = "cancel";
    cancel.onclick = (e) => {
      e.preventDefault();
      parentForReply = null;
      updateReplyChip();
    };
    chip.appendChild(cancel);
  } else {
    chip.classList.add("hidden");
  }
}

// ---------------- history / diff ----------------
async function historyModal(): Promise<void> {
  let revs: any[];
  try {
    revs = (await getHistory(sid, branch)).revs;
  } catch (e) {
    alert((e as Error).message);
    return;
  }
  const rows = revs.slice(0, 60).map((r) => `
    <div class="row mb1">
      <span class="mono xs grow">rev ${r.rev} · @${r.author} · ${fmtTime(r.time)}
        ${esc(r.message || "")} · ${r.changes.length} change(s)</span>
      <button class="btn small" data-rev="${r.rev}" data-act="view">view</button>
      <button class="btn small" data-rev="${r.rev}" data-act="diff">diff vs parent</button>
      ${curPath && space.can_edit ? `<button class="btn small" data-rev="${r.rev}" data-act="restore">restore</button>` : ""}
    </div>`).join("");
  const fromRev = revs.length ? Math.max(0, revs[0].rev - 1) : 0;
  const { root, close } = openModal(`
    <h2>history · ${esc(branch)}</h2>
    <div class="row mb2 small dim">
      <span>from rev</span><input type="number" id="dh-a" class="grow" value="${fromRev}">
      <span>to rev</span><input type="number" id="dh-b" class="grow" value="${revs.length ? revs[0].rev : 0}">
      <button class="btn" id="dh-go">show diff</button>
    </div>
    ${rows || '<div class="dim">no revisions</div>'}
    <div class="actions"><button class="btn" id="dh-close">close</button></div>`);
  root.querySelector("#dh-close")!.addEventListener("click", close);
  root.querySelector("#dh-go")!.addEventListener("click", () => {
    const a = +(root.querySelector("#dh-a") as HTMLInputElement).value;
    const b = +(root.querySelector("#dh-b") as HTMLInputElement).value;
    void diffModal(a, b);
  });
  root.querySelectorAll<HTMLElement>("[data-act]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const r = +(btn.dataset.rev || "0");
      if (btn.dataset.act === "view") {
        close();
        if (curPath) void openNote(curPath, r);
      } else if (btn.dataset.act === "restore") {
        void doRestore(r, close);
      } else {
        void diffModal(Math.max(0, r - 1), r);
      }
    });
  });
}

async function doRestore(rev: number, close?: () => void): Promise<void> {
  if (!curPath) return;
  if (!window.confirm(`restore ${curPath} to rev ${rev}? a new revision is created.`)) return;
  try {
    await restoreNote(sid, branch, curPath, rev);
    if (close) close();
    await loadTree();
    await openNote(curPath);
  } catch (e) {
    alert((e as Error).message);
  }
}

// ---------------- note history (per-note restore) ----------------
async function noteHistoryModal(): Promise<void> {
  if (!curPath) return;
  let revs: any[];
  try {
    revs = (await getNoteHistory(sid, curPath, branch)).revs;
  } catch (e) {
    alert((e as Error).message);
    return;
  }
  if (!revs.length) {
    alert("this note has no earlier revisions");
    return;
  }
  const rows = revs.map((r) => `
    <div class="row mb1">
      <span class="mono xs grow">rev ${r.rev} · @${r.author} · ${fmtTime(r.time)}
        ${esc(r.message || "")}</span>
      <button class="btn small" data-rev="${r.rev}" data-act="view">view</button>
      <button class="btn small" data-rev="${r.rev}" data-act="restore">restore</button>
    </div>`).join("");
  const { root, close } = openModal(`
    <h2>revisions of <span class="mono">${esc(curPath)}</span></h2>
    ${rows}
    <div class="actions"><button class="btn" id="nh-close">close</button></div>`);
  root.querySelector("#nh-close")!.addEventListener("click", close);
  root.querySelectorAll<HTMLElement>("[data-act]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const r = +(btn.dataset.rev || "0");
      if (btn.dataset.act === "view") {
        close();
        void openNote(curPath, r);
      } else {
        void doRestore(r, close);
      }
    });
  });
}

// ---------------- import ----------------
async function importModal(): Promise<void> {
  if (!space.can_edit) return;
  const { root, close } = openModal(`
    <h2>import files</h2>
    <p class="dim">choose .md files, or a .zip of .md files (e.g. a space export).<br>
    they are added to branch <span class="mono">${esc(branch)}</span> as one revision.
    folder structure comes from the file names.</p>
    <label class="field"><span class="lbl">files (.md or .zip)</span>
      <input type="file" id="im-files" multiple accept=".md,.markdown,.zip,.txt"></label>
    <label class="field"><span class="lbl">commit message (optional)</span>
      <input type="text" id="im-msg" placeholder="import"></label>
    <div class="error-box hidden" id="im-error"></div>
    <div class="micro" id="im-status"></div>
    <div class="actions">
      <button class="btn" id="im-cancel">cancel</button>
      <button class="btn primary" id="im-go">import</button>
    </div>`);
  const errBox = root.querySelector("#im-error") as HTMLElement;
  const status = root.querySelector("#im-status") as HTMLElement;
  const fail = (m: string) => { errBox.textContent = m; errBox.classList.remove("hidden"); status.textContent = ""; };
  root.querySelector("#im-cancel")!.addEventListener("click", close);
  root.querySelector("#im-go")!.addEventListener("click", async () => {
    const input = root.querySelector("#im-files") as HTMLInputElement;
    const msg = (root.querySelector("#im-msg") as HTMLInputElement).value.trim();
    const files = input.files;
    if (!files || files.length === 0) { fail("choose at least one file"); return; }
    status.textContent = "importing…";
    try {
      const mdFiles: { path: string; content: string }[] = [];
      const zips: File[] = [];
      for (const f of Array.from(files)) {
        if (f.name.toLowerCase().endsWith(".zip")) zips.push(f);
        else mdFiles.push({ path: f.name, content: await f.text() });
      }
      let done = 0;
      if (mdFiles.length) {
        const d = await importFiles(sid, branch, mdFiles, msg);
        done += d.imported || 0;
      }
      for (const z of zips) {
        const d = await importZip(sid, branch, await z.arrayBuffer(), msg);
        done += d.imported || 0;
      }
      close();
      await loadTree();
      if (curPath) await openNote(curPath);
      else showEmptyState();
    } catch (e) {
      fail((e as Error).message);
    }
  });
}

async function diffModal(revA: number, revB: number): Promise<void> {
  let d: any;
  try {
    d = await getDiff(sid, branch, revA, revB);
  } catch (e) {
    alert((e as Error).message);
    return;
  }
  const files: any[] = d.files;
  const inner = files.length === 0
    ? '<div class="dim">no differences</div>'
    : files.map((f) => {
        const lines = f.diff.map((ln: string) => {
          let cls = "";
          if (ln.startsWith("+")) cls = "diff-add";
          else if (ln.startsWith("-")) cls = "diff-del";
          else if (ln.startsWith("@@")) cls = "diff-hdr";
          return `<span class="diff-line ${cls}">${esc(ln)}</span>`;
        }).join("\n");
        return `<div class="diff-file"><div class="df-head">${esc(f.path)}</div><pre>${lines}</pre></div>`;
      }).join("");
  const { root, close } = openModal(`
    <h2>diff · rev ${revA} → rev ${revB} · ${esc(branch)}</h2>
    ${inner}
    <div class="actions"><button class="btn" id="df-close">close</button></div>`);
  root.querySelector("#df-close")!.addEventListener("click", close);
}

// ---------------- merge ----------------
async function mergeModal(): Promise<void> {
  if (!space.can_edit) return;
  const others = Object.keys(space.branches).filter((b) => b !== branch);
  if (!others.length) {
    alert("no other branches to merge from — create one first");
    return;
  }
  const opts = others.map((b) => `<option value="${b}">${b}</option>`).join("");
  const { root, close } = openModal(`
    <h2>merge into ${esc(branch)}</h2>
    <label class="field"><span class="lbl">source branch</span>
      <select id="mg-src">${opts}</select></label>
    <div id="mg-out"></div>
    <div class="actions">
      <button class="btn" id="mg-close">close</button>
      <button class="btn primary" id="mg-go">merge</button>
    </div>`);
  root.querySelector("#mg-close")!.addEventListener("click", close);
  const doMerge = async (resolve?: Record<string, string>) => {
    const src = (root.querySelector("#mg-src") as HTMLSelectElement).value;
    const out = root.querySelector("#mg-out")!;
    out.innerHTML = '<div class="dim">merging…</div>';
    try {
      const d = await mergeBranch(sid, src, branch, resolve).catch((e) => {
        if (e instanceof ApiError && e.payload && e.payload.resolve_required) {
          return e.payload;                    // 409 = conflict list, not a hard error
        }
        throw e;
      });
      if (d.resolve_required) {
        out.innerHTML = '<div class="micro warn mb2">conflicts — choose one side per file:</div>';
        const resolveMap: Record<string, string> = {};
        for (const c of d.conflicts) {
          const row = document.createElement("div");
          row.className = "panel";
          const t = document.createElement("div");
          t.className = "mono small mb1";
          t.textContent = c.path;
          row.appendChild(t);
          const btns = document.createElement("div");
          btns.className = "row";
          const oursBtn = document.createElement("button");
          oursBtn.className = "btn small";
          oursBtn.textContent = "keep current (" + branch + ")";
          const theirsBtn = document.createElement("button");
          theirsBtn.className = "btn small";
          theirsBtn.textContent = "take " + src;
          const showBtn = document.createElement("button");
          showBtn.className = "btn small";
          showBtn.textContent = "peek";
          const preview = document.createElement("pre");
          preview.className = "small hidden mt1";
          const clearPreview = () => {
            preview.textContent = "";
            preview.classList.add("hidden");
          };
          oursBtn.onclick = () => {
            resolveMap[c.path] = "ours";
            oursBtn.classList.add("active");
            theirsBtn.classList.remove("active");
            clearPreview();
          };
          theirsBtn.onclick = () => {
            resolveMap[c.path] = "theirs";
            theirsBtn.classList.add("active");
            oursBtn.classList.remove("active");
            clearPreview();
          };
          showBtn.onclick = () => {
            api(`spaces/${sid}/object?sha=${c.ours_sha}`).then((o) => {
              api(`spaces/${sid}/object?sha=${c.theirs_sha}`).then((t2) => {
                preview.textContent =
                  `— ${branch} (ours) —\n${o.content}\n\n— ${src} (theirs) —\n${t2.content}`;
                preview.classList.remove("hidden");
              });
            }).catch(() => { /* ignore */ });
          };
          btns.append(oursBtn, theirsBtn, showBtn);
          row.append(btns, preview);
          out.appendChild(row);
        }
        const go = document.createElement("button");
        go.className = "btn primary";
        go.textContent = "apply choices and merge";
        go.onclick = () => { void doMerge(resolveMap); };
        out.appendChild(go);
      } else if (d.nothing_to_do) {
        out.innerHTML = '<div class="dim">nothing to merge — branches agree.</div>';
      } else {
        out.innerHTML = `<div class="micro ok">merged — rev ${d.rev}, ${d.changes} change(s).</div>`;
        close();
        await loadTree();
        if (curPath) await openNote(curPath);
      }
    } catch (e) {
      out.innerHTML = `<div class="error-box">${esc((e as Error).message)}</div>`;
    }
  };
  root.querySelector("#mg-go")!.addEventListener("click", () => { void doMerge(); });
}

// ---------------- tags / settings ----------------
async function tagsModal(): Promise<void> {
  if (!space.can_edit) return;
  const { root, close } = openModal(`
    <h2>space settings</h2>
    <label class="field"><span class="lbl">name</span>
      <input type="text" id="st-name" value="${esc(space.name)}"></label>
    <label class="field"><span class="lbl">description</span>
      <input type="text" id="st-desc" value="${esc(space.description)}"></label>
    <label class="field"><span class="lbl">tags (comma separated)</span>
      <input type="text" id="st-tags" value="${esc(space.tags.join(", "))}"></label>
    <label class="field"><span class="lbl">viewers (read-only users, comma separated)</span>
      <input type="text" id="st-viewers" value="${esc(space.viewers.join(", "))}"></label>
    <label class="row small"><input type="checkbox" id="st-public" ${space.public ? "checked" : ""}>
      <span>public (any logged-in user can view and comment)</span></label>
    <div class="error-box hidden" id="st-error"></div>
    <div class="actions">
      <button class="btn" id="st-cancel">cancel</button>
      <button class="btn primary" id="st-save">save</button>
    </div>`);
  root.querySelector("#st-cancel")!.addEventListener("click", close);
  root.querySelector("#st-save")!.addEventListener("click", () => {
    patchSpace(sid, {
      name: (root.querySelector("#st-name") as HTMLInputElement).value.trim(),
      description: (root.querySelector("#st-desc") as HTMLInputElement).value.trim(),
      tags: (root.querySelector("#st-tags") as HTMLInputElement).value
        .split(",").map((t) => t.trim()).filter(Boolean),
      viewers: (root.querySelector("#st-viewers") as HTMLInputElement).value
        .split(",").map((v) => v.trim()).filter(Boolean),
      public: (root.querySelector("#st-public") as HTMLInputElement).checked,
    }).then((s) => {
      space = s;
      close();
      renderSpaceMeta();
    }).catch((e) => {
      const box = root.querySelector("#st-error") as HTMLElement;
      box.textContent = (e as Error).message;
      box.classList.remove("hidden");
    });
  });
}

// ---------------- branch create ----------------
function branchModal(): void {
  if (!space.can_edit) return;
  const { root, close } = openModal(`
    <h2>new branch</h2>
    <label class="field"><span class="lbl">branch name (letters, digits, - , _)</span>
      <input type="text" id="nb-name"></label>
    <label class="field"><span class="lbl">create from</span>
      <select id="nb-from">${Object.keys(space.branches).map((b) => `<option value="${b}">${b}</option>`).join("")}</select></label>
    <div class="error-box hidden" id="nb-error"></div>
    <div class="actions">
      <button class="btn" id="nb-cancel">cancel</button>
      <button class="btn primary" id="nb-go">create</button>
    </div>`);
  root.querySelector("#nb-cancel")!.addEventListener("click", close);
  root.querySelector("#nb-go")!.addEventListener("click", () => {
    const name = (root.querySelector("#nb-name") as HTMLInputElement).value.trim();
    const from = (root.querySelector("#nb-from") as HTMLSelectElement).value;
    createBranch(sid, name, from)
      .then(async () => {
        close();
        space = await getSpace(sid);
        branch = name;
        renderSpaceMeta();
        await loadTree();
        if (curPath) await openNote(curPath);
        else showEmptyState();
      })
      .catch((e) => {
        const box = root.querySelector("#nb-error") as HTMLElement;
        box.textContent = (e as Error).message;
        box.classList.remove("hidden");
      });
  });
}

function initBranchMergeButtons(): void {
  const sel = $("branch-select");
  const add = document.createElement("button");
  add.className = "btn small";
  add.textContent = "branch +";
  add.title = "create a new branch";
  add.onclick = branchModal;
  const mg = document.createElement("button");
  mg.className = "btn small";
  mg.textContent = "merge";
  mg.title = "merge another branch into the current one";
  mg.onclick = () => { void mergeModal(); };
  sel.insertAdjacentElement("afterend", mg);
  sel.insertAdjacentElement("afterend", add);
}

boot();
