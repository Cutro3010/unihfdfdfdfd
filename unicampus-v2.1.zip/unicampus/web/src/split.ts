// Split view: two panes, each showing any part of the site. Switch between
// horizontal (side by side) and vertical (top/bottom) splits, drag the
// divider, swap panes. Layout persists in localStorage.

import { initTheme, initBell, initUserArea } from "./common.js";

const $ = (id: string) => document.getElementById(id)!;

const QUICK = [
  ["home / forum", "/"],
  ["tests", "/tests.html"],
  ["calendar", "/calendar.html"],
  ["chats", "/chats.html"],
  ["leaderboard", "/leaderboard.html"],
  ["my room", "/room.html"],
];

let orient: "h" | "v" =
  (localStorage.getItem("uni-split-orient") as "h" | "v") || "h";
let leftUrl = localStorage.getItem("uni-split-left") || "/";
let rightUrl = localStorage.getItem("uni-split-right") || "/tests.html";
let ratio = Number(localStorage.getItem("uni-split-ratio") || 50);
ratio = Math.max(15, Math.min(85, ratio || 50));

// side by side is unusable on a narrow phone: stack the panes there, whatever was chosen
const narrow = window.matchMedia("(max-width: 720px)");
const effOrient = (): "h" | "v" => (narrow.matches ? "v" : orient);

function buildPanes(): void {
  const root = $("split-root");
  root.innerHTML = "";
  const eo = effOrient();
  root.className = "split-layout " + eo;

  const left = document.createElement("div");
  left.className = "split-pane";
  left.style.flex = `${ratio} 1 0`;
  const lf = document.createElement("iframe");
  lf.src = leftUrl;
  left.appendChild(lf);

  const divider = document.createElement("div");
  divider.className = "split-divider";
  divider.title = "drag to resize";

  const right = document.createElement("div");
  right.className = "split-pane";
  right.style.flex = `${100 - ratio} 1 0`;
    const rf = document.createElement("iframe");
  rf.src = rightUrl;
  right.appendChild(rf);

  root.append(left, divider, right);

  divider.addEventListener("pointerdown", (e) => {
    divider.setPointerCapture(e.pointerId);
    const rect = root.getBoundingClientRect();
    const move = (ev: PointerEvent) => {
      const pct = eo === "h"
        ? ((ev.clientX - rect.left) / rect.width) * 100
        : ((ev.clientY - rect.top) / rect.height) * 100;
      ratio = Math.max(15, Math.min(85, pct));
      left.style.flex = `${ratio} 1 0`; right.style.flex = `${100 - ratio} 1 0`;
    };
    const up = () => {
      divider.removeEventListener("pointermove", move);
      divider.removeEventListener("pointerup", up);
      localStorage.setItem("uni-split-ratio", String(Math.round(ratio)));
    };
    divider.addEventListener("pointermove", move);
    divider.addEventListener("pointerup", up);
  });
}

function fillQuick(sel: HTMLSelectElement, input: HTMLInputElement): void {
  sel.innerHTML = "";
  for (const [label, url] of QUICK) {
    const o = document.createElement("option");
    o.value = url;
    o.textContent = label;
    sel.appendChild(o);
  }
  sel.value = QUICK.some(([, u]) => u === input.value) ? input.value : QUICK[0][1];
}

function wire(): void {
  const hBtn = $("sp-h");
  const vBtn = $("sp-v");
  const setOrient = (o: "h" | "v") => {
    orient = o;
    localStorage.setItem("uni-split-orient", o);
    hBtn.classList.toggle("active", o === "h");
    vBtn.classList.toggle("active", o === "v");
    buildPanes();
  };
  hBtn.addEventListener("click", () => setOrient("h"));
  vBtn.addEventListener("click", () => setOrient("v"));
  hBtn.classList.toggle("active", orient === "h");
  vBtn.classList.toggle("active", orient === "v");

  const leftInp = $("sp-left") as HTMLInputElement;
  const rightInp = $("sp-right") as HTMLInputElement;
  const leftSel = $("sp-left-quick") as HTMLSelectElement;
  const rightSel = $("sp-right-quick") as HTMLSelectElement;
  leftInp.value = leftUrl;
  rightInp.value = rightUrl;
  fillQuick(leftSel, leftInp);
  fillQuick(rightSel, rightInp);
  leftSel.value = QUICK.some(([, u]) => u === leftUrl) ? leftUrl : "";
  rightSel.value = QUICK.some(([, u]) => u === rightUrl) ? rightUrl : "";

  const applyLeft = (url: string) => {
    const clean = url.trim() || "/";
    leftUrl = clean.startsWith("/") ? clean : "/" + clean;
    localStorage.setItem("uni-split-left", leftUrl);
    leftInp.value = leftUrl;
    buildPanes();
  };
  const applyRight = (url: string) => {
    const clean = url.trim() || "/";
    rightUrl = clean.startsWith("/") ? clean : "/" + clean;
    localStorage.setItem("uni-split-right", rightUrl);
    rightInp.value = rightUrl;
    buildPanes();
  };
  leftInp.addEventListener("keydown", (e) => {
    if (e.key === "Enter") applyLeft(leftInp.value);
  });
  rightInp.addEventListener("keydown", (e) => {
    if (e.key === "Enter") applyRight(rightInp.value);
  });
  leftSel.addEventListener("change", () => { if (leftSel.value) applyLeft(leftSel.value); });
  rightSel.addEventListener("change", () => { if (rightSel.value) applyRight(rightSel.value); });

  wireFullscreen();

  $("sp-swap").addEventListener("click", () => {
    const t = leftUrl;
    leftUrl = rightUrl;
    rightUrl = t;
    localStorage.setItem("uni-split-left", leftUrl);
    localStorage.setItem("uni-split-right", rightUrl);
    leftInp.value = leftUrl;
    rightInp.value = rightUrl;
    buildPanes();
  });
}

// Fullscreen keeps the toolbar and both panes; only the browser chrome goes away.
// (iPhone Safari has no element fullscreen, so the button stays hidden there.)
function wireFullscreen(): void {
  const btn = $("sp-full");
  const main = $("split-main") as HTMLElement & { webkitRequestFullscreen?: () => Promise<void> };
  const doc = document as Document & {
    webkitFullscreenEnabled?: boolean; webkitFullscreenElement?: Element | null; webkitExitFullscreen?: () => void;
  };
  if (!(doc.fullscreenEnabled || doc.webkitFullscreenEnabled)) return;
  btn.classList.remove("hidden");
  const isFull = () => !!(doc.fullscreenElement || doc.webkitFullscreenElement);
  const sync = () => { btn.textContent = isFull() ? "⛶ exit fullscreen" : "⛶ fullscreen"; };
  btn.addEventListener("click", () => {
    if (isFull()) {
      if (doc.exitFullscreen) void doc.exitFullscreen(); else doc.webkitExitFullscreen?.();
    } else if (main.requestFullscreen) {
      void main.requestFullscreen();
    } else {
      void main.webkitRequestFullscreen?.();
    }
  });
  document.addEventListener("fullscreenchange", sync);
  document.addEventListener("webkitfullscreenchange", sync);
  sync();
}

narrow.addEventListener("change", () => buildPanes());

async function boot(): Promise<void> {
  initTheme();
  initBell();
  await initUserArea();
  wire();
  buildPanes();
}

boot();
