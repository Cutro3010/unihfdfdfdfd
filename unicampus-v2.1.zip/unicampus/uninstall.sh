#!/usr/bin/env bash
# ============================================================
# Uniheaven uninstaller - Ubuntu / Debian
#
#   sudo bash uninstall.sh            # remove the app, KEEP data + backups
#   sudo bash uninstall.sh --purge    # remove the app AND all data/backups
#   sudo bash uninstall.sh --dry-run  # show what would be removed
#
# The CLI (`space`) is removed with:  sudo bash install_cli.sh --remove
# ============================================================
set -euo pipefail

APP=/opt/uniheaven
SVC_USER=uniheaven
SERVICE=uniheaven.service
PURGE=0
DRY=0
for arg in "$@"; do
  case "$arg" in
    --purge) PURGE=1 ;;
    --dry-run) DRY=1 ;;
  esac
done

if [[ $EUID -ne 0 ]]; then
  echo "run as root: sudo bash uninstall.sh"
  exit 1
fi

run() {
  if [[ $DRY -eq 1 ]]; then
    echo "dry-run: $*"
  else
    "$@"
  fi
}

echo ">> stopping and removing the systemd service"
if systemctl list-unit-files 2>/dev/null | grep -q "^$SERVICE"; then
  run systemctl stop "$SERVICE" 2>/dev/null || true
  run systemctl disable "$SERVICE" 2>/dev/null || true
fi
run rm -f "/etc/systemd/system/$SERVICE"
if [[ $DRY -eq 0 ]]; then
  systemctl daemon-reload 2>/dev/null || true
fi

echo ">> removing the nightly backup cron job"
run rm -f /etc/cron.daily/uniheaven-backup

echo ">> removing app files"
if [[ -d "$APP" ]]; then
  run rm -rf "$APP/web"
  run rm -f "$APP/server.py" "$APP/space.py" "$APP/README.md" "$APP/STYLE.md"
fi

if [[ $PURGE -eq 1 ]]; then
  echo "!! --purge: deleting all data and backups"
  run rm -rf "$APP/data" "$APP/backups"
  run rmdir "$APP" 2>/dev/null || true
else
  echo ">> keeping $APP/data and $APP/backups"
  echo "   (re-run with --purge to delete them too)"
  run rmdir "$APP" 2>/dev/null || true
fi

echo ">> removing the unprivileged service user"
if id -u "$SVC_USER" >/dev/null 2>&1; then
  run userdel "$SVC_USER" 2>/dev/null || true
fi

echo ""
echo "================================================"
echo " uniheaven removed."
if [[ $PURGE -eq 0 && -d "$APP/data" ]]; then
  echo " your data is still at $APP/data - back it up:"
  echo "   sudo tar -czf uniheaven-data.tar.gz -C $APP data"
fi
echo " if you opened a firewall port, remove it, e.g.:"
echo "   sudo ufw status | grep 8000"
echo "================================================"
