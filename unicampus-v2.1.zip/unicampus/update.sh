#!/usr/bin/env bash
# ============================================================
# Uniheaven updater
#
#   1. asks for your repo URL
#   2. makes a FULL recovery copy of the app (code + data)
#   3. makes a separate copy of the data folder alone
#   4. clones the repo and runs the installer (data preserved)
#
#   sudo bash update.sh            # interactive
#   sudo bash update.sh --branch dev --dry-run
# ============================================================
set -euo pipefail

APP=/opt/uniheaven
BACKUP_ROOT=/root/backups/uniheaven
BRANCH=main
DRY=0
for arg in "$@"; do
  case "$arg" in
    --branch) BRANCH="${2:-main}"; shift ;;
    --branch=*) BRANCH="${arg#*=}"; shift ;;
    --dry-run) DRY=1 ;;
  esac
done

if [[ $EUID -ne 0 ]]; then
  echo "run as root: sudo bash update.sh"
  exit 1
fi

if ! command -v git >/dev/null 2>&1; then
  echo "git is missing. install it with:  sudo apt install -y git"
  exit 1
fi

run() {
  if [[ $DRY -eq 1 ]]; then
    echo "dry-run: $*"
  else
    "$@"
  fi
}

echo ""
echo "================================================"
echo " uniheaven updater"
echo "================================================"
echo ""

read -r -p "repo url (e.g. https://github.com/you/uniheaven): " REPO
if [[ -z "$REPO" ]]; then
  echo "no repo url given - aborting."
  exit 1
fi
echo ">> branch: $BRANCH"

STAMP="$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP_ROOT"

# 1. full recovery copy (app + data, one tarball)
if [[ -d "$APP" ]]; then
  echo ">> full recovery copy -> $BACKUP_ROOT/uniheaven-full-$STAMP.tar.gz"
  run tar -czf "$BACKUP_ROOT/uniheaven-full-$STAMP.tar.gz" -C "$(dirname "$APP")" "$(basename "$APP")"
fi

# 2. singular copy of the data folder
if [[ -d "$APP/data" ]]; then
  echo ">> data copy -> $BACKUP_ROOT/uniheaven-data-$STAMP.tar.gz"
  run tar -czf "$BACKUP_ROOT/uniheaven-data-$STAMP.tar.gz" -C "$APP" data
fi

# keep the last 10 backups of each kind
run bash -c "ls -t '$BACKUP_ROOT'/uniheaven-full-*.tar.gz 2>/dev/null | tail -n +11 | xargs -r rm -f"
run bash -c "ls -t '$BACKUP_ROOT'/uniheaven-data-*.tar.gz 2>/dev/null | tail -n +11 | xargs -r rm -f"

# 3. clone and install
TMP="$(mktemp -d)"
echo ">> cloning $REPO (branch $BRANCH)…"
run git clone --depth 1 --branch "$BRANCH" "$REPO" "$TMP/repo"

echo ">> installing from the fresh checkout…"
if [[ $DRY -eq 1 ]]; then
  echo "dry-run: would run: bash $TMP/repo/install.sh"
else
  ( cd "$TMP/repo" && bash install.sh )
fi

run rm -rf "$TMP"

echo ""
echo "================================================"
echo " update finished."
echo "   backups:  $BACKUP_ROOT/uniheaven-full-$STAMP.tar.gz"
if [[ -d "$APP/data" ]]; then
  echo "             $BACKUP_ROOT/uniheaven-data-$STAMP.tar.gz"
fi
echo "   status:   systemctl status uniheaven"
echo "   admin pw: journalctl -u uniheaven | grep 'admin page'"
echo "================================================"
