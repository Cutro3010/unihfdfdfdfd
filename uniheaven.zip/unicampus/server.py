#!/usr/bin/env python3
"""
Uniheaven server - a tiny self-hosted note space for university students.

Pure Python 3 standard library. No frameworks, no SQL.
Data lives in <datadir>/ as JSON files and content-addressed .md objects.

Run:  python server.py [--host 0.0.0.0] [--port 8000] [--datadir ./data]
"""

import argparse
import difflib
import hashlib
import io
import json
import os
import re
import secrets
import sys
import threading
import time
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

ROOT = Path(__file__).resolve().parent
WEB = ROOT / "web"
DEFAULT_DATA = ROOT / "data"

SESSION_TTL = 30 * 24 * 3600          # 30 days
SESSION_TOKENS = 32                   # hex chars
PBKDF2_ITER = 120_000
NOTE_MAX_BYTES = 1_000_000            # per-note cap
LOGIN_WINDOW = 600                    # rate-limit window (s)
LOGIN_MAX_TRIES = 8
REGISTER_WINDOW = int(os.environ.get("UNI_REGISTER_WINDOW", "3600"))
REGISTER_MAX_TRIES = int(os.environ.get("UNI_REGISTER_MAX", "5"))
MAX_USERS = int(os.environ.get("UNI_MAX_USERS", "0"))   # 0 = unlimited
IMPORT_MAX_BYTES = 50 * 1024 * 1024   # zip upload cap
IMPORT_UNZIP_BUDGET = 64 * 1024 * 1024  # cap on uncompressed zip contents
IMPORT_MAX_FILES = 500
ACTIVITY_CAP = 500
NOTIF_CAP = 100
DISK_BUDGET = 9.5 * 1024**3           # warn/refuse near the 10 GB VPS budget

MENTION_RE = re.compile(r"(?<![\w@])@([A-Za-z0-9_-]{1,32})")
DUE_RE = re.compile(r"^@due\s+(\d{4}-\d{2}-\d{2})\s*$", re.M)
SAFE_PATH_RE = re.compile(r"[^\w\-. /()@]")
BRANCH_RE = re.compile(r"[A-Za-z0-9_-]{1,32}")
SPACE_NAME_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9 ,._()@&'+-]{0,63}")
WORD_RE = re.compile(r"[a-z0-9]+")
STOPWORDS = set("""a about after again all also an and any are as at be because
been before being between both but by can could did do does doing down each
few for from further had has have having he her here hers him his how i if
in into is it its just like may me more most my no nor not now of off on once
only or other our out over own same she should so some such than that the
their them then there these they this those through to too under until up
very was we were what when where which while who why will with would you your
yours""".split())
PROFILE_LOGO_PREFIX = "data:image/png;base64,"
PROFILE_LOGO_MAX = 30 * 1024

# ---- admin page (separate from user accounts) --------------------------------
ADMIN_USER = "eye"                                  # reserved username
# The admin password is NOT hardcoded: it is generated on first start (or taken
# from $UNI_ADMIN_PASSWORD), stored PBKDF2-hashed in data/admin_creds.json and
# printed once to stderr (the journal).

# ---- major arcana (each user may hold at most two) ---------------------------
ARCADA = [
    "The Fool", "The Magician", "The High Priestess", "The Empress",
    "The Emperor", "The Hierophant", "The Lovers", "The Chariot",
    "Strength", "The Hermit", "Wheel of Fortune", "Justice",
    "The Hanged Man", "Death", "Temperance", "The Devil", "The Tower",
    "The Star", "The Moon", "The Sun", "Judgement", "The World",
]
ARCADA_MAX = 2

_wlock = threading.Lock()             # serializes every data mutation
_login_fails = {}                     # {(ip, user): [ts, ...]}
_register_fails = {}                  # {ip: [ts, ...]}  registration rate limit


# ---------------------------------------------------------------- storage ---

def jload(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def jsave(path, obj):
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


def sha16(data):
    return hashlib.sha1(data.encode("utf-8")).hexdigest()


def now():
    return time.time()


class Store:
    """Handles every file under the data dir; all mutators hold _wlock."""

    def __init__(self, datadir):
        self.dir = Path(datadir)
        self.dir.mkdir(parents=True, exist_ok=True)
        (self.dir / "spaces").mkdir(exist_ok=True)

    # -- flat json files -----------------------------------------------------
    @property
    def users_path(self):      return self.dir / "users.json"
    @property
    def sessions_path(self):   return self.dir / "sessions.json"
    @property
    def stars_path(self):      return self.dir / "stars.json"
    @property
    def activity_path(self):   return self.dir / "activity.json"
    @property
    def notif_path(self):      return self.dir / "notifications.json"
    @property
    def profiles_path(self):   return self.dir / "profiles.json"
    @property
    def posts_path(self):      return self.dir / "posts.json"
    @property
    def deadlines_path(self):  return self.dir / "deadlines.json"
    @property
    def reading_path(self):    return self.dir / "reading.json"
    @property
    def arcana_path(self):     return self.dir / "arcana.json"
    @property
    def votes_path(self):      return self.dir / "votes.json"
    @property
    def admin_sessions_path(self): return self.dir / "admin_sessions.json"

    def users(self):      return jload(self.users_path, {})
    def sessions(self):   return jload(self.sessions_path, {})
    def stars(self):      return jload(self.stars_path, {})
    def activity(self):   return jload(self.activity_path, [])
    def notifs(self):     return jload(self.notif_path, {})
    def profiles(self):   return jload(self.profiles_path, {})
    def posts(self):      return jload(self.posts_path, [])
    def deadlines(self):  return jload(self.deadlines_path, [])
    def reading(self):    return jload(self.reading_path, {})
    def arcana(self):     return jload(self.arcana_path, {})
    def votes(self):      return jload(self.votes_path, {})
    def admin_sessions(self): return jload(self.admin_sessions_path, {})

    # -- spaces ---------------------------------------------------------------
    def space_dir(self, sid):
        d = (self.dir / "spaces" / sid).resolve()
        root = (self.dir / "spaces").resolve()
        if not str(d).startswith(str(root)):          # sid comes from our own id
            raise ValueError("bad space id")          # pool only; belt & braces
        return d

    def metas(self):
        out = {}
        for d in (self.dir / "spaces").iterdir():
            if d.is_dir() and (d / "meta.json").exists():
                m = jload(d / "meta.json", None)
                if m:
                    out[m["id"]] = m
        return out

    def meta(self, sid):
        return jload(self.space_dir(sid) / "meta.json", None)

    def tree(self, sid, branch, rev=None):
        if not valid_branch(branch):          # belt & braces: no traversal, ever
            raise ValueError("bad branch")
        sd = self.space_dir(sid)
        revlog = jload(sd / "revlogs" / f"{branch}.json", [])
        head = revlog[-1]["rev"] if revlog else 0
        if rev is None:
            rev = head
        if rev < 0 or rev > head:
            return None, rev
        return jload(sd / "trees" / branch / f"{rev}.json", {}), rev

    def object_text(self, sid, sha):
        p = self.space_dir(sid) / "objects" / f"{sha}.md"
        try:
            return p.read_text(encoding="utf-8")
        except FileNotFoundError:
            return None

    def disk_usage(self):
        total = 0
        for root, _dirs, files in os.walk(self.dir):
            for fn in files:
                try:
                    total += (Path(root) / fn).stat().st_size
                except OSError:
                    pass
        return total

    # -- activity / notifications ---------------------------------------------
    def log_activity(self, user, action, sid, space_name, path=None, summary=""):
        with _wlock:
            acts = self.activity()
            acts.insert(0, {"time": now(), "user": user, "action": action,
                            "space": sid, "space_name": space_name,
                            "path": path, "summary": summary})
            del acts[ACTIVITY_CAP:]
            jsave(self.activity_path, acts)

    def notify(self, target, ntype, actor, sid, space_name, path, text, anchor=None):
        with _wlock:
            nf = self.notifs()
            lst = nf.setdefault(target, [])
            lst.insert(0, {"id": secrets.token_hex(8), "time": now(), "read": False,
                           "type": ntype, "actor": actor, "space": sid,
                           "space_name": space_name, "path": path,
                           "anchor": anchor, "text": text[:120]})
            del lst[NOTIF_CAP:]
            jsave(self.notif_path, nf)


STORE = None  # set in main()


# ---------------------------------------------------------------- helpers ---

def err(msg, status=400):
    return status, {"error": msg}


def valid_username(u):
    return bool(u) and re.fullmatch(r"[A-Za-z0-9_-]{2,32}", u or "") is not None


def valid_space_name(n):
    """Space names: 1-64 chars from a safe set (no CR/LF, no quotes, ASCII)."""
    return bool(n) and SPACE_NAME_RE.fullmatch(n or "") is not None


def valid_branch(b):
    return bool(b) and BRANCH_RE.fullmatch(b or "") is not None


def safe_filename(name):
    """ASCII-safe, header-safe filename for downloads."""
    name = re.sub(r"[^A-Za-z0-9 ,._()@&'+\-]", "_", name or "space").strip()
    return (name or "space")[:80]


def ok_path(p):
    """Note paths are relative, forward-slash separated, no traversal."""
    if not p or len(p) > 240:
        return False
    if "\\" in p or p.startswith("/") or any(c in p for c in "\x00\r\n\t"):
        return False
    parts = p.split("/")
    if any(x in ("", ".", "..") or ":" in x for x in parts):
        return False
    return True


def hash_pw(password, salt=None):
    salt = salt or secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"),
                             bytes.fromhex(salt), PBKDF2_ITER)
    return salt, dk.hex()


def new_session(username):
    with _wlock:
        sessions = STORE.sessions()
        sessions = {t: s for t, s in sessions.items()
                    if s["expires"] > now()}          # lazy cleanup
        token = secrets.token_hex(SESSION_TOKENS // 2)
        sessions[token] = {"user": username, "expires": now() + SESSION_TTL}
        jsave(STORE.sessions_path, sessions)
        return token


def drop_session(token):
    with _wlock:
        sessions = STORE.sessions()
        sessions.pop(token, None)
        jsave(STORE.sessions_path, sessions)


def admin_creds():
    """Load (or generate once) the admin panel password record.

    The admin password is random per installation (or $UNI_ADMIN_PASSWORD),
    stored PBKDF2-hashed in data/admin_creds.json and printed once to stderr.
    """
    p = STORE.dir / "admin_creds.json"
    rec = jload(p, None)
    if rec and rec.get("salt") and rec.get("hash"):
        return rec
    pw = os.environ.get("UNI_ADMIN_PASSWORD") or secrets.token_urlsafe(12)
    salt, dk = hash_pw(pw)
    rec = {"salt": salt, "hash": dk}
    with _wlock:
        jsave(p, rec)
    if os.environ.get("UNI_ADMIN_PASSWORD"):
        sys.stderr.write("admin credentials initialized from $UNI_ADMIN_PASSWORD\n")
    else:
        sys.stderr.write(
            "\nuniheaven admin page (/admin.html): username '%s', password: %s\n"
            "(generated once, stored hashed in %s)\n" % (ADMIN_USER, pw, p))
    return rec


def prune_rate_limits():
    """Drop expired rate-limit timestamps (called by the watcher thread)."""
    cutoff = now() - max(LOGIN_WINDOW, REGISTER_WINDOW)
    for table in (_login_fails, _register_fails):
        for key in list(table):
            table[key] = [t for t in table[key] if t > cutoff]
            if not table[key]:
                del table[key]


def public_user(u):
    return {"username": u["username"], "display_name": u.get("display_name"),
            "admin": u.get("admin", False), "created": u.get("created")}


def space_view(sid, user):
    """Public JSON shape of a space for a viewer."""
    m = STORE.meta(sid)
    stars = STORE.stars()
    return {"id": m["id"], "name": m["name"], "owner": m["owner"],
            "description": m.get("description", ""),
            "tags": m.get("tags", []), "public": m.get("public", True),
            "created": m.get("created"), "forked_from": m.get("forked_from"),
            "branches": m.get("branches", {}),
            "collaborators": m.get("collaborators", []),
            "viewers": m.get("viewers", []),
            "can_edit": can_edit(sid, user),
            "starred": user is not None and m["id"] in stars.get(user["username"], []),
            "star_count": sum(1 for v in stars.values() if m["id"] in v)}


def visible_spaces(user):
    uname = user["username"] if user else None
    out = []
    for m in STORE.metas().values():
        if (m.get("public", True) or (uname and (
                uname == m["owner"]
                or uname in m.get("collaborators", [])
                or uname in m.get("viewers", [])))):
            out.append(space_view(m["id"], user))
    out.sort(key=lambda s: s["created"], reverse=True)
    return out


def redact_activity(acts, user):
    """Hide private-space details from feed viewers who cannot see the space."""
    uname = user["username"] if user else None
    metas = STORE.metas()
    out = []
    for a in acts:
        sid = a.get("space")
        m = metas.get(sid) if sid else None
        if m and not (m.get("public", True) or (uname and (
                uname == m["owner"]
                or uname in m.get("collaborators", [])
                or uname in m.get("viewers", [])))):
            a = dict(a)
            a["space"] = None
            a["space_name"] = "a private space"
            a["path"] = None
            a["summary"] = None
        out.append(a)
    return out


def add_mention_notifs(actor, sid, path, text, anchor=None):
    m = STORE.meta(sid) if sid else None
    space_name = m["name"] if m else None
    users = STORE.users()
    for name in set(MENTION_RE.findall(text or "")):
        if name in users and name != actor["username"]:
            STORE.notify(name, "mention", actor["username"], sid,
                         space_name, path, text, anchor=anchor)


# ------------------------------------------------------------- deadlines ---

def due_from_content(content):
    """A note carries its deadline as a '@due YYYY-MM-DD' line."""
    m = DUE_RE.search(content or "")
    if not m:
        return None
    try:
        return time.mktime(time.strptime(m.group(1), "%Y-%m-%d"))  # local midnight
    except (ValueError, OverflowError):
        return None


def sync_deadline(sid, space_name, path, content, username):
    """Upsert the deadline record for one note. Caller holds _wlock."""
    dl = STORE.deadlines()
    old = next((d for d in dl if d["space"] == sid and d["path"] == path), None)
    dl = [d for d in dl if not (d["space"] == sid and d["path"] == path)]
    due = due_from_content(content)
    if due:
        dl.append({"space": sid, "space_name": space_name, "path": path,
                   "due": due, "user": username,
                   "reminded_24": bool(old and old.get("due") == due
                                       and old.get("reminded_24")),
                   "reminded_day": bool(old and old.get("due") == due
                                        and old.get("reminded_day"))})
    jsave(STORE.deadlines_path, dl)


def check_deadlines():
    """One sweep: remind day-before and day-of, drop stale records."""
    now_ts = now()
    to_send = []
    with _wlock:
        dl = STORE.deadlines()
        keep, changed = [], False
        for d in dl:
            if not STORE.meta(d["space"]):
                changed = True
                continue
            if now_ts > d["due"] + 2 * 86400:          # long past: forget it
                changed = True
                continue
            if now_ts < d["due"] - 2 * 86400:          # far future: leave alone
                keep.append(d)
                continue
            if now_ts >= d["due"] and not d.get("reminded_day"):
                d["reminded_day"] = True
                changed = True
                to_send.append((d["user"], "deadline_today", d,
                                "due today · %s" % d["path"]))
            elif now_ts >= d["due"] - 86400 and not d.get("reminded_24"):
                d["reminded_24"] = True
                changed = True
                to_send.append((d["user"], "deadline_soon", d,
                                "due tomorrow · %s" % d["path"]))
            keep.append(d)
        if changed:
            jsave(STORE.deadlines_path, keep)
    for target, ntype, d, text in to_send:
        STORE.notify(target, ntype, None, d["space"], d["space_name"],
                     d["path"], text)


def deadline_watcher():
    while True:
        try:
            check_deadlines()
            prune_rate_limits()
        except Exception as e:                          # never die silently
            sys.stderr.write("deadline watcher: %s\n" % e)
        time.sleep(60)


def new_revision(sid, branch, author, message, changes, ensure_path=None):
    """Append a rev to a branch revlog + write its tree snapshot."""
    if not valid_branch(branch):
        raise ValueError("bad branch")
    sd = STORE.space_dir(sid)
    revlog = jload(sd / "revlogs" / f"{branch}.json", [])
    parent = revlog[-1]["rev"] if revlog else 0
    parent_tree, _ = STORE.tree(sid, branch)
    tree = dict(parent_tree)
    for ch in changes:
        path, old_sha, new_sha = ch["path"], ch["old_sha"], ch["new_sha"]
        if new_sha is None:
            tree.pop(path, None)
        else:
            tree[path] = new_sha
    rev = parent + 1
    revlog.append({"rev": rev, "parent": parent, "author": author,
                   "time": now(), "message": message or "",
                   "changes": changes})
    tdir = sd / "trees" / branch
    tdir.mkdir(parents=True, exist_ok=True)
    jsave(tdir / f"{rev}.json", tree)
    jsave(sd / "revlogs" / f"{branch}.json", revlog)
    # keep the search index in sync
    idx = jload(sd / "search_index.json", {})
    for ch in changes:
        if ch["new_sha"] is None:
            idx.pop(ch["path"], None)
        else:
            txt = STORE.object_text(sid, ch["new_sha"]) or ""
            idx[ch["path"]] = re.sub(r"\s+", " ", txt).lower()[:4000]
    jsave(sd / "search_index.json", idx)
    return rev


def can_view(sid, user):
    """Public spaces are open; private ones allow owner + collabs + viewers."""
    m = STORE.meta(sid)
    if m is None:
        return False
    if m.get("public", True):
        return True
    if not user:
        return False
    return (user["username"] == m["owner"]
            or user["username"] in m.get("collaborators", [])
            or user["username"] in m.get("viewers", []))


def can_edit(sid, user):
    """Owner or listed collaborator can edit a space."""
    if not user:
        return False
    m = STORE.meta(sid)
    return m is not None and (user["username"] == m["owner"]
                              or user["username"] in m.get("collaborators", []))


def profile_stats(username):
    """Aggregate stats about a user from spaces, revlogs and comments."""
    metas = STORE.metas()
    owned = [m for m in metas.values() if m["owner"] == username]
    tag_count, word_count, day_count = {}, {}, {}
    notes_n = revs_n = 0
    for m in owned:
        sd = STORE.space_dir(m["id"])
        for t in m.get("tags", []):
            tag_count[t] = tag_count.get(t, 0) + 1
        tree, _ = STORE.tree(m["id"], "main")
        notes_n += len(tree)
        for sha in tree.values():
            txt = (STORE.object_text(m["id"], sha) or "").lower()
            for w in WORD_RE.findall(txt):
                if len(w) >= 4 and w not in STOPWORDS and not w.isdigit():
                    word_count[w] = word_count.get(w, 0) + 1
        for branch in m.get("branches", {}):
            for r in jload(sd / "revlogs" / f"{branch}.json", []):
                if r["author"] == username:
                    revs_n += 1
                    day = time.strftime("%Y-%m-%d", time.localtime(r["time"]))
                    day_count[day] = day_count.get(day, 0) + 1
    comments_n = 0
    for m in metas.values():
        cm = jload(STORE.space_dir(m["id"]) / "comments.json", [])
        comments_n += sum(1 for c in cm if c["author"] == username)
    spark = []
    for i in range(55, -1, -1):
        d = time.strftime("%Y-%m-%d", time.localtime(time.time() - i * 86400))
        spark.append({"day": d, "count": day_count.get(d, 0)})
    recent = [a for a in STORE.activity() if a["user"] == username][:20]
    return {
        "spaces": len(owned),
        "notes": notes_n,
        "revisions": revs_n,
        "comments": comments_n,
        "stars_given": len(STORE.stars().get(username, [])),
        "tags": sorted(tag_count.items(), key=lambda x: -x[1])[:12],
        "words": sorted(word_count.items(), key=lambda x: -x[1])[:24],
        "sparkline": spark,
        "recent": recent,
    }


# ------------------------------------------------------------------ server ---

class Handler(BaseHTTPRequestHandler):
    server_version = "uniheaven/1.0"

    # -- plumbing ------------------------------------------------------------
    def log_message(self, fmt, *args):
        sys.stderr.write("[%s] %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"),
                                        fmt % args))

    def send_json(self, status, obj, headers=None):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def read_body(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            n = 0
        if n <= 0:
            return {}
        raw = self.rfile.read(min(n, 4 * 1024 * 1024))
        try:
            return json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return None

    def current_user(self):
        token = None
        auth = self.headers.get("Authorization") or ""
        if auth.startswith("Bearer "):
            token = auth[7:].strip()
        if not token:
            cookie = self.headers.get("Cookie") or ""
            m = re.search(r"(?:^|;\s*)uni_sid=([0-9a-f]+)", cookie)
            token = m.group(1) if m else None
        if not token:
            return None
        sess = STORE.sessions().get(token)
        if not sess or sess["expires"] < now():
            return None
        u = STORE.users().get(sess["user"])
        return {"username": sess["user"], "display_name": u.get("display_name"),
                "admin": u.get("admin", False), "created": u.get("created")} if u else None

    def require(self):
        u = self.current_user()
        if not u:
            self.send_json(*err("login required", 401))
        return u

    # -- static files ----------------------------------------------------------
    def serve_static(self, path):
        if path == "/":
            path = "/index.html"
        rel = unquote(path).lstrip("/")
        target = (WEB / rel).resolve()
        if not str(target).startswith(str(WEB.resolve())) or not target.is_file():
            self.send_error(404)
            return
        ctype = {"html": "text/html; charset=utf-8",
                 "css": "text/css; charset=utf-8",
                 "js": "text/javascript; charset=utf-8",
                 "mjs": "text/javascript; charset=utf-8",
                 "json": "application/json",
                 "map": "application/json",
                 "svg": "image/svg+xml", "png": "image/png",
                 "ico": "image/x-icon", "woff": "font/woff",
                 "woff2": "font/woff2", "ttf": "font/ttf",
                 "txt": "text/plain; charset=utf-8",
                 "md": "text/plain; charset=utf-8"}.get(target.suffix[1:],
                                                        "application/octet-stream")
        data = target.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        if path.endswith(".html"):
            self.send_header("Cache-Control", "no-cache")
        else:
            self.send_header("Cache-Control", "max-age=3600")
        self.end_headers()
        self.wfile.write(data)

    # -- routing -----------------------------------------------------------------
    def do_GET(self):
        self.route("GET")

    def do_POST(self):
        self.route("POST")

    def do_PUT(self):
        self.route("PUT")

    def do_PATCH(self):
        self.route("PATCH")

    def do_DELETE(self):
        self.route("DELETE")

    def route(self, method):
        u = urlparse(self.path)
        path = u.path
        q = parse_qs(u.query)
        try:
            if path.startswith("/api/"):
                self.api(method, path[5:], q)
            elif method == "GET":
                self.serve_static(path)
            else:
                self.send_json(*err("not found", 404))
        except BrokenPipeError:
            pass
        except Exception as e:
            try:
                self.send_json(500, {"error": "internal error: %s" % e})
            except (BrokenPipeError, ConnectionResetError):
                pass

    # --------------------------------------------------------------- API ---
    def api(self, method, p, q):
        parts = [x for x in p.split("/") if x]
        if not parts:
            return self.send_json(*err("bad route", 404))

        # ---- auth ----
        if parts[0] == "register" and method == "POST":
            return self.api_register()
        if parts[0] == "login" and method == "POST":
            return self.api_login()
        if parts[0] == "logout" and method == "POST":
            user = self.current_user()
            cookie = self.headers.get("Cookie") or ""
            m = re.search(r"(?:^|;\s*)uni_sid=([0-9a-f]+)", cookie)
            if m:
                drop_session(m.group(1))
            auth = self.headers.get("Authorization") or ""
            if auth.startswith("Bearer "):
                drop_session(auth[7:].strip())
            return self.send_json(200, {"ok": True})
        if parts[0] == "me":
            user = self.current_user()
            return self.send_json(200, {"user": public_user(user) if user else None})
        if parts[0] == "users":
            if len(parts) == 1 and method == "GET":
                user = self.current_user()
                if not user:
                    return self.send_json(401, {"error": "login required"})
                prefix = (q.get("prefix", [""])[0] or "").lower()
                all_users = STORE.users()
                return self.send_json(200, {"users": [u for u in all_users
                                                      if u.lower().startswith(prefix)][:20]})
            if len(parts) == 3 and parts[2] == "profile":
                return self.api_profile(parts[1])
        if parts[0] == "tags":
            counts = {}
            for m in STORE.metas().values():
                for t in m.get("tags", []):
                    counts[t] = counts.get(t, 0) + 1
            return self.send_json(200, {"tags": counts})
        if parts[0] == "activity":
            acts = redact_activity(STORE.activity()[:100], self.current_user())
            return self.send_json(200, {"activity": acts})

        # ---- admin page (own credentials, own session) ----
        if parts[0] == "admin":
            return self.api_admin(parts[1:], method)

        # ---- everything below needs a user ----
        user = self.require()
        if not user:
            return

        if parts[0] == "notifications":
            if len(parts) == 1 and method == "GET":
                lst = STORE.notifs().get(user["username"], [])
                return self.send_json(200, {"notifications": lst,
                                            "unread": sum(1 for n in lst if not n["read"])})
            if len(parts) == 2 and parts[1] == "read" and method == "POST":
                body = self.read_body() or {}
                ids = set(body.get("ids") or [])
                with _wlock:
                    nf = STORE.notifs()
                    for n in nf.get(user["username"], []):
                        if not ids or n["id"] in ids:
                            n["read"] = True
                    jsave(STORE.notif_path, nf)
                return self.send_json(200, {"ok": True})
            return self.send_json(*err("bad route", 404))

        if parts[0] == "deadlines" and len(parts) == 1 and method == "GET":
            out = [d for d in STORE.deadlines()
                   if d["user"] == user["username"] and STORE.meta(d["space"])]
            out.sort(key=lambda d: d["due"])
            return self.send_json(200, {"deadlines": out})

        if parts[0] == "reading" and len(parts) == 1:
            if method == "GET":
                lst = [x for x in STORE.reading().get(user["username"], [])
                       if STORE.meta(x["space"])]
                return self.send_json(200, {"reading": lst})
            if method == "POST":
                body = self.read_body() or {}
                sid = (body.get("space") or "").strip()
                path = (body.get("path") or "").strip()
                anchor = (body.get("anchor") or "").strip()
                if not sid or not can_view(sid, user):
                    return self.send_json(*err("not found or private", 404))
                if path and not ok_path(path):
                    return self.send_json(*err("bad path"))
                if anchor and not anchor.startswith("#"):
                    anchor = ""
                anchor = anchor[:80]
                m = STORE.meta(sid)
                with _wlock:
                    rd = STORE.reading()
                    lst = rd.setdefault(user["username"], [])
                    lst = [x for x in lst
                           if not (x["space"] == sid and x["path"] == path)]
                    lst.insert(0, {"space": sid, "space_name": m["name"],
                                   "path": path, "anchor": anchor,
                                   "time": now()})
                    del lst[30:]
                    rd[user["username"]] = lst
                    jsave(STORE.reading_path, rd)
                return self.send_json(200, {"ok": True})

        if parts[0] == "posts" and len(parts) == 1 and method == "GET":
            return self.api_posts()
        if parts[0] == "posts" and len(parts) == 1 and method == "POST":
            return self.api_post_create()
        if parts[0] == "posts" and len(parts) == 2 and method == "DELETE":
            return self.api_post_delete(parts[1])
        if parts[0] == "posts" and len(parts) == 3 and parts[2] == "vote" and method == "POST":
            return self.api_post_vote(parts[1], user)

        if parts[0] == "search":
            qs = (q.get("q", [""])[0] or "").strip().lower()
            if not qs:
                return self.send_json(200, {"spaces": [], "notes": []})
            words = qs.split()
            spaces, notes = [], []
            for sid, m in STORE.metas().items():
                if not can_view(sid, user):
                    continue
                idx = jload(STORE.space_dir(sid) / "search_index.json", {})
                for path, text in idx.items():
                    if all(w in text for w in words):
                        notes.append({"space": sid, "space_name": m["name"],
                                      "path": path})
            for m in visible_spaces(user):
                blob = " ".join([m["name"], m.get("description", ""),
                                 " ".join(m.get("tags", []))]).lower()
                if all(w in blob for w in words):
                    spaces.append({"id": m["id"], "name": m["name"],
                                   "owner": m["owner"], "tags": m["tags"]})
            return self.send_json(200, {"spaces": spaces, "notes": notes})

        if parts[0] == "spaces" and len(parts) == 1 and method == "GET":
            return self.send_json(200, {"spaces": visible_spaces(user)})

        if parts[0] == "spaces" and len(parts) == 1 and method == "POST":
            body = self.read_body()
            if body is None:
                return self.send_json(*err("invalid JSON"))
            name = (body.get("name") or "").strip()
            if not valid_space_name(name):
                return self.send_json(*err("space name must be 1-64 chars"))
            with _wlock:
                sid = secrets.token_hex(4)
                sd = STORE.space_dir(sid)
                sd.mkdir(parents=True, exist_ok=True)
                for sub in ("objects", "trees", "revlogs"):
                    (sd / sub).mkdir(exist_ok=True)
                meta = {"id": sid, "name": name, "owner": user["username"],
                        "description": (body.get("description") or "").strip()[:500],
                        "tags": [t.strip().lower() for t in
                                 body.get("tags") or [] if t.strip()][:20],
                        "public": bool(body.get("public", True)),
                        "created": now(), "forked_from": None,
                        "viewers": [],
                        "branches": {"main": {"created_by": user["username"],
                                              "created_at": now(),
                                              "from_branch": None, "from_rev": None}}}
                jsave(sd / "meta.json", meta)
                jsave(sd / "search_index.json", {})
                new_revision(sid, "main", user["username"], "initial commit", [])
            STORE.log_activity(user["username"], "create_space", sid, name)
            return self.send_json(200, space_view(sid, user))

        if (parts[0] == "spaces" and len(parts) == 2 and parts[1] == "import"
                and method == "POST"):
            return self.api_import_new(user)

        if parts[0] == "spaces" and len(parts) >= 2:
            sid = parts[1]
            if not can_view(sid, user):
                return self.send_json(*err("not found or private", 404))

            if len(parts) == 2 and method == "GET":
                return self.send_json(200, space_view(sid, user))

            if len(parts) == 2 and method == "PATCH":
                return self.api_patch_space(sid, user)

            if len(parts) == 2 and method == "DELETE":
                m = STORE.meta(sid)
                if m["owner"] != user["username"]:
                    return self.send_json(*err("owner only", 403))
                with _wlock:
                    import shutil
                    shutil.rmtree(STORE.space_dir(sid))
                    dl = [d for d in STORE.deadlines() if d["space"] != sid]
                    jsave(STORE.deadlines_path, dl)
                    rd = STORE.reading()
                    for uname in list(rd):
                        rd[uname] = [x for x in rd[uname] if x["space"] != sid]
                    jsave(STORE.reading_path, rd)
                return self.send_json(200, {"ok": True})

            if len(parts) == 3:
                if parts[2] == "tree":
                    branch = q.get("branch", ["main"])[0]
                    if not valid_branch(branch):
                        return self.send_json(*err("bad branch"))
                    tree, rev = STORE.tree(sid, branch)
                    return self.send_json(200, {"branch": branch, "rev": rev,
                                                "tree": tree})
                if parts[2] == "note" and method == "GET":
                    path = q.get("path", [""])[0]
                    if not ok_path(path):
                        return self.send_json(*err("bad path"))
                    branch = q.get("branch", ["main"])[0]
                    if not valid_branch(branch):
                        return self.send_json(*err("bad branch"))
                    rev_q = q.get("rev", [None])[0]
                    if rev_q is not None:
                        try:
                            rev = int(rev_q)
                        except (TypeError, ValueError):
                            return self.send_json(*err("bad revision", 400))
                        tree, cur = STORE.tree(sid, branch, rev)
                    else:
                        tree, cur = STORE.tree(sid, branch)
                    if tree is None:
                        return self.send_json(*err("revision not found", 404))
                    sha = tree.get(path)
                    if sha is None:
                        return self.send_json(*err("note not found", 404))
                    return self.send_json(200, {"path": path, "sha": sha,
                                                "content": STORE.object_text(sid, sha)})
                if parts[2] == "note" and method == "PUT":
                    return self.api_put_note(sid, user, q)
                if parts[2] == "note" and method == "DELETE":
                    return self.api_delete_note(sid, user, q)
                if parts[2] == "object" and method == "GET":
                    sha = q.get("sha", [""])[0]
                    if not re.fullmatch(r"[0-9a-f]{40}", sha or ""):
                        return self.send_json(*err("bad sha"))
                    txt = STORE.object_text(sid, sha)
                    if txt is None:
                        return self.send_json(*err("object not found", 404))
                    return self.send_json(200, {"sha": sha, "content": txt})
                if parts[2] == "comments" and method == "GET":
                    path = q.get("path", [""])[0]
                    if not ok_path(path):
                        return self.send_json(*err("bad path"))
                    cm = jload(STORE.space_dir(sid) / "comments.json", [])
                    return self.send_json(200, {"comments": [c for c in cm
                                                             if c["path"] == path]})
                if parts[2] == "comments" and method == "POST":
                    return self.api_comment(sid, user)
                if parts[2] == "history":
                    branch = q.get("branch", ["main"])[0]
                    if not valid_branch(branch):
                        return self.send_json(*err("bad branch"))
                    rl = jload(STORE.space_dir(sid) / "revlogs" / f"{branch}.json", [])
                    return self.send_json(200, {"branch": branch, "revs": rl[::-1]})
                if parts[2] == "note-history" and method == "GET":
                    path = q.get("path", [""])[0]
                    if not ok_path(path):
                        return self.send_json(*err("bad path"))
                    branch = q.get("branch", ["main"])[0]
                    if not valid_branch(branch):
                        return self.send_json(*err("bad branch"))
                    rl = jload(STORE.space_dir(sid) / "revlogs" / f"{branch}.json", [])
                    hits = [r for r in rl
                            if any(c.get("path") == path for c in r.get("changes") or [])]
                    return self.send_json(200, {"revs": hits[::-1],
                                                "head": rl[-1]["rev"] if rl else 0})
                if parts[2] == "restore" and method == "POST":
                    return self.api_restore(sid, user)
                if parts[2] == "import" and method == "POST":
                    return self.api_import(sid, user)
                if parts[2] == "import-zip" and method == "POST":
                    return self.api_import_zip(sid, user, q)
                if parts[2] == "diff" and method == "GET":
                    return self.api_diff(sid, q)
                if parts[2] == "branches" and method == "POST":
                    return self.api_branch(sid, user)
                if parts[2] == "merge" and method == "POST":
                    return self.api_merge(sid, user)
                if parts[2] == "fork" and method == "POST":
                    return self.api_fork(sid, user)
                if parts[2] == "export" and method == "GET":
                    return self.api_export(sid, q)
                if parts[2] == "export.txt" and method == "GET":
                    return self.api_export_txt(sid, q)
            return self.send_json(*err("bad route", 404))

        if parts[0] == "star" and len(parts) == 2 and method == "POST":
            return self.api_star(parts[1], user, True)
        if parts[0] == "unstar" and len(parts) == 2 and method == "POST":
            return self.api_star(parts[1], user, False)

        return self.send_json(*err("bad route", 404))

    # ---- auth handlers ----
    def api_register(self):
        body = self.read_body()
        if body is None:
            return self.send_json(*err("invalid JSON"))
        name = (body.get("username") or "").strip()
        pw = body.get("password") or ""
        if not valid_username(name):
            return self.send_json(*err("username: 2-32 chars, letters/digits/-/_"))
        if name.lower() == ADMIN_USER:
            return self.send_json(*err("username reserved", 409))
        if len(pw) < 6:
            return self.send_json(*err("password must be at least 6 characters"))
        ip = self.client_address[0]
        tries = [t for t in _register_fails.get(ip, []) if t > now() - REGISTER_WINDOW]
        if len(tries) >= REGISTER_MAX_TRIES:
            return self.send_json(*err("too many registrations from this address, wait a bit", 429))
        _register_fails.setdefault(ip, []).append(now())
        with _wlock:
            users = STORE.users()
            if MAX_USERS and len(users) >= MAX_USERS:
                return self.send_json(*err("registration is currently closed", 403))
            if name.lower() in {u.lower() for u in users}:
                return self.send_json(*err("username taken", 409))
            salt, dk = hash_pw(pw)
            users[name] = {"username": name,
                           "display_name": (body.get("display_name") or "").strip()[:50],
                           "salt": salt, "hash": dk,
                           "admin": len(users) == 0,      # first account = admin
                           "created": now()}
            jsave(STORE.users_path, users)
        token = new_session(name)
        STORE.log_activity(name, "register", None, None, summary="joined")
        self.send_json(200, {"token": token, "user": public_user(users[name])})

    def api_login(self):
        body = self.read_body()
        if body is None:
            return self.send_json(*err("invalid JSON"))
        name = (body.get("username") or "").strip()
        pw = body.get("password") or ""
        key = (self.client_address[0], name.lower())
        tries = [t for t in _login_fails.get(key, []) if t > now() - LOGIN_WINDOW]
        if len(tries) >= LOGIN_MAX_TRIES:
            return self.send_json(*err("too many attempts, wait a bit", 429))
        users = STORE.users()
        u = users.get(name)
        salt = u.get("salt") if u else "00" * 16
        dk = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"),
                                 bytes.fromhex(salt), PBKDF2_ITER).hex()
        if not u or not secrets.compare_digest(dk, u["hash"]):
            _login_fails.setdefault(key, []).append(now())
            return self.send_json(*err("wrong username or password", 401))
        token = new_session(name)
        return self.send_json(200, {"token": token, "user": public_user(u)})

    # ---- posts (reddit-style public threads) ----
    def api_posts(self):
        profs = STORE.profiles()
        votes = STORE.votes()
        viewer = self.current_user()
        uname = viewer["username"] if viewer else None
        out = []
        for p in STORE.posts():
            v = votes.get(p["id"], {})
            out.append(dict(p,
                            logo=profs.get(p["author"], {}).get("logo", ""),
                            score=sum(v.values()),
                            my_vote=v.get(uname, 0) if uname else 0))
        return self.send_json(200, {"posts": out})

    def api_post_create(self):
        body = self.read_body()
        if body is None:
            return self.send_json(*err("invalid JSON"))
        text = (body.get("text") or "").strip()
        title = (body.get("title") or "").strip()[:120]
        if not text or len(text) > 2000:
            return self.send_json(*err("post must be 1-2000 characters"))
        parent_id = body.get("parent_id")
        with _wlock:
            posts = STORE.posts()
            if parent_id and not any(p["id"] == parent_id for p in posts):
                return self.send_json(*err("reply target not found", 404))
            if parent_id:                              # comments carry no title
                title = ""
            post = {"id": secrets.token_hex(8), "author": self.current_user()["username"],
                    "time": now(), "text": text, "title": title or None,
                    "parent_id": parent_id or None}
            posts.append(post)
            jsave(STORE.posts_path, posts)
        add_mention_notifs({"username": post["author"]}, None, None, text)
        STORE.log_activity(post["author"], "post", None, None,
                           summary=(title or text)[:80])
        return self.send_json(200, {"post": post})

    def api_post_vote(self, pid, user):
        body = self.read_body()
        if body is None:
            return self.send_json(*err("invalid JSON"))
        try:
            d = int(body.get("dir", 0))
        except (TypeError, ValueError):
            return self.send_json(*err("bad dir"))
        if d not in (-1, 0, 1):
            return self.send_json(*err("dir must be -1, 0 or 1"))
        with _wlock:
            posts = STORE.posts()
            if not any(p["id"] == pid for p in posts):
                return self.send_json(*err("post not found", 404))
            votes = STORE.votes()
            v = votes.setdefault(pid, {})
            if d == 0:
                v.pop(user["username"], None)
            else:
                v[user["username"]] = d
            if not v:
                votes.pop(pid, None)
            jsave(STORE.votes_path, votes)
        score = sum(votes.get(pid, {}).values())
        return self.send_json(200, {"score": score, "my_vote": d})

    def api_post_delete(self, pid):
        user = self.current_user()
        with _wlock:
            posts = STORE.posts()
            target = next((p for p in posts if p["id"] == pid), None)
            if not target:
                return self.send_json(*err("post not found", 404))
            if target["author"] != user["username"] and not user.get("admin"):
                return self.send_json(*err("you can only delete your own posts", 403))
            posts = [p for p in posts if p["id"] != pid and p["parent_id"] != pid]
            jsave(STORE.posts_path, posts)
        return self.send_json(200, {"ok": True})

    # ---- admin page (username "eye", own password, own session) ----
    def admin_user(self):
        auth = self.headers.get("Authorization") or ""
        if not auth.startswith("Bearer "):
            return False
        token = auth[7:].strip()
        sess = STORE.admin_sessions().get(token)
        return bool(sess and sess["expires"] > now())

    def api_admin(self, parts, method):
        if not parts and method == "POST":
            return self.api_admin_login()
        if not parts and method == "GET":
            return self.send_json(200, {"admin": self.admin_user()})
        if parts == ["logout"] and method == "POST":
            auth = self.headers.get("Authorization") or ""
            if auth.startswith("Bearer "):
                with _wlock:
                    sessions = STORE.admin_sessions()
                    sessions.pop(auth[7:].strip(), None)
                    jsave(STORE.admin_sessions_path, sessions)
            return self.send_json(200, {"ok": True})
        if not self.admin_user():
            return self.send_json(*err("admin login required", 401))

        if parts == ["users"] and method == "GET":
            users = STORE.users()
            arcs = STORE.arcana()
            metas = STORE.metas()
            posts = STORE.posts()
            out = []
            for u in sorted(users.values(), key=lambda x: x.get("created") or 0):
                uname = u["username"]
                out.append({
                    "username": uname,
                    "display_name": u.get("display_name"),
                    "admin": u.get("admin", False),
                    "created": u.get("created"),
                    "arcana": arcs.get(uname, []),
                    "spaces": sum(1 for m in metas.values() if m["owner"] == uname),
                    "posts": sum(1 for p in posts if p["author"] == uname),
                })
            return self.send_json(200, {"users": out, "arcana_list": ARCADA})

        if parts == ["users"] and method == "POST":
            return self.api_admin_create_user()

        if len(parts) == 2 and parts[0] == "users" and method == "DELETE":
            return self.api_admin_delete_user(parts[1])

        if parts == ["posts"] and method == "GET":
            out = sorted(STORE.posts(), key=lambda p: p["time"], reverse=True)
            return self.send_json(200, {"posts": out[:100]})

        if len(parts) == 2 and parts[0] == "posts" and method == "DELETE":
            pid = parts[1]
            with _wlock:
                posts = STORE.posts()
                if not any(p["id"] == pid for p in posts):
                    return self.send_json(*err("post not found", 404))
                posts = [p for p in posts if p["id"] != pid and p["parent_id"] != pid]
                jsave(STORE.posts_path, posts)
            return self.send_json(200, {"ok": True})

        if parts == ["arcana"] and method == "POST":
            body = self.read_body()
            if body is None:
                return self.send_json(*err("invalid JSON"))
            target = (body.get("user") or "").strip()
            if target not in STORE.users():
                return self.send_json(*err("no such user", 404))
            want = []
            for a in body.get("arcanas") or []:
                a = str(a).strip()
                if a not in ARCADA:
                    return self.send_json(*err("unknown arcana: %s" % a))
                if a not in want:
                    want.append(a)
            if len(want) > ARCADA_MAX:
                return self.send_json(*err("a user can hold at most %d arcana" % ARCADA_MAX))
            with _wlock:
                arcs = STORE.arcana()
                if want:
                    arcs[target] = want
                else:
                    arcs.pop(target, None)
                jsave(STORE.arcana_path, arcs)
            return self.send_json(200, {"user": target, "arcana": want})

        return self.send_json(*err("bad route", 404))

    def api_admin_login(self):
        body = self.read_body()
        if body is None:
            return self.send_json(*err("invalid JSON"))
        name = (body.get("username") or "").strip()
        pw = body.get("password") or ""
        key = (self.client_address[0], "admin:" + name.lower())
        tries = [t for t in _login_fails.get(key, []) if t > now() - LOGIN_WINDOW]
        if len(tries) >= LOGIN_MAX_TRIES:
            return self.send_json(*err("too many attempts, wait a bit", 429))
        rec = admin_creds()
        dk = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"),
                                 bytes.fromhex(rec["salt"]), PBKDF2_ITER).hex()
        ok = name.lower() == ADMIN_USER and secrets.compare_digest(dk, rec["hash"])
        if not ok:
            _login_fails.setdefault(key, []).append(now())
            return self.send_json(*err("wrong username or password", 401))
        with _wlock:
            sessions = STORE.admin_sessions()
            sessions = {t: s for t, s in sessions.items()
                        if s["expires"] > now()}
            token = secrets.token_hex(SESSION_TOKENS // 2)
            sessions[token] = {"expires": now() + SESSION_TTL}
            jsave(STORE.admin_sessions_path, sessions)
        return self.send_json(200, {"token": token})

    def api_admin_create_user(self):
        body = self.read_body()
        if body is None:
            return self.send_json(*err("invalid JSON"))
        name = (body.get("username") or "").strip()
        pw = body.get("password") or ""
        if not valid_username(name):
            return self.send_json(*err("username: 2-32 chars, letters/digits/-/_"))
        if name.lower() == ADMIN_USER:
            return self.send_json(*err("username reserved", 409))
        if len(pw) < 6:
            return self.send_json(*err("password must be at least 6 characters"))
        with _wlock:
            users = STORE.users()
            if MAX_USERS and len(users) >= MAX_USERS:
                return self.send_json(*err("registration is currently closed", 403))
            if name.lower() in {u.lower() for u in users}:
                return self.send_json(*err("username taken", 409))
            salt, dk = hash_pw(pw)
            users[name] = {"username": name,
                           "display_name": (body.get("display_name") or "").strip()[:50],
                           "salt": salt, "hash": dk,
                           "admin": False,
                           "created": now()}
            jsave(STORE.users_path, users)
        return self.send_json(200, {"user": public_user(users[name])})

    def api_admin_delete_user(self, name):
        if name not in STORE.users():
            return self.send_json(*err("no such user", 404))
        import shutil
        with _wlock:
            # drop their sessions
            sessions = {t: s for t, s in STORE.sessions().items()
                        if s["user"] != name}
            jsave(STORE.sessions_path, sessions)
            # profile, stars, arcana, reading, notifications
            profs = STORE.profiles()
            profs.pop(name, None)
            jsave(STORE.profiles_path, profs)
            stars = STORE.stars()
            stars.pop(name, None)
            jsave(STORE.stars_path, stars)
            arcs = STORE.arcana()
            arcs.pop(name, None)
            jsave(STORE.arcana_path, arcs)
            rd = STORE.reading()
            rd.pop(name, None)
            jsave(STORE.reading_path, rd)
            owned_sids = [m["id"] for m in STORE.metas().values()
                          if m["owner"] == name]
            nf = STORE.notifs()
            nf.pop(name, None)
            for other in nf:
                nf[other] = [n for n in nf[other]
                             if n.get("space") not in owned_sids]
            jsave(STORE.notif_path, nf)
            # their votes everywhere
            votes = STORE.votes()
            for pid in list(votes):
                votes[pid].pop(name, None)
                if not votes[pid]:
                    votes.pop(pid)
            jsave(STORE.votes_path, votes)
            # their posts and every thread that hangs off them
            posts = STORE.posts()
            gone = {p["id"] for p in posts if p["author"] == name}
            changed = True
            while changed:
                changed = False
                for p in posts:
                    if p["parent_id"] and p["parent_id"] in gone and p["id"] not in gone:
                        gone.add(p["id"])
                        changed = True
            posts = [p for p in posts if p["id"] not in gone]
            jsave(STORE.posts_path, posts)
            # deadlines they set, their activity entries
            jsave(STORE.deadlines_path,
                  [d for d in STORE.deadlines() if d["user"] != name])
            jsave(STORE.activity_path,
                  [a for a in STORE.activity() if a["user"] != name])
            # spaces they own (whole dirs) + collaborator entries
            for m in list(STORE.metas().values()):
                if m["owner"] == name:
                    shutil.rmtree(STORE.space_dir(m["id"]))
            for m in list(STORE.metas().values()):
                collabs = m.get("collaborators", [])
                if name in collabs:
                    m["collaborators"] = [c for c in collabs if c != name]
                    jsave(STORE.space_dir(m["id"]) / "meta.json", m)
                viewers = m.get("viewers", [])
                if name in viewers:
                    m["viewers"] = [v for v in viewers if v != name]
                    jsave(STORE.space_dir(m["id"]) / "meta.json", m)
            # finally the account record itself
            users = STORE.users()
            users.pop(name, None)
            jsave(STORE.users_path, users)
        return self.send_json(200, {"ok": True})

    # ---- space handlers ----
    def api_profile(self, name):
        user = self.current_user()
        if not user:
            return self.send_json(401, {"error": "login required"})
        record = STORE.users().get(name)
        if not record:
            return self.send_json(*err("no such user", 404))
        if self.command == "GET":
            prof = STORE.profiles().get(name, {"about": "", "logo": ""})
            return self.send_json(200, {
                "user": public_user(record),
                "profile": prof,
                "arcana": STORE.arcana().get(name, []),
                "stats": profile_stats(name),
                "is_you": user["username"] == name,
            })
        if user["username"] != name:
            return self.send_json(*err("you can only edit your own profile", 403))
        body = self.read_body()
        if body is None:
            return self.send_json(*err("invalid JSON"))
        with _wlock:
            profs = STORE.profiles()
            prof = profs.setdefault(name, {"about": "", "logo": ""})
            if "about" in body:
                about = (body["about"] or "").strip()
                if len(about) > 2000:
                    return self.send_json(*err("about is too long (max 2000 chars)"))
                prof["about"] = about
            if "logo" in body and body["logo"]:
                logo = body["logo"]
                if not logo.startswith(PROFILE_LOGO_PREFIX) or len(logo) > PROFILE_LOGO_MAX:
                    return self.send_json(*err("logo must be a small PNG data URL (max 30 KB)"))
                prof["logo"] = logo
            jsave(STORE.profiles_path, profs)
        return self.send_json(200, {"profile": prof})

    def api_delete_note(self, sid, user, q):
        m = STORE.meta(sid)
        if not can_edit(sid, user):
            return self.send_json(*err("only the owner and collaborators can edit", 403))
        path = (q.get("path", [""])[0] or "").strip()
        if not path or not ok_path(path.rstrip("/")):
            return self.send_json(*err("bad path"))
        branch = q.get("branch", ["main"])[0]
        if not valid_branch(branch):
            return self.send_json(*err("bad branch"))
        if branch not in m.get("branches", {}):
            return self.send_json(*err("unknown branch", 404))
        with _wlock:
            tree, _ = STORE.tree(sid, branch)
            if path.endswith("/"):
                targets = [p for p in tree if p.startswith(path)]
            else:
                targets = [path] if path in tree else []
            if not targets:
                return self.send_json(*err("note not found", 404))
            label = path.rstrip("/") + "/" if path.endswith("/") else path
            changes = [{"path": p, "old_sha": tree[p], "new_sha": None}
                       for p in targets]
            rev = new_revision(sid, branch, user["username"],
                               "delete " + label, changes)
            dl = [d for d in STORE.deadlines()
                  if not (d["space"] == sid and d["path"] in targets)]
            if len(dl) != len(STORE.deadlines()):
                jsave(STORE.deadlines_path, dl)
        for p in targets:
            STORE.log_activity(user["username"], "delete_note", sid, m["name"], p)
        return self.send_json(200, {"rev": rev, "deleted": len(targets)})

    def api_patch_space(self, sid, user):
        m = STORE.meta(sid)
        if m["owner"] != user["username"]:
            return self.send_json(*err("owner only", 403))
        body = self.read_body() or {}
        added_viewers = []
        with _wlock:
            if "name" in body and valid_space_name((body["name"] or "").strip()):
                m["name"] = body["name"].strip()
            if "description" in body:
                m["description"] = (body["description"] or "").strip()[:500]
            if "tags" in body:
                m["tags"] = [t.strip().lower() for t in body["tags"] if t.strip()][:20]
            if "public" in body:
                m["public"] = bool(body["public"])
            if "collaborators" in body:
                names = []
                for n in (body["collaborators"] or []):
                    n = str(n).strip()
                    if n and n not in names:
                        names.append(n)
                users = STORE.users()
                for n in names:
                    if n not in users:
                        return self.send_json(*err("unknown user: %s" % n))
                m["collaborators"] = names
            if "viewers" in body:
                names = []
                for n in (body["viewers"] or []):
                    n = str(n).strip()
                    if n and n not in names:
                        names.append(n)
                users = STORE.users()
                for n in names:
                    if n not in users:
                        return self.send_json(*err("unknown user: %s" % n))
                added_viewers = [n for n in names if n not in (m.get("viewers") or [])]
                m["viewers"] = names
            jsave(STORE.space_dir(sid) / "meta.json", m)
        for n in added_viewers:                     # notify outside the lock
            STORE.notify(n, "share", user["username"], sid, m["name"], None,
                         "added you as a viewer on this space")
        return self.send_json(200, space_view(sid, user))

    def api_put_note(self, sid, user, q):
        m = STORE.meta(sid)
        if not can_edit(sid, user):
            return self.send_json(*err("only the owner and collaborators can edit", 403))
        body = self.read_body()
        if body is None:
            return self.send_json(*err("invalid JSON"))
        path = (body.get("path") or "").strip()
        content = body.get("content") or ""
        if not ok_path(path):
            return self.send_json(*err("bad path"))
        if len(content.encode("utf-8")) > NOTE_MAX_BYTES:
            return self.send_json(*err("note too large (max 1 MB)"))
        if STORE.disk_usage() > DISK_BUDGET:
            return self.send_json(*err("disk budget reached - notes not saved", 507))
        branch = q.get("branch", ["main"])[0]
        if not valid_branch(branch):
            return self.send_json(*err("bad branch"))
        if branch not in m.get("branches", {}):
            return self.send_json(*err("unknown branch", 404))
        new_sha = sha16(content)
        tree, _ = STORE.tree(sid, branch)
        if tree.get(path) == new_sha:
            return self.send_json(200, {"unchanged": True})
        with _wlock:
            obj = STORE.space_dir(sid) / "objects" / f"{new_sha}.md"
            if not obj.exists():
                obj.write_text(content, encoding="utf-8")
            rev = new_revision(sid, branch, user["username"],
                               (body.get("message") or "").strip()[:200],
                               [{"path": path, "old_sha": tree.get(path),
                                 "new_sha": new_sha}])
            sync_deadline(sid, m["name"], path, content, user["username"])
        STORE.log_activity(user["username"], "edit_note", sid, m["name"], path,
                           (body.get("message") or "").strip()[:80])
        return self.send_json(200, {"rev": rev, "sha": new_sha})

    def api_comment(self, sid, user):
        body = self.read_body()
        if body is None:
            return self.send_json(*err("invalid JSON"))
        path = (body.get("path") or "").strip()
        text = (body.get("text") or "").strip()
        if not ok_path(path):
            return self.send_json(*err("bad path"))
        if not text or len(text) > 4000:
            return self.send_json(*err("comment must be 1-4000 chars"))
        m = STORE.meta(sid)
        with _wlock:
            cm = jload(STORE.space_dir(sid) / "comments.json", [])
            c = {"id": secrets.token_hex(8), "path": path,
                 "author": user["username"], "time": now(), "text": text,
                 "parent_id": body.get("parent_id")}
            cm.append(c)
            jsave(STORE.space_dir(sid) / "comments.json", cm)
        add_mention_notifs(user, sid, path, text, anchor=c["id"])
        if c["parent_id"]:
            parent = next((x for x in cm if x["id"] == c["parent_id"]), None)
            if parent and parent["author"] != user["username"]:
                STORE.notify(parent["author"], "reply", user["username"], sid,
                             m["name"], path, text, anchor=c["id"])
        STORE.log_activity(user["username"], "comment", sid, m["name"], path,
                           text[:80])
        return self.send_json(200, {"comment": c})

    def api_diff(self, sid, q):
        branch = q.get("branch", ["main"])[0]
        if not valid_branch(branch):
            return self.send_json(*err("bad branch"))
        try:
            ra = int(q.get("rev_a", ["0"])[0])
            rb = int(q.get("rev_b", ["0"])[0])
        except ValueError:
            return self.send_json(*err("bad rev"))
        ta, _ = STORE.tree(sid, branch, ra)
        tb, _ = STORE.tree(sid, branch, rb)
        if ta is None or tb is None:
            return self.send_json(*err("revision not found", 404))
        out, whole = [], []
        for path in sorted(set(ta) | set(tb)):
            a = STORE.object_text(sid, ta[path]) if path in ta else ""
            b = STORE.object_text(sid, tb[path]) if path in tb else ""
            if a != b:
                lines = list(difflib.unified_diff(
                    (a or "").splitlines(), (b or "").splitlines(),
                    f"{path}@{ra}", f"{path}@{rb}", lineterm=""))
                out.append({"path": path, "diff": lines[2:]})
                whole += lines
        return self.send_json(200, {"files": out, "diff": "\n".join(whole)})

    def api_branch(self, sid, user):
        m = STORE.meta(sid)
        if not can_edit(sid, user):
            return self.send_json(*err("only the owner and collaborators can edit", 403))
        body = self.read_body() or {}
        name = (body.get("name") or "").strip()
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,32}", name):
            return self.send_json(*err("branch name: 1-32 chars, letters/digits/-/_"))
        src = body.get("from") or "main"
        if name in m.get("branches", {}):
            return self.send_json(*err("branch exists", 409))
        if src not in m.get("branches", {}):
            return self.send_json(*err("unknown source branch", 404))
        with _wlock:
            src_tree, rev = STORE.tree(sid, src)
            m["branches"][name] = {"created_by": user["username"],
                                   "created_at": now(),
                                   "from_branch": src, "from_rev": rev}
            jsave(STORE.space_dir(sid) / "meta.json", m)
            tdir = STORE.space_dir(sid) / "trees" / name
            tdir.mkdir(exist_ok=True)
            jsave(tdir / "0.json", src_tree)          # rev 0 = snapshot of src
            jsave(STORE.space_dir(sid) / "revlogs" / f"{name}.json",
                  [{"rev": 0, "parent": 0, "author": user["username"],
                    "time": now(), "message": f"branch {name} from {src}@{rev}",
                    "changes": []}])
        STORE.log_activity(user["username"], "branch", sid, m["name"],
                           summary=f"created branch {name}")
        return self.send_json(200, {"branch": name})

    def api_merge(self, sid, user):
        m = STORE.meta(sid)
        if not can_edit(sid, user):
            return self.send_json(*err("only the owner and collaborators can edit", 403))
        body = self.read_body() or {}
        src = body.get("source") or "main"
        dst = body.get("target") or "main"
        resolve = body.get("resolve") or {}
        if src not in m.get("branches", {}) or dst not in m.get("branches", {}):
            return self.send_json(*err("unknown branch"))
        if src == dst:
            return self.send_json(*err("source and target are the same"))
        bmeta = m["branches"][src]
        base_tree, _ = STORE.tree(sid, bmeta["from_branch"] or dst,
                                  bmeta["from_rev"])
        ours, _ = STORE.tree(sid, dst)
        theirs, _ = STORE.tree(sid, src)
        conflicts, changes = [], []
        for path in sorted(set(ours) | set(theirs) | set(base_tree)):
            o = ours.get(path)
            t = theirs.get(path)
            b = base_tree.get(path)
            if o == t:
                continue
            if o == b:
                changes.append({"path": path, "old_sha": o, "new_sha": t})
            elif t == b:
                continue                        # only ours changed: keep ours
            else:
                choice = resolve.get(path)
                if choice == "ours":
                    continue
                if choice == "theirs":
                    changes.append({"path": path, "old_sha": o, "new_sha": t})
                else:
                    conflicts.append({"path": path, "ours_sha": o,
                                      "theirs_sha": t, "base_sha": b})
        if conflicts:
            return self.send_json(409, {"error": "merge conflicts",
                                        "conflicts": conflicts,
                                        "resolve_required": True})
        if not changes:
            return self.send_json(200, {"merged": True, "nothing_to_do": True})
        with _wlock:
            rev = new_revision(sid, dst, user["username"],
                               f"merge {src} into {dst}", changes)
        STORE.log_activity(user["username"], "merge", sid, m["name"],
                           summary=f"merged {src} into {dst}")
        return self.send_json(200, {"merged": True, "rev": rev,
                                    "changes": len(changes)})

    def api_fork(self, sid, user):
        src = STORE.meta(sid)
        if src["owner"] == user["username"]:
            return self.send_json(*err("you own this space already"))
        branch = "main"
        _, rev = STORE.tree(sid, branch)
        with _wlock:
            nid = secrets.token_hex(4)
            nsd = STORE.space_dir(nid)
            nsd.mkdir(parents=True, exist_ok=True)
            for sub in ("objects", "trees", "revlogs"):
                (nsd / sub).mkdir(exist_ok=True)
            sd = STORE.space_dir(sid)
            for f in (sd / "objects").iterdir():
                (nsd / "objects" / f.name).write_bytes(f.read_bytes())
            (nsd / "trees" / branch).mkdir(exist_ok=True)
            for i in range(0, rev + 1):
                t = jload(sd / "trees" / branch / f"{i}.json", {})
                jsave(nsd / "trees" / branch / f"{i}.json", t)
            jsave(nsd / "revlogs" / f"{branch}.json",
                  jload(sd / "revlogs" / f"{branch}.json", []))
            meta = {"id": nid, "name": src["name"], "owner": user["username"],
                    "description": src.get("description", ""),
                    "tags": src.get("tags", []), "public": src.get("public", True),
                    "created": now(),
                    "forked_from": {"space": sid, "owner": src["owner"],
                                    "branch": branch, "rev": rev},
                    "viewers": [],
                    "branches": {branch: {"created_by": user["username"],
                                          "created_at": now(),
                                          "from_branch": None, "from_rev": None}}}
            jsave(nsd / "meta.json", meta)
            jsave(nsd / "search_index.json", jload(sd / "search_index.json", {}))
            jsave(nsd / "comments.json", [])
        STORE.log_activity(user["username"], "fork", nid, src["name"],
                           summary=f"forked from {src['owner']}")
        return self.send_json(200, space_view(nid, user))

    def api_export(self, sid, q):
        branch = q.get("branch", ["main"])[0]
        if not valid_branch(branch):
            return self.send_json(*err("bad branch"))
        tree, rev = STORE.tree(sid, branch)
        m = STORE.meta(sid)
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            for path, sha in tree.items():
                txt = STORE.object_text(sid, sha) or ""
                z.writestr(path, txt)
            z.writestr("META.json", json.dumps(
                {"space": m["name"], "branch": branch, "rev": rev,
                 "owner": m["owner"], "tags": m["tags"],
                 "exported": time.strftime("%Y-%m-%d %H:%M:%S")}, indent=1))
        data = buf.getvalue()
        self.send_response(200)
        self.send_header("Content-Type", "application/zip")
        self.send_header("Content-Disposition",
                         'attachment; filename="%s-%s.zip"'
                         % (safe_filename(m["name"]), branch))
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def api_export_txt(self, sid, q):
        branch = q.get("branch", ["main"])[0]
        if not valid_branch(branch):
            return self.send_json(*err("bad branch"))
        tree, rev = STORE.tree(sid, branch)
        m = STORE.meta(sid)
        lines = [
            "UNIHEAVEN SPACE EXPORT",
            "======================",
            "",
            "This text file was exported from uniheaven, a tiny self-hosted",
            "note space for university students: notes with LaTeX math,",
            "branching, hashtags that connect spaces, comments and public",
            "posts. Learn more in the app or in its README.",
            "",
            "Space    : %s" % m["name"],
            "Owner    : @%s" % m["owner"],
            "Branch   : %s" % branch,
            "Revision : %s" % rev,
            "Exported : %s" % time.strftime("%Y-%m-%d %H:%M:%S"),
            "",
            "FOLDER STRUCTURE",
            "================",
            "",
        ]
        root = {}
        for p in sorted(tree):
            parts = p.split("/")
            node = root
            for i, part in enumerate(parts):
                if i == len(parts) - 1:
                    node.setdefault(part, None)
                else:
                    node = node.setdefault(part, {})

        def walk(node, indent):
            out = []
            for name in sorted(node, key=lambda k: (not isinstance(node[k], dict), k)):
                if isinstance(node[name], dict):
                    out.append("  " * indent + name + "/")
                    out += walk(node[name], indent + 1)
                else:
                    out.append("  " * indent + name)
            return out

        lines += walk(root, 0)
        lines += ["", "NOTES", "=====", ""]
        for p in sorted(tree):
            lines.append("--- %s ---" % p)
            lines.append(STORE.object_text(sid, tree[p]) or "")
            lines.append("")
        data = "\n".join(lines).encode("utf-8")
        fname = safe_filename(m["name"]) + "-" + branch + ".txt"
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Disposition",
                         'attachment; filename="%s"' % fname)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _import_files(self, files):
        """Validate an imported file list. Returns (clean, errmsg)."""
        if not isinstance(files, list):
            return None, "files must be a list"
        if len(files) > IMPORT_MAX_FILES:
            return None, "too many files (max %d)" % IMPORT_MAX_FILES
        clean, seen = [], set()
        for f in files:
            if not isinstance(f, dict):
                return None, "bad file entry"
            path = (f.get("path") or "").strip()
            content = f.get("content")
            if not isinstance(content, str):
                return None, "bad content for %r" % path
            if not ok_path(path) or not path.lower().endswith(".md"):
                return None, "bad path: %s" % path
            if path in seen:
                continue
            seen.add(path)
            if len(content.encode("utf-8")) > NOTE_MAX_BYTES:
                return None, "note too large: %s (max 1 MB)" % path
            clean.append((path, content))
        return clean, None

    def api_import(self, sid, user, body=None):
        """Add/update a batch of .md files on one branch as a single revision."""
        m = STORE.meta(sid)
        if not can_edit(sid, user):
            return self.send_json(*err("only the owner and collaborators can edit", 403))
        if body is None:
            body = self.read_body()
            if body is None:
                return self.send_json(*err("invalid JSON"))
        branch = (body.get("branch") or "main").strip()
        if not valid_branch(branch):
            return self.send_json(*err("bad branch"))
        if branch not in m.get("branches", {}):
            return self.send_json(*err("unknown branch", 404))
        files, msg = self._import_files(body.get("files"))
        if files is None:
            return self.send_json(*err(msg))
        if STORE.disk_usage() > DISK_BUDGET:
            return self.send_json(*err("disk budget reached - not saved", 507))
        tree, _ = STORE.tree(sid, branch)
        message = (body.get("message") or "import").strip()[:200]
        n_changed = 0
        with _wlock:
            changes = []
            for path, content in files:
                sha = sha16(content)
                if tree.get(path) == sha:
                    continue
                obj = STORE.space_dir(sid) / "objects" / f"{sha}.md"
                if not obj.exists():
                    obj.write_text(content, encoding="utf-8")
                changes.append({"path": path, "old_sha": tree.get(path),
                                "new_sha": sha})
            if changes:
                rev = new_revision(sid, branch, user["username"], message, changes)
                n_changed = len(changes)
                for path, content in files:
                    if any(c["path"] == path and c["new_sha"] is not None
                           for c in changes):
                        sync_deadline(sid, m["name"], path, content,
                                      user["username"])
        STORE.log_activity(user["username"], "import", sid, m["name"],
                           summary="%d file(s)" % n_changed)
        if not n_changed:
            return self.send_json(200, {"unchanged": True, "imported": 0})
        return self.send_json(200, {"rev": rev, "imported": n_changed})

    def api_import_zip(self, sid, user, q):
        """Import a zip of .md files (raw body). Entries are validated; a bad
        entry path (absolute, .., backslash) aborts the whole import."""
        m = STORE.meta(sid)
        if not can_edit(sid, user):
            return self.send_json(*err("only the owner and collaborators can edit", 403))
        branch = q.get("branch", ["main"])[0]
        if not valid_branch(branch):
            return self.send_json(*err("bad branch"))
        if branch not in m.get("branches", {}):
            return self.send_json(*err("unknown branch", 404))
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            n = 0
        if n <= 0:
            return self.send_json(*err("empty upload"))
        if n > IMPORT_MAX_BYTES:
            return self.send_json(*err("upload too large (max %d MB)"
                                       % (IMPORT_MAX_BYTES // 2**20)), 413)
        raw = self.rfile.read(n)
        files = []
        try:
            with zipfile.ZipFile(io.BytesIO(raw)) as zf:
                infos = [i for i in zf.infolist() if not i.is_dir()]
                if sum(i.file_size for i in infos) > IMPORT_UNZIP_BUDGET:
                    return self.send_json(*err("zip expands to too much data"), 413)
                if len(infos) > IMPORT_MAX_FILES:
                    return self.send_json(*err("too many files (max %d)"
                                               % IMPORT_MAX_FILES))
                for info in infos:
                    name = info.filename.replace("\\", "/")
                    if not name.lower().endswith(".md"):
                        continue
                    files.append({"path": name,
                                  "content": zf.read(info).decode("utf-8", "replace")})
        except zipfile.BadZipFile:
            return self.send_json(*err("not a valid zip file"))
        return self.api_import(sid, user, {"branch": branch, "files": files})

    def api_import_new(self, user):
        """Create a brand-new space from a list of .md files."""
        body = self.read_body()
        if body is None:
            return self.send_json(*err("invalid JSON"))
        name = (body.get("name") or "").strip()
        if not valid_space_name(name):
            return self.send_json(*err("space name: 1-64 chars, letters/digits/"
                                       "space/._()@-"))
        files, msg = self._import_files(body.get("files"))
        if files is None:
            return self.send_json(*err(msg))
        if not files:
            return self.send_json(*err("no .md files to import"))
        if STORE.disk_usage() > DISK_BUDGET:
            return self.send_json(*err("disk budget reached - not saved", 507))
        with _wlock:
            sid = secrets.token_hex(4)
            sd = STORE.space_dir(sid)
            sd.mkdir(parents=True, exist_ok=True)
            for sub in ("objects", "trees", "revlogs"):
                (sd / sub).mkdir(exist_ok=True)
            meta = {"id": sid, "name": name, "owner": user["username"],
                    "description": (body.get("description") or "").strip()[:500],
                    "tags": [t.strip().lower() for t in
                             body.get("tags") or [] if t.strip()][:20],
                    "public": bool(body.get("public", True)),
                    "created": now(), "forked_from": None,
                    "viewers": [],
                    "branches": {"main": {"created_by": user["username"],
                                          "created_at": now(),
                                          "from_branch": None, "from_rev": None}}}
            jsave(sd / "meta.json", meta)
            jsave(sd / "search_index.json", {})
            changes = []
            for path, content in files:
                sha = sha16(content)
                obj = sd / "objects" / f"{sha}.md"
                if not obj.exists():
                    obj.write_text(content, encoding="utf-8")
                changes.append({"path": path, "old_sha": None, "new_sha": sha})
            new_revision(sid, "main", user["username"],
                         (body.get("message") or "import").strip()[:200], changes)
            for path, content in files:
                sync_deadline(sid, name, path, content, user["username"])
        STORE.log_activity(user["username"], "create_space", sid, name,
                           summary="imported %d file(s)" % len(files))
        return self.send_json(200, space_view(sid, user))

    def api_restore(self, sid, user):
        """Restore one note to its state at rev N (creates a new revision;
        restoring to a rev where the note didn't exist deletes it)."""
        m = STORE.meta(sid)
        if not can_edit(sid, user):
            return self.send_json(*err("only the owner and collaborators can edit", 403))
        body = self.read_body() or {}
        path = (body.get("path") or "").strip()
        branch = (body.get("branch") or "main").strip()
        if not ok_path(path):
            return self.send_json(*err("bad path"))
        if not valid_branch(branch):
            return self.send_json(*err("bad branch"))
        if branch not in m.get("branches", {}):
            return self.send_json(*err("unknown branch", 404))
        try:
            rev = int(body.get("rev"))
        except (TypeError, ValueError):
            return self.send_json(*err("bad revision", 400))
        rev_tree, _head = STORE.tree(sid, branch, rev)
        if rev_tree is None:
            return self.send_json(*err("revision not found", 404))
        cur_tree, _ = STORE.tree(sid, branch)
        old_sha = cur_tree.get(path)
        new_sha = rev_tree.get(path)              # None = note did not exist
        if old_sha == new_sha:
            return self.send_json(200, {"unchanged": True})
        content = STORE.object_text(sid, new_sha) if new_sha else ""
        message = (body.get("message")
                   or "restore %s to rev %d" % (path, rev)).strip()[:200]
        with _wlock:
            rrev = new_revision(sid, branch, user["username"], message,
                                [{"path": path, "old_sha": old_sha,
                                  "new_sha": new_sha}])
            sync_deadline(sid, m["name"], path, content, user["username"])
        STORE.log_activity(user["username"], "restore", sid, m["name"], path,
                           summary="restored rev %d" % rev)
        return self.send_json(200, {"rev": rrev})

    def api_star(self, sid, user, on):
        if not can_view(sid, user):
            return self.send_json(*err("not found or private", 404))
        with _wlock:
            stars = STORE.stars()
            lst = set(stars.get(user["username"], []))
            if on:
                lst.add(sid)
            else:
                lst.discard(sid)
            stars[user["username"]] = sorted(lst)
            jsave(STORE.stars_path, stars)
        return self.send_json(200, {"starred": on,
                                    "star_count": sum(1 for v in STORE.stars().values()
                                                      if sid in v)})


def main():
    ap = argparse.ArgumentParser(description="Uniheaven server")
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--datadir", default=str(DEFAULT_DATA))
    args = ap.parse_args()

    global STORE
    STORE = Store(args.datadir)

    admin_creds()                             # generate/print admin password once

    threading.Thread(target=deadline_watcher, daemon=True).start()

    srv = ThreadingHTTPServer((args.host, args.port), Handler)
    sys.stderr.write("uniheaven listening on http://%s:%d (data: %s)\n"
                     % (args.host, args.port, STORE.dir))
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
