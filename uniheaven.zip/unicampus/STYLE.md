# STYLE.md — how to restyle Uniheaven

This document is written so that an LLM (or a human) can change the entire
visual appearance of the app quickly and safely. Read it fully before editing
any style file.

## 1. How styling works (read this first)

The whole app's look comes from exactly **two CSS files** and a **3-class
rule**:

| File               | Role                                             |
|--------------------|--------------------------------------------------|
| `web/css/theme.css`| **Design tokens only.** Every color, font, size, spacing step and shape used anywhere. Also the dark/light theme switch. |
| `web/css/layout.css`| **Component styles only.** Every rule here must reference tokens via `var(--...)`. No hardcoded colors. |

Theming is a two-block operation:

```css
:root { --bg: #eef3fb; ... }                 /* angel / light (default)   */
[data-theme="dark"] { --bg: #090c1f; ... }   /* cyber / dark (the toggle) */
```

Default theme is now **light = "angel"** (pearl, ice blue, cobalt chrome);
`[data-theme="dark"]` is **"cyber"** (indigo night, ice-blue glow). To go back
to dark-by-default: set `data-theme="dark"` on `<html>` in the three html
files and, in their inline script, test `t === "light"` instead of `"dark"`.

The toggle button swaps `data-theme` on `<html>` and persists the choice in
`localStorage["uni-theme"]`. No other code is involved.

## 2. Hard rules (do not violate)

1. **Gradients only as tokens.** The cyberangel/y2k look needs chrome and
   sky gradients, so they are allowed, but ONLY as `--grad-*` tokens in
   `theme.css`. `layout.css` never writes a raw gradient. (This replaces the
   old "no gradients" rule.)
2. **No inline styles** in `*.html` or `*.ts` files. Style via classes in
   `layout.css` and tokens in `theme.css` only. (Dynamic JS may still toggle
   classes - that is fine.)
3. **No new colors in `layout.css`.** If you need a new color, add a token to
   `theme.css` (both themes!) and reference it.
4. **No decorative animations** beyond `transition` on hover/active states.
   No glitch/scanline/CRT effects (explicit project decision, still valid).
   `prefers-reduced-motion` switches transitions off.
5. **No CSS frameworks, no build step for CSS.** Plain files, loaded in this
   order in every HTML page: `theme.css`, `layout.css`, then KaTeX's css.
6. KaTeX math inherits `currentColor`; only the two small rules at the bottom
   of `theme.css` style it. Adjust there if math needs size changes.

## 3. Token glossary (theme.css)

Palette (dark defaults shown; light values are in `[data-theme="light"]`):

| Token          | Dark default | What it colors                                   |
|----------------|--------------|--------------------------------------------------|
| `--bg`         | `#0e1116`    | page background                                  |
| `--bg-panel`   | `#151a21`    | cards, panels, sidebar, top bar, modals          |
| `--bg-inset`   | `#0a0d11`    | inputs, textareas, code blocks, wells            |
| `--bg-hover`   | `#1d242e`    | hover background on rows/items                   |
| `--bg-active`  | `#263041`    | pressed/selected elements                        |
| `--text`       | `#e6edf3`    | main text                                        |
| `--text-dim`   | `#8b98a5`    | secondary text, labels                           |
| `--text-faint` | `#59636e`    | disabled text, hints, timestamps                 |
| `--accent`     | `#4da3ff`    | links, primary buttons, selection (light blue)   |
| `--accent-dim` | `#1f6feb`    | darker accent: borders, hover states             |
| `--accent-soft`| `#16233a`    | accent-tinted backgrounds (tags, selected rows)  |
| `--border`     | `#2a3340`    | all 1px lines                                    |
| `--ok`         | `#3fb950`    | success, diff additions                          |
| `--danger`     | `#f85149`    | errors, diff deletions                           |
| `--warn`       | `#d29922`    | warnings, merge conflicts                        |
| `--code-bg`    | `#0a0d11`    | code block background                            |
| `--diff-add-bg`| `rgba(63,185,80,.16)` | added-line background in diffs        |
| `--diff-del-bg`| `rgba(248,81,73,.16)` | deleted-line background in diffs      |

Shape, motion, layout:

| Token       | Default | Meaning                                          |
|-------------|---------|--------------------------------------------------|
| `--radius`  | `2px`   | corner radius everywhere (0 = fully sharp)       |
| `--border-w`| `1px`   | border width everywhere                          |
| `--transition`| `120ms ease` | hover/active transition duration            |
| `--max-w`   | `920px`  | note reading column width                        |
| `--space-1`…`--space-5` | `4/8/16/24/40px` | the only spacing steps used     |

Typography:

| Token      | Value (stack)                                          | Used for           |
|------------|---------------------------------------------------------|--------------------|
| `--font-ui`| ui-monospace, Cascadia Code/JetBrains Mono, Consolas…  | buttons, labels, top bar, status bar |
| `--font-body`| Segoe UI, system-ui…                                  | note text, comments |
| `--font-mono`| same stack as `--font-ui`                             | code, paths, tree  |
| `--fs-xs/s/m/l/xl` | `11/13/15/18/24px`                              | micro-labels → page headings |
| `--lh`     | `1.6`     | line-height of body text                           |

## 4. Recipes (copy-paste starting points)

**Change the accent color (whole app):**
1. In `web/css/theme.css`, replace the three values of `--accent`,
   `--accent-dim` and `--accent-soft` in BOTH `:root` and
   `[data-theme="light"]`.
2. Nothing else. Done.

**Change fonts:**
1. Edit `--font-ui`, `--font-body`, `--font-mono` in `theme.css`.
2. If you add a webfont, self-host it under `web/vendor/<font>/` (the app
   must work offline) and add a `@font-face` block at the top of `theme.css`.

**Make it fully flat/sharp:**
- Set `--radius: 0` in `:root`. Everything becomes angular.

**Adjust density:**
- Halve the spacing: `--space-1..5` to `2/4/8/12/20px`. Padding is derived
  only from these tokens.

**Make the light theme the default:**
- Change the default `<html data-theme="dark">` attribute in
  `web/index.html` and `web/space.html` to `data-theme="light"`.

**Style a new component:**
1. Give the element a class in the HTML/TS (no inline styles).
2. Add rules in `layout.css` using only `var(--...)` tokens.
3. If a brand-new color is required, add tokens to BOTH themes first.

## 5. Component map (layout.css)

| Section of layout.css      | Styles what                                    |
|----------------------------|------------------------------------------------|
| reset / base               | box-sizing, body font/colors, links, hr        |
| .topbar / .logo            | header bar on both pages                       |
| .btn (+ .primary/.danger/.small/.active) | every button in the app             |
| label.field / .lbl / inputs | forms, inputs, textareas, selects, errors     |
| .page / h1 / .sub          | home page shell                                |
| .space-grid / .card        | space cards on the home page                   |
| .tag                       | #tag pills (home, cards)                       |
| .feed-item                 | activity feed rows                             |
| .modal-*                   | all modal dialogs (history, diff, merge, …)    |
| .workspace / .sidebar / .content | space page layout grid                   |
| .tree-row / .tree-indent   | file tree in the sidebar                       |
| .note-head / .note-body    | note header and rendered markdown              |
| .editor-grid / .preview    | editor textarea + live preview panes           |
| .comments / .comment / .comment-form | comment thread and form              |
| .diff-file / .diff-*       | diff view (history modal)                      |
| .profile-head / .avatar / .avatar-placeholder | user profile header + 20x20 logo |
| .stat-grid / .stat         | profile stat cards                             |
| .word-cloud / .wc-1…5      | top-words cloud (5 fixed size buckets)         |
| .spark / .bar.b1…b3        | 8-week revision sparkline                      |
| .pix-editor / .pix-canvas / .pix-palette / .pix-swatch | 20x20 pixel logo editor |
| .post / .p-head / .p-avatar* / .p-text / .p-actions / .post-replies / .post-form | news posts (twitter-style feed) |
| .cc.c01…c30 / .cc.c00 / .cc.cm | chat color codes (!£XX content styling — fixed content palette, not theme tokens) |
| .statusbar / .badge / .dropdown | footer bar, notification bell + dropdowns |
| .panel / .row / utilities (.grow,.hidden,.dim,…) | generic layout helpers            |

## 6. Verification checklist (after any style change)

Run the app (`python server.py --port 8000`) and check, in BOTH themes
(toggle with the `theme` button; default is now light):

1. Home page: top bar, cards, tag pills, feed, buttons hover correctly.
2. Space page: file tree, note rendering (headings, code blocks, math via
   KaTeX), editor + preview, comments, branch select, status bar.
3. Open the history modal and a diff — added/deleted lines must be legible
   (`--diff-add-bg` / `--diff-del-bg`).
4. Trigger a merge conflict and confirm the conflict picker is readable.
5. Open the notification bell dropdown; unread items must stand out.
6. User profile page (`/user.html?name=…`): avatar, stat cards, word cloud
   buckets, sparkline bars, and the pixel-editor modal (palette swatches use
   the `--swatch` custom property set by JS — keep it, do not hardcode).
7. News feed: posts with avatars, replies indent, chat colors render in
   both themes (the `.cc.cXX` palette is fixed content styling — it may be
   adjusted but must stay readable on dark AND light backgrounds).
8. Light theme: verify `[data-theme="light"]` actually overrides (the
   attribute must be on `<html>`, not `<body>`).
9. Contrast: `--text-dim` and `--text-faint` must stay readable on
   `--bg` / `--bg-panel` in both themes.
10. No console warnings for missing CSS vars (typos in `var(--…)`).

If a change is only visual, no TypeScript rebuild is needed (CSS is served
as-is). If you touched `web/src/*.ts`, recompile with `npx tsc -p web` and
commit `web/out/`.


---

# 7. Cyberangel / y2k visual language (added)

Reference mood: pearl-white + ice-blue ads (Walkman D-EJ751, PS2 steel silver),
cyber-sigil thorn linework, angel halo + wings, japanese warning-label type.

| Ingredient | Where it lives |
|------------|----------------|
| chrome strips (top bar, status bar, buttons) | `--grad-chrome`, `--grad-chrome-hover`, `--bevel` |
| cobalt primary button | `--grad-accent`, `--grad-accent-hover` |
| window titlebars (modals) | `--grad-title` |
| fading hairlines under headings | `--grad-rule` |
| lens flare + lavender haze behind the page | `--flare` (body background) |
| halftone dot fade, bottom-right corner | `--halftone` (`body::after`) |
| glow instead of drop shadow | `--glow`, `--glow-soft`, `--focus-ring` |
| capsule shapes (buttons, tags, badges, select) | `--radius-pill`; panels/inputs stay at `--radius` (2px) |
| ornaments: thorn-wing, sparkle, halo | `--orn-thorn`, `--orn-sparkle`, `--orn-halo` (svg data-uri **masks**, so they take the colour of `background`) |
| spec-table stat cards (black label tab) | `--ink`, `--on-ink` |

Where the ornaments appear: halo above the logo and above the profile avatar,
thorn-wing after page headings (`.page h1::after`), sparkle on panel titles,
modal titlebars, space cards and the first status-bar item.

**Lowercase.** `body` has `text-transform: lowercase`; user-written content
(notes, posts, comments, inputs, code, file names) opts out so it keeps its
casing. The old uppercase micro-labels were removed.

## Fonts

No webfont is bundled (the app must work offline). Current stacks:

- `--font-display`: Arial Black, italic 900, outlined with `-webkit-text-stroke`
  (logo, page headings, note headings, big stat numbers)
- `--font-ui`: MS Gothic / Osaka-Mono (pixel-ish, japanese ui feel)
- `--font-body`: Tahoma / Verdana

To get the exact look of the references, self-host two free fonts:
**DotGothic16** (pixel japanese) and **Michroma** (wide chrome-ad display),
put the `.woff2` files in `web/vendor/fonts/` and uncomment the two
`@font-face` blocks at the bottom of `theme.css`. Both are already first in
the stacks, nothing else to change.

## New tokens

`--accent-ice`, `--accent-lav`, `--ink`, `--on-ink`, `--on-accent`, `--scrim`,
`--topbar-h`, `--fs-display`, `--font-display`, `--radius-pill`, and all
`--grad-*`, `--glow*`, `--bevel`, `--orn-*`, `--flare`, `--halftone`.
`--topbar-h` (49px) is used by the space-page workspace height - keep the
top bar at that height.

## Chat colors

The `.cc.c2x` / `.cc.c30` (light) codes are unreadable on the pearl background,
so on the light theme they use deeper twins of the same hue. Dark theme is
unchanged.
