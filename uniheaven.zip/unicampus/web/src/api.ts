// Uniheaven API client (browser). Token lives in localStorage, sent as Bearer.

export interface User {
  username: string;
  display_name: string;
  admin: boolean;
  created: number;
}

export interface Space {
  id: string;
  name: string;
  owner: string;
  description: string;
  tags: string[];
  public: boolean;
  created: number;
  forked_from: { space: string; owner: string; branch: string; rev: number } | null;
  branches: Record<string, unknown>;
  collaborators: string[];
  viewers: string[];
  can_edit: boolean;
  starred: boolean;
  star_count: number;
}

export function getToken(): string {
  try { return localStorage.getItem("uni-token") || ""; } catch { return ""; }
}
export function setToken(t: string): void {
  try { t ? localStorage.setItem("uni-token", t) : localStorage.removeItem("uni-token"); } catch { /* ignore */ }
}

export class ApiError extends Error {
  payload: any;
  constructor(msg: string, payload?: any) {
    super(msg);
    this.payload = payload;
  }
}

export async function api(path: string, opts: { method?: string; body?: unknown } = {}): Promise<any> {
  const headers: Record<string, string> = {};
  const token = getToken();
  if (token) headers["Authorization"] = "Bearer " + token;
  const res = await fetch("/api/" + path, {
    method: opts.method || "GET",
    credentials: "same-origin",
    headers,
    body: opts.body === undefined ? undefined : JSON.stringify(opts.body),
  });
  const ct = res.headers.get("content-type") || "";
  if (ct.includes("application/json")) {
    const data = await res.json();
    if (!res.ok) throw new ApiError(data.error || `HTTP ${res.status}`, data);
    return data;
  }
  if (!res.ok) throw new ApiError(`HTTP ${res.status}`);
  return res;
}

export const me = async (): Promise<User | null> => (await api("me")).user;
export const users = (prefix: string) => api("users?prefix=" + encodeURIComponent(prefix));
export const listSpaces = (): Promise<Space[]> => api("spaces").then((d) => d.spaces);
export const getSpace = (id: string): Promise<Space> => api("spaces/" + id);
export const patchSpace = (id: string, body: object) => api("spaces/" + id, { method: "PATCH", body });
export const getTree = (id: string, branch: string) =>
  api(`spaces/${id}/tree?branch=${encodeURIComponent(branch)}`);
export const getNote = (id: string, path: string, branch: string, rev?: number) =>
  api(`spaces/${id}/note?path=${encodeURIComponent(path)}&branch=${encodeURIComponent(branch)}` +
    (rev === undefined ? "" : `&rev=${rev}`));
export const putNote = (id: string, branch: string, path: string, content: string, message: string) =>
  api(`spaces/${id}/note?branch=${encodeURIComponent(branch)}`,
    { method: "PUT", body: { path, content, message } });
export const deleteNote = (id: string, path: string, branch: string) =>
  api(`spaces/${id}/note?path=${encodeURIComponent(path)}&branch=${encodeURIComponent(branch)}`,
    { method: "DELETE" });
export const getProfile = (name: string) =>
  api("users/" + encodeURIComponent(name) + "/profile");
export const putProfile = (name: string, body: { about?: string; logo?: string }) =>
  api("users/" + encodeURIComponent(name) + "/profile", { method: "PUT", body });
export const getComments = (id: string, path: string) =>
  api(`spaces/${id}/comments?path=${encodeURIComponent(path)}`);
export const postComment = (id: string, path: string, text: string, parent_id?: string | null) =>
  api(`spaces/${id}/comments`, { method: "POST", body: { path, text, parent_id } });
export const getHistory = (id: string, branch: string) =>
  api(`spaces/${id}/history?branch=${encodeURIComponent(branch)}`);
export const getNoteHistory = (id: string, path: string, branch: string) =>
  api(`spaces/${id}/note-history?path=${encodeURIComponent(path)}&branch=${encodeURIComponent(branch)}`);
export const restoreNote = (id: string, branch: string, path: string, rev: number, message?: string) =>
  api(`spaces/${id}/restore`, { method: "POST", body: { path, branch, rev, message } });
export const importFiles = (id: string, branch: string, files: { path: string; content: string }[], message?: string) =>
  api(`spaces/${id}/import`, { method: "POST", body: { branch, files, message } });
export const importNewSpace = (body: {
  name: string; description?: string; tags?: string[]; public?: boolean;
  files: { path: string; content: string }[]; message?: string;
}): Promise<Space> => api("spaces/import", { method: "POST", body });
export async function importZip(id: string, branch: string, data: ArrayBuffer, message?: string): Promise<any> {
  const headers: Record<string, string> = {};
  const token = getToken();
  if (token) headers["Authorization"] = "Bearer " + token;
  const res = await fetch(`/api/spaces/${id}/import-zip?branch=${encodeURIComponent(branch)}`, {
    method: "POST",
    headers,
    body: data,
  });
  const d = await res.json();
  if (!res.ok) throw new ApiError(d.error || `HTTP ${res.status}`, d);
  return d;
}
export const getDiff = (id: string, branch: string, revA: number, revB: number) =>
  api(`spaces/${id}/diff?branch=${encodeURIComponent(branch)}&rev_a=${revA}&rev_b=${revB}`);
export const createBranch = (id: string, name: string, from: string) =>
  api(`spaces/${id}/branches`, { method: "POST", body: { name, from } });
export const mergeBranch = (id: string, source: string, target: string, resolve?: Record<string, string>) =>
  api(`spaces/${id}/merge`, { method: "POST", body: { source, target, resolve } });
export const forkSpace = (id: string): Promise<Space> => api(`spaces/${id}/fork`, { method: "POST" });
export const starSpace = (id: string, on: boolean) =>
  api(`${on ? "star" : "unstar"}/${id}`, { method: "POST" });
export const notifications = () => api("notifications");
export const notificationsRead = (ids: string[]) => api("notifications/read", { method: "POST", body: { ids } });
export const getDeadlines = () => api("deadlines");
export const getReading = () => api("reading");
export const postReading = (space: string, path: string, anchor: string) =>
  api("reading", { method: "POST", body: { space, path, anchor } });
export const activity = () => api("activity");
export const allTags = () => api("tags");
export const searchAll = (q: string) => api("search?q=" + encodeURIComponent(q));
export const exportUrl = (id: string, branch: string) =>
  `/api/spaces/${id}/export?branch=${encodeURIComponent(branch)}`;
export const exportTxtUrl = (id: string, branch: string) =>
  `/api/spaces/${id}/export.txt?branch=${encodeURIComponent(branch)}`;
export const getPosts = () => api("posts");
export const postPost = (text: string, parent_id?: string | null, title?: string) =>
  api("posts", { method: "POST", body: { text, parent_id, title } });
export const deletePost = (id: string) => api("posts/" + id, { method: "DELETE" });
export const votePost = (id: string, dir: number) =>
  api(`posts/${id}/vote`, { method: "POST", body: { dir } });

// major arcana (mirrors ARCADA on the server)
export const ARCADA = [
  "The Fool", "The Magician", "The High Priestess", "The Empress",
  "The Emperor", "The Hierophant", "The Lovers", "The Chariot",
  "Strength", "The Hermit", "Wheel of Fortune", "Justice",
  "The Hanged Man", "Death", "Temperance", "The Devil", "The Tower",
  "The Star", "The Moon", "The Sun", "Judgement", "The World",
];
export const arcSlug = (name: string): string =>
  name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

// Authenticated file download. Plain links/location.href cannot send the
// Bearer token (the server sets no cookie), so we fetch and save a blob.
export async function downloadFile(url: string, fallbackName: string): Promise<void> {
  const headers: Record<string, string> = {};
  const token = getToken();
  if (token) headers["Authorization"] = "Bearer " + token;
  const res = await fetch(url, { credentials: "same-origin", headers });
  if (!res.ok) {
    let msg = `HTTP ${res.status}`;
    try { msg = (await res.json()).error || msg; } catch { /* not json */ }
    throw new ApiError(msg);
  }
  const cd = res.headers.get("content-disposition") || "";
  const m = /filename\*?=(?:UTF-8'')?"?([^";]+)"?/i.exec(cd);
  const name = m ? decodeURIComponent(m[1]) : fallbackName;
  const blob = await res.blob();
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}
