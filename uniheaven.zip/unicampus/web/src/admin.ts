// Admin page: own login (not a user account), arcana assignment
// (max two per user), thread moderation. Token lives in sessionStorage.

import { ARCADA, arcSlug } from "./api.js";
import { initTheme, fmtTime } from "./common.js";
import { esc } from "./render.js";

const TOKEN_KEY = "uni-admin-token";

function getToken(): string {
  try { return sessionStorage.getItem(TOKEN_KEY) || ""; } catch { return ""; }
}
function setToken(t: string): void {
  try { t ? sessionStorage.setItem(TOKEN_KEY, t) : sessionStorage.removeItem(TOKEN_KEY); } catch { /* ignore */ }
}

async function adminApi(path: string, opts: { method?: string; body?: unknown } = {}): Promise<any> {
  const headers: Record<string, string> = {};
  const token = getToken();
  if (token) headers["Authorization"] = "Bearer " + token;
  const res = await fetch("/api/admin/" + path, {
    method: opts.method || "GET",
    headers,
    body: opts.body === undefined ? undefined : JSON.stringify(opts.body),
  });
  let data: any = null;
  try { data = await res.json(); } catch { /* not json */ }
  if (!res.ok) throw new Error((data && data.error) || `HTTP ${res.status}`);
  return data;
}

const $ = (id: string) => document.getElementById(id)!;

// ---------------- boot ----------------
async function boot(): Promise<void> {
  initTheme();
  const area = $("admin-area");
  if (getToken()) {
    const out = document.createElement("button");
    out.className = "btn small";
    out.textContent = "logout";
    out.addEventListener("click", async () => {
      try { await adminApi("logout", { method: "POST" }); } catch { /* ignore */ }
      setToken("");
      location.reload();
    });
    area.replaceChildren(out);
    await loadMain();
  } else {
    area.innerHTML = "";
    const loginPanel = $("admin-login");
    loginPanel.classList.remove("hidden");
    wireLogin();
  }
}

function wireLogin(): void {
  $("adm-login-btn").addEventListener("click", async () => {
    const username = ($("adm-user") as HTMLInputElement).value.trim();
    const password = ($("adm-pass") as HTMLInputElement).value;
    try {
      const d = await adminApi("", { method: "POST", body: { username, password } });
      setToken(d.token);
      location.reload();
    } catch (e) {
      const box = $("adm-error");
      box.textContent = (e as Error).message;
      box.classList.remove("hidden");
    }
  });
}

// ---------------- legend ----------------
function renderLegend(): void {
  const box = $("legend");
  box.innerHTML = "";
  for (const a of ARCADA) {
    const chip = document.createElement("span");
    chip.className = "arc " + arcSlug(a);
    chip.textContent = a;
    chip.title = a;
    box.appendChild(chip);
  }
}

// ---------------- accounts ----------------
function wireCreateUser(): void {
  $("adm-create-btn").addEventListener("click", async () => {
    const username = ($("adm-new-user") as HTMLInputElement).value.trim();
    const display = ($("adm-new-display") as HTMLInputElement).value.trim();
    const password = ($("adm-new-pass") as HTMLInputElement).value;
    const errBox = $("adm-create-error");
    try {
      await adminApi("users", { method: "POST", body: { username, password, display_name: display } });
      ($("adm-new-user") as HTMLInputElement).value = "";
      ($("adm-new-display") as HTMLInputElement).value = "";
      ($("adm-new-pass") as HTMLInputElement).value = "";
      errBox.classList.add("hidden");
      void renderUsers();
    } catch (e) {
      errBox.textContent = (e as Error).message;
      errBox.classList.remove("hidden");
    }
  });
}

// ---------------- users / arcana ----------------
interface AdminUser {
  username: string;
  display_name: string | null;
  admin: boolean;
  created: number;
  arcana: string[];
  spaces: number;
  posts: number;
}

function arcSlot(selected: string): HTMLSelectElement {
  const sel = document.createElement("select");
  sel.className = "arc-slot";
  const none = document.createElement("option");
  none.value = "";
  none.textContent = "— none —";
  sel.appendChild(none);
  for (const a of ARCADA) {
    const o = document.createElement("option");
    o.value = a;
    o.textContent = a;
    sel.appendChild(o);
  }
  sel.value = selected || "";
  return sel;
}

async function renderUsers(): Promise<void> {
  const box = $("admin-users");
  box.innerHTML = '<div class="dim">loading…</div>';
  let users: AdminUser[];
  try {
    users = (await adminApi("users")).users;
  } catch (e) {
    box.innerHTML = `<div class="error-box">${esc((e as Error).message)}</div>`;
    return;
  }
  box.innerHTML = "";
  for (const u of users) {
    const row = document.createElement("div");
    row.className = "admin-user";
    const top = document.createElement("div");
    top.className = "row";
    const who = document.createElement("a");
    who.href = "/user.html?name=" + encodeURIComponent(u.username);
    who.textContent = "@" + u.username;
    who.title = "open profile";
    const meta = document.createElement("span");
    meta.className = "faint xs mono";
    meta.textContent = `joined ${fmtTime(u.created)} · spaces ${u.spaces} · posts ${u.posts}` +
      (u.admin ? " · admin" : "");
    const spacer = document.createElement("span");
    spacer.className = "spacer";
    const del = document.createElement("button");
    del.className = "btn small danger";
    del.textContent = "delete";
    del.title = "remove this account: sessions, profile, spaces, posts, votes";
    del.addEventListener("click", async () => {
      if (!window.confirm(`delete @${u.username} and all their data? this cannot be undone.`)) return;
      try {
        await adminApi("users/" + encodeURIComponent(u.username), { method: "DELETE" });
        void renderUsers();
      } catch (e) {
        alert((e as Error).message);
      }
    });
    top.append(who, meta, spacer, del);
    row.appendChild(top);

    const edits = document.createElement("div");
    edits.className = "row mt1";
    const s1 = arcSlot(u.arcana[0] || "");
    const s2 = arcSlot(u.arcana[1] || "");
    const status = document.createElement("span");
    status.className = "save-status";

    const save = async () => {
      if (s2.value && s1.value === s2.value) {
        s2.value = "";
      }
      const want = [s1.value, s2.value].filter(Boolean);
      try {
        const d = await adminApi("arcana", { method: "POST", body: { user: u.username, arcanas: want } });
        u.arcana = d.arcana;
        status.textContent = "saved";
        status.className = "save-status ok";
        window.setTimeout(() => { status.textContent = ""; }, 2500);
      } catch (e) {
        status.textContent = (e as Error).message;
        status.className = "save-status bad";
      }
    };
    s1.addEventListener("change", () => { void save(); });
    s2.addEventListener("change", () => { void save(); });
    edits.append(s1, s2, status);
    row.appendChild(edits);
    box.appendChild(row);
  }
}

// ---------------- thread moderation ----------------
async function renderPosts(): Promise<void> {
  const box = $("admin-posts");
  box.innerHTML = '<div class="dim">loading…</div>';
  let posts: any[];
  try {
    posts = (await adminApi("posts")).posts;
  } catch (e) {
    box.innerHTML = `<div class="error-box">${esc((e as Error).message)}</div>`;
    return;
  }
  box.innerHTML = "";
  if (!posts.length) {
    box.innerHTML = '<div class="dim">no threads yet.</div>';
    return;
  }
  for (const p of posts) {
    const item = document.createElement("div");
    item.className = "feed-item admin-post";
    const when = document.createElement("span");
    when.className = "when";
    when.textContent = fmtTime(p.time);
    const body = document.createElement("span");
    const who = document.createElement("a");
    who.className = "who";
    who.href = "/user.html?name=" + encodeURIComponent(p.author);
    who.textContent = "@" + p.author;
    const what = document.createElement("span");
    what.className = "what";
    what.textContent = (p.title ? "「" + p.title + "」 " : "") +
      (p.text || "").slice(0, 100) + (p.parent_id ? " · reply" : "");
    body.append(who, document.createTextNode(" "), what);
    const del = document.createElement("button");
    del.className = "btn small danger";
    del.textContent = "delete";
    del.addEventListener("click", async () => {
      try {
        await adminApi("posts/" + p.id, { method: "DELETE" });
        void renderPosts();
      } catch (e) {
        alert((e as Error).message);
      }
    });
    item.append(when, body, del);
    box.appendChild(item);
  }
}

async function loadMain(): Promise<void> {
  $("admin-main").classList.remove("hidden");
  renderLegend();
  wireCreateUser();
  void renderUsers();
  void renderPosts();
}

boot();
