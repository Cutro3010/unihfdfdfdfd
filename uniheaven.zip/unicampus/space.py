#!/usr/bin/env python3
"""
Uniheaven CLI - talk to a uniheaven server from the terminal.

Pure Python 3 standard library. No dependencies.

Quick start:
  python space.py register alice --server https://your-vps:8000
  python space.py login alice
  python space.py create "Analysis" --tags math --public
  python space.py send "Theorem 5 proof sketch" --space Analysis
  python space.py pull Analysis --out notes/
  python space.py push Analysis --dir notes/ --message "week 3 notes"
  python space.py comment Analysis --path notes/idea.md "nice idea!"
  python space.py branch Analysis solutions-v2
  python space.py merge Analysis --source solutions-v2
  python space.py search "eigenvalues"

The server address is remembered in ~/.spacecli.json after first use.
You can also set SPACE_SERVER=https://host:port once instead of --server.
"""

import argparse
import getpass
import hashlib
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

# ------------------------------------------------------------ theme ----
# The CLI mirrors the web UI's cyberangel / cybercore look:
#   cyber (dark)  = indigo night + ice-blue glow   [data-theme="dark"]
#   angel (light) = pearl white + cobalt chrome    [data-theme="light"]
# Colours are 24-bit ANSI escapes matching web/css/theme.css tokens.
# Disabled automatically when stdout is not a tty (scripts stay clean),
# or with NO_COLOR=1 / --no-color. Force a palette with SPACE_THEME.

def _tty():
    try:
        return sys.stdout.isatty()
    except Exception:
        return False


def _dark_bg():
    """Guess the terminal background from COLORFGBG ('<fg>;<bg>', 7/15 = light)."""
    v = os.environ.get("COLORFGBG", "")
    try:
        bg = int(v.split(";")[-1])
    except (ValueError, IndexError):
        return True                     # assume a dark terminal
    return bg not in (7, 15)


_CYBER = {
    "text": "38;2;230;237;243",         # warm white    #e6edf3
    "dim": "38;2;139;152;165",          #               #8b98a5
    "faint": "38;2;89;99;110",          #               #59636e
    "accent": "38;2;77;163;255",        # ice blue      #4da3ff
    "accent_dim": "38;2;31;111;235",    # cobalt        #1f6feb
    "ok": "38;2;63;185;80",             #               #3fb950
    "danger": "38;2;248;81;73",         #               #f85149
    "warn": "38;2;210;153;34",          #               #d29922
    "gold": "38;2;210;153;34",          # stars / arcana
    "panel": "48;2;21;26;33",           # bg-panel      #151a21
}

_ANGEL = {
    "text": "38;2;21;26;58",            # indigo ink    #151a3a
    "dim": "38;2;74;85;120",            #               #4a5578
    "faint": "38;2;117;128;160",        #               #7580a0
    "accent": "38;2;31;111;235",        # cobalt        #1f6feb
    "accent_dim": "38;2;77;163;255",    # ice blue      #4da3ff
    "ok": "38;2;26;127;55",             #               #1a7f37
    "danger": "38;2;207;34;46",         #               #cf222e
    "warn": "38;2;154;103;0",           #               #9a6700
    "gold": "38;2;154;103;0",           # stars / arcana
    "panel": "48;2;251;252;255",        # pearl         #fbfcff
}


class UI:
    """One styling instance; colours only when stdout is a tty."""

    def __init__(self):
        self.color = (not os.environ.get("NO_COLOR")) and _tty()
        want = os.environ.get("SPACE_THEME", "").strip().lower()
        dark = want == "dark" or (want != "light" and _dark_bg())
        self.pal = _CYBER if dark else _ANGEL
        self.theme = "cyber" if dark else "angel"

    def paint(self, name, s):
        if not self.color or not isinstance(s, str):
            return s
        return "\x1b[%sm%s\x1b[0m" % (self.pal[name], s)

    def bold(self, s):
        return "\x1b[1m%s\x1b[0m" % s if self.color else s


ui = UI()


def _c(name, s):
    return ui.paint(name, s)


def _b(s):
    return ui.bold(s)


def banner():
    """The CLI's little hero block: halo + logo + the classic statusbar line."""
    halo = " " * 8 + _c("accent", "✦")
    top = "╭" + "─" * 12 + "╮"
    mid = "│" + _b(_c("accent", "  uniheaven ")) + "│"
    bot = "╰" + "─" * 12 + "╯"
    print()
    print(halo)
    print("  " + _c("accent_dim", top))
    print("  " + _c("accent_dim", "│") + _b(_c("accent", "  uniheaven ")) + _c("accent_dim", "│"))
    print("  " + _c("accent_dim", bot))
    print("  " + _c("dim", "welcome to heaven! enjoy your stay!"))
    print("  " + _c("faint", "つづけるにはなにかボタンをおしてください"))
    print()


def sparkline(counts, width=56):
    """The profile page's 8-week revision bars, as block characters."""
    if not counts:
        return ""
    mx = max(counts) or 1
    blocks = "▁▂▃▄▅▆▇█"
    out = []
    for v in counts:
        if v <= 0:
            out.append(_c("faint", "·"))
        else:
            i = min(len(blocks) - 1, int(v / mx * (len(blocks) - 1)))
            out.append(_c("accent", blocks[i]))
    return "".join(out)


def stat_row(items):
    """Spec-table stat cards (label tab above, big number below)."""
    labels = [label.lower() for label, _ in items]
    values = [str(v) for _, v in items]
    w = max(len(l) for l in labels) + 1
    print("  ".join(_c("faint", l.ljust(w)) for l in labels))
    print("  ".join(_c("faint", "━" * w) for _ in labels))
    print("  ".join(_b(_c("accent", v.ljust(w))) for v in values))


CONFIG = Path.home() / ".spacecli.json"
DEFAULT_SERVER = os.environ.get("SPACE_SERVER", "http://127.0.0.1:8000")
MARKER = ".uniheaven.json"


class CliError(Exception):
    """CLI error; payload carries the full JSON body of a non-2xx response."""

    def __init__(self, message, payload=None):
        super().__init__(message)
        self.payload = payload


# ------------------------------------------------------------ plumbing ----

def cfg_load():
    if CONFIG.exists():
        try:
            return json.loads(CONFIG.read_text(encoding="utf-8"))
        except (ValueError, OSError):
            return {}
    return {}


def cfg_save(cfg):
    CONFIG.write_text(json.dumps(cfg, indent=1), encoding="utf-8")


def request(method, path, cfg, body=None, raw=False):
    url = cfg["server"].rstrip("/") + "/api/" + path
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    if body is not None:
        req.add_header("Content-Type", "application/json")
    if cfg.get("token"):
        req.add_header("Authorization", "Bearer " + cfg["token"])
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            payload = resp.read()
    except urllib.error.HTTPError as e:
        try:
            payload = json.loads(e.read().decode("utf-8"))
            msg = payload.get("error", "http %d" % e.code)
        except Exception:
            payload = None
            msg = "http %d" % e.code
        raise CliError(msg, payload)
    except urllib.error.URLError as e:
        raise CliError("cannot reach server at %s (%s)" % (cfg["server"], e.reason))
    if raw:
        return payload
    return json.loads(payload.decode("utf-8"))


def need_token(cfg):
    if not cfg.get("token"):
        raise CliError("not logged in - run: space login USERNAME")


def ask_password(twice=False):
    env = os.environ.get("SPACE_PASSWORD")
    if env is not None:
        return env
    pw = getpass.getpass("password: ")
    if twice:
        if pw != getpass.getpass("again: "):
            raise CliError("passwords do not match")
    return pw


def find_space(cfg, name):
    d = request("GET", "spaces", cfg)
    spaces = d["spaces"]
    by_id = [s for s in spaces if s["id"] == name]
    if by_id:
        return by_id[0]
    by_name = [s for s in spaces if s["name"] == name]
    if not by_name:
        raise CliError("no space named '%s'" % name)
    mine = [s for s in by_name if s["can_edit"]]
    if mine:
        return mine[0]
    if len(by_name) > 1:
        raise CliError("several spaces named '%s' - use one of these ids: %s"
                       % (name, ", ".join(s["id"] for s in by_name)))
    return by_name[0]


def ensure_inbox(cfg):
    need_token(cfg)
    d = request("GET", "spaces", cfg)
    mine = [s for s in d["spaces"] if s["name"] == "inbox" and s["can_edit"]]
    if mine:
        return mine[0]
    return request("POST", "spaces", cfg,
                   {"name": "inbox", "description": "personal quick notes",
                    "tags": ["inbox"], "public": False})


def fmt_time(t):
    if not t:
        return "-"
    d = time.time() - t
    if d < 60:
        return "just now"
    if d < 3600:
        return "%dm ago" % (d // 60)
    if d < 86400:
        return "%dh ago" % (d // 3600)
    if d < 86400 * 30:
        return "%dd ago" % (d // 86400)
    return time.strftime("%Y-%m-%d", time.localtime(t))


# ------------------------------------------------------------ commands ----

def cmd_register(args, cfg):
    pw = ask_password(twice=True)
    d = request("POST", "register", cfg,
                {"username": args.user, "password": pw,
                 "display_name": args.display or ""})
    cfg["token"] = d["token"]
    cfg["user"] = d["user"]["username"]
    cfg_save(cfg)
    print("registered and logged in as %s" % _b(_c("accent", "@" + d["user"]["username"])))
    if d["user"].get("admin"):
        print(_c("gold", "✦ you are the first user, so you are admin ✦"))


def cmd_login(args, cfg):
    pw = ask_password()
    d = request("POST", "login", cfg, {"username": args.user, "password": pw})
    cfg["token"] = d["token"]
    cfg["user"] = d["user"]["username"]
    cfg_save(cfg)
    print("logged in as %s" % _b(_c("accent", "@" + d["user"]["username"])))


def cmd_logout(args, cfg):
    if cfg.get("token"):
        try:
            request("POST", "logout", cfg)
        except CliError:
            pass
    cfg.pop("token", None)
    cfg_save(cfg)
    print(_c("faint", "logged out"))


def cmd_me(args, cfg):
    need_token(cfg)
    u = request("GET", "me", cfg)["user"]
    if not u:
        print("not logged in")
        return
    banner()
    print("@%s%s · joined %s"
          % (_b(_c("accent", u["username"])),
             _c("gold", " (admin)") if u.get("admin") else "",
             _c("dim", fmt_time(u["created"]))))
    print(_c("faint", "server %s · theme %s" % (cfg["server"], ui.theme)))


def cmd_create(args, cfg):
    need_token(cfg)
    s = request("POST", "spaces", cfg,
                {"name": args.name, "description": args.description or "",
                 "tags": [t.strip() for t in (args.tags or "").split(",") if t.strip()],
                 "public": not args.private})
    print("created space %s (%s)" % (_b(_c("accent", s["name"])), _c("faint", s["id"])))
    print(_c("faint", "open it at %s/space.html?id=%s"
             % (cfg["server"].rstrip("/"), s["id"])))


def cmd_list(args, cfg):
    d = request("GET", "spaces", cfg)
    spaces = d["spaces"]
    if args.mine:
        spaces = [s for s in spaces if s["can_edit"]]
    if args.tag:
        spaces = [s for s in spaces if args.tag in s["tags"]]
    if not spaces:
        print("no spaces")
        return
    print("%s · %d space(s)" % (_c("accent", "spaces"), len(spaces)))
    for s in sorted(spaces, key=lambda x: x["created"], reverse=True):
        star = _c("gold", "★") if s["starred"] else _c("faint", "☆")
        name_raw = s["name"].ljust(24)
        name = _b(_c("accent", name_raw)) if s["can_edit"] else name_raw
        owner = _c("dim", ("@" + s["owner"]).ljust(12))
        pub = _c("faint", "public ") if s["public"] else _c("warn", "private")
        fork = (" " + _c("faint", "(forked from @%s)" % s["forked_from"]["owner"])
                if s["forked_from"] else "")
        tags_raw = " ".join("#" + t for t in s["tags"]).ljust(40)
        tags = _c("accent_dim", tags_raw) if s["tags"] else tags_raw
        print("%s %s %s %s %s %s%s"
              % (star, name, owner, pub, tags, _c("faint", s["id"]), fork))


def cmd_send(args, cfg):
    need_token(cfg)
    if args.space:
        s = find_space(cfg, args.space)
    else:
        s = ensure_inbox(cfg)
    path = args.path or "inbox/%s.md" % time.strftime("%Y-%m-%d-%H%M%S")
    d = request("PUT", "spaces/%s/note?branch=%s" % (s["id"], urllib.parse.quote(args.branch or "main")),
                cfg, {"path": path, "content": args.text,
                      "message": args.message or ""})
    if d.get("unchanged"):
        print(_c("faint", "unchanged - %s already has this content" % path))
    else:
        print("saved %s/%s (%s)" % (_c("accent", s["name"]), _c("accent_dim", path),
                                    _c("faint", "rev " + str(d["rev"]))))


def cmd_pull(args, cfg):
    s = find_space(cfg, args.space)
    branch = args.branch or "main"
    d = request("GET", "spaces/%s/tree?branch=%s" % (s["id"], urllib.parse.quote(branch)), cfg)
    tree = d["tree"]
    out = Path(args.out or ".")
    out.mkdir(parents=True, exist_ok=True)
    n = 0
    for path, sha in tree.items():
        note = request("GET", "spaces/%s/note?path=%s&branch=%s"
                       % (s["id"], urllib.parse.quote(path), urllib.parse.quote(branch)), cfg)
        target = out / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(note["content"], encoding="utf-8", newline="\n")
        n += 1
    (out / MARKER).write_text(
        json.dumps({"space": s["id"], "name": s["name"], "branch": branch,
                    "rev": d["rev"]}, indent=1), encoding="utf-8")
    print("pulled %s note(s) from %s/%s into %s (%s)"
          % (_b(_c("accent", str(n))), _c("accent", s["name"]), branch,
             _c("accent_dim", str(out)), _c("faint", "rev " + str(d["rev"]))))


def cmd_push(args, cfg):
    base = Path(args.dir or ".")
    marker_file = base / MARKER
    if marker_file.exists():
        m = json.loads(marker_file.read_text(encoding="utf-8"))
        s = {"id": m["space"], "name": m.get("name", m["space"])}
        branch = args.branch or m.get("branch", "main")
    else:
        s = find_space(cfg, args.space or base.name)
        branch = args.branch or "main"
    d = request("GET", "spaces/%s/tree?branch=%s" % (s["id"], urllib.parse.quote(branch)), cfg)
    tree = d["tree"]
    pushed = 0
    for f in sorted(base.rglob("*.md")):
        rel = f.relative_to(base).as_posix()
        if rel == "README.md":
            continue
        data = f.read_bytes()
        local_sha = hashlib.sha1(data).hexdigest()
        if tree.get(rel) == local_sha:
            continue
        d2 = request("PUT", "spaces/%s/note?branch=%s"
                     % (s["id"], urllib.parse.quote(branch)), cfg,
                     {"path": rel, "content": data.decode("utf-8"),
                      "message": args.message or ""})
        if d2.get("unchanged"):
            print(_c("faint", "unchanged %s" % rel))
        else:
            print("pushed %s (%s)" % (_c("accent_dim", rel),
                                      _c("faint", "rev " + str(d2["rev"]))))
            pushed += 1
    if pushed == 0:
        print(_c("faint", "nothing to push (no .md changes) for %s/%s" % (s["name"], branch)))


def cmd_comment(args, cfg):
    s = find_space(cfg, args.space)
    request("POST", "spaces/%s/comments" % s["id"], cfg,
            {"path": args.path, "text": args.text})
    print("commented on %s/%s" % (_c("accent", s["name"]), _c("accent_dim", args.path)))


def cmd_branch(args, cfg):
    s = find_space(cfg, args.space)
    request("POST", "spaces/%s/branches" % s["id"], cfg,
            {"name": args.new, "from": args.from_branch or "main"})
    print("created branch %s on %s (from %s)" % (_b(_c("accent", args.new)),
                                                 _c("accent", s["name"]),
                                                 _c("faint", args.from_branch or "main")))


def merge_loop(s, cfg, src, dst, resolve):
    try:
        d = request("POST", "spaces/%s/merge" % s["id"], cfg,
                    {"source": src, "target": dst, "resolve": resolve or None})
    except CliError as e:
        if e.payload and "conflicts" in e.payload:
            d = e.payload                      # 409 = merge conflicts, not a hard error
        else:
            raise
    if "conflicts" not in d:
        if d.get("nothing_to_do"):
            print(_c("faint", "nothing to merge - %s and %s agree" % (src, dst)))
        else:
            print("merged %s into %s (%s, %s change(s))"
                  % (_c("accent", src), _c("accent", dst),
                     _c("faint", "rev " + str(d["rev"])),
                     _b(_c("ok", str(d["changes"])))))
        return
    print(_c("warn", "⚠ conflicts:"))
    for c in d["conflicts"]:
        choice = resolve.get(c["path"])
        if choice:
            print("  %s -> %s" % (_c("accent", c["path"]), _c("ok", choice)))
            continue
        if not sys.stdin.isatty():
            raise CliError(
                "conflict on %s - re-run with --resolve \"%s=ours|theirs\"" %
                (c["path"], c["path"]))
        print(_c("accent", "\n  file: %s" % c["path"]))
        try:
            o = request("GET", "spaces/%s/object?sha=%s" % (s["id"], c["ours_sha"]), cfg)
            t = request("GET", "spaces/%s/object?sha=%s" % (s["id"], c["theirs_sha"]), cfg)
        except CliError:
            o = t = {"content": ""}
        print(_c("faint", "  --- %s (ours) ---" % dst))
        print("\n".join("  " + ln for ln in (o["content"].splitlines() or [""])[:20]))
        print(_c("faint", "  --- %s (theirs) ---" % src))
        print("\n".join("  " + ln for ln in (t["content"].splitlines() or [""])[:20]))
        while True:
            try:
                ans = input(_c("accent", "  keep which? [o]urs / [t]heirs: ")).strip().lower()
            except (EOFError, OSError):
                pending = ", ".join(
                    "%s=ours|theirs" % c2["path"] for c2 in d["conflicts"]
                    if c2["path"] not in resolve)
                raise CliError(
                    "cannot prompt (not a terminal) - re-run with --resolve \"%s\""
                    % pending)
            if ans in ("o", "ours"):
                resolve[c["path"]] = "ours"
                break
            if ans in ("t", "theirs"):
                resolve[c["path"]] = "theirs"
                break
    merge_loop(s, cfg, src, dst, resolve)


def cmd_merge_entry(args, cfg):
    s = find_space(cfg, args.space)
    resolve = {}
    if args.resolve:
        for item in args.resolve.split(","):
            p, _, choice = item.rpartition("=")
            if choice in ("ours", "theirs"):
                resolve[p] = choice
    merge_loop(s, cfg, args.source, args.target or "main", resolve)


def cmd_diff(args, cfg):
    s = find_space(cfg, args.space)
    branch = args.branch or "main"
    hist = request("GET", "spaces/%s/history?branch=%s" % (s["id"], urllib.parse.quote(branch)), cfg)
    revs = [r["rev"] for r in hist["revs"]]
    if not revs:
        print(_c("faint", "no revisions on %s" % branch))
        return
    rb = args.rev_b if args.rev_b is not None else revs[0]
    ra = args.rev_a if args.rev_a is not None else max(0, rb - 1)
    d = request("GET", "spaces/%s/diff?branch=%s&rev_a=%d&rev_b=%d"
                % (s["id"], urllib.parse.quote(branch), ra, rb), cfg)
    if not d["files"]:
        print(_c("faint", "no differences between rev %s and rev %s" % (ra, rb)))
        return
    for f in d["files"]:
        print()
        print(_b("═" * 4 + " %s " % f["path"] + "═" * 4))
        for line in f["diff"]:
            if line.startswith("+"):
                print(_c("ok", line))
            elif line.startswith("-"):
                print(_c("danger", line))
            elif line.startswith("@@"):
                print(_c("accent", line))
            else:
                print(_c("dim", line))


def cmd_history(args, cfg):
    s = find_space(cfg, args.space)
    branch = args.branch or "main"
    d = request("GET", "spaces/%s/history?branch=%s" % (s["id"], urllib.parse.quote(branch)), cfg)
    print("%s · %s" % (_c("accent", "history"), _c("faint", "%s/%s" % (s["name"], branch))))
    for r in d["revs"]:
        print("%s %s @%s %s %s"
              % (_c("accent", ("rev " + str(r["rev"])).ljust(7)),
                 _c("faint", fmt_time(r["time"]).ljust(10)),
                 r["author"].ljust(16),
                 _c("dim", r["message"] or ""),
                 _c("ok" if r["changes"] else "faint",
                    "(%d change(s))" % len(r["changes"]))))


def cmd_fork(args, cfg):
    s = find_space(cfg, args.space)
    f = request("POST", "spaces/%s/fork" % s["id"], cfg)
    print("forked %s -> new space %s (%s)"
          % (_c("accent", s["name"]), _b(_c("accent", f["name"])), _c("faint", f["id"])))


def cmd_inbox(args, cfg):
    need_token(cfg)
    d = request("GET", "notifications", cfg)
    lst = d["notifications"]
    print("%s %d notification(s), %s"
          % (_c("accent", "bell"), len(lst),
             _c("warn", "%d unread" % d["unread"]) if d["unread"] else _c("faint", "0 unread")))
    for n in lst:
        mark = _c("accent", "●") if not n["read"] else _c("faint", "·")
        if n["type"] == "mention":
            where = ("in %s/%s" % (_c("accent", n["space_name"]), n["path"])) if n.get("space") else "in a post"
            print("%s @%s mentioned you %s" % (mark, n["actor"], where))
        elif n["type"] == "share":
            print("%s @%s shared %s with you (viewer)"
                  % (mark, n["actor"], _c("accent", n.get("space_name", ""))))
        else:
            print("%s @%s: %s" % (mark, n["actor"], n.get("text", "")))
    if d["unread"]:
        request("POST", "notifications/read", cfg, {"ids": [n["id"] for n in lst]})


def cmd_search(args, cfg):
    d = request("GET", "search?q=%s" % urllib.parse.quote(args.query), cfg)
    for s in d["spaces"]:
        print("space  %s %s %s"
              % (_c("accent", "▸ " + s["name"]),
                 _c("dim", "(@%s)" % s["owner"]),
                 _c("accent_dim", " ".join("#" + t for t in s["tags"]))))
    for n in d["notes"]:
        print("note   %s %s"
              % (_c("accent_dim", "▹ " + n["space_name"]),
                 _c("faint", "%s/%s" % (n["space"], n["path"]))))
    if not d["spaces"] and not d["notes"]:
        print(_c("faint", "no results for '%s'" % args.query))


def cmd_tags(args, cfg):
    d = request("GET", "tags", cfg)
    print(_c("accent", "tags") + " · " + _c("faint", "%d" % len(d["tags"])))
    print(" ".join("%s %s" % (_c("accent_dim", "#" + t), _c("faint", "(%d)" % c))
                   for t, c in sorted(d["tags"].items(), key=lambda x: -x[1])))


def cmd_star(args, cfg):
    s = find_space(cfg, args.space)
    request("POST", "star/%s" % s["id"], cfg)
    print("starred %s %s" % (_c("gold", "★"), _c("accent", s["name"])))


def cmd_unstar(args, cfg):
    s = find_space(cfg, args.space)
    request("POST", "unstar/%s" % s["id"], cfg)
    print("unstarred %s" % _c("faint", s["name"]))


def cmd_profile(args, cfg):
    name = args.user or cfg.get("user")
    if not name:
        raise CliError("no user given - run: space profile USERNAME")
    d = request("GET", "users/%s/profile" % name, cfg)
    u, p, s = d["user"], d["profile"], d["stats"]
    print("@%s%s · joined %s%s"
          % (_b(_c("accent", u["username"])),
             _c("gold", " (admin)") if u.get("admin") else "",
             _c("dim", fmt_time(u["created"])),
             _c("faint", " · this is you") if d["is_you"] else ""))
    if d.get("arcana"):
        print(_c("faint", "arcana: ")
              + " · ".join(_c("gold", a.lower()) for a in d["arcana"]))
    print("logo: %s" % (_c("accent", "set (%d bytes)" % len(p["logo"]))
                        if p.get("logo") else _c("faint", "none")))
    print("about: %s" % (p.get("about") or _c("faint", "(empty)")))
    stat_row([("spaces", s["spaces"]), ("notes", s["notes"]),
              ("revisions", s["revisions"]), ("comments", s["comments"]),
              ("stars given", s["stars_given"])])
    if s["tags"]:
        print("most used tags:  " + " ".join(
            "%s %s" % (_c("accent_dim", "#" + t), _c("faint", "(%d)" % c))
            for t, c in s["tags"][:8]))
    if s["words"]:
        print("most used words: " + " ".join(
            "%s %s" % (_c("accent" if i < 8 else "dim", w), _c("faint", "(%d)" % c))
            for i, (w, c) in enumerate(s["words"][:15])))
    if s["sparkline"]:
        print(_c("faint", "revisions · last 8 weeks: ")
              + sparkline([d2["count"] for d2 in s["sparkline"]]))


def cmd_about(args, cfg):
    need_token(cfg)
    request("PUT", "users/%s/profile" % cfg["user"], cfg, {"about": args.text})
    print("about updated for %s" % _b(_c("accent", "@" + cfg["user"])))


def cmd_rm(args, cfg):
    need_token(cfg)
    s = find_space(cfg, args.space)
    path = args.path
    d = request("DELETE",
                "spaces/%s/note?path=%s&branch=%s"
                % (s["id"], urllib.parse.quote(path),
                   urllib.parse.quote(args.branch or "main")), cfg)
    print("deleted %s note(s) under %s/%s (%s)"
          % (_b(_c("danger", str(d["deleted"]))), _c("accent", s["name"]),
             _c("accent_dim", path), _c("faint", "rev " + str(d["rev"]))))


def cmd_collab(args, cfg):
    need_token(cfg)
    s = find_space(cfg, args.space)
    collabs = list(s.get("collaborators") or [])
    if args.add:
        for name in args.add.split(","):
            name = name.strip()
            if name and name not in collabs:
                collabs.append(name)
    if args.remove:
        for name in args.remove.split(","):
            name = name.strip()
            if name in collabs:
                collabs.remove(name)
    if not args.add and not args.remove:
        print("collaborators of %s: %s"
              % (_c("accent", s["name"]),
                 " ".join(_c("accent_dim", "@" + c) for c in collabs) or _c("faint", "(none)")))
        return
    request("PATCH", "spaces/%s" % s["id"], cfg, {"collaborators": collabs})
    print("collaborators of %s: %s"
          % (_c("accent", s["name"]),
             " ".join(_c("accent_dim", "@" + c) for c in collabs) or _c("faint", "(none)")))


def cmd_post(args, cfg):
    need_token(cfg)
    d = request("POST", "posts", cfg, {"text": args.text})
    print("posted (%s)" % _c("faint", d["post"]["id"]))


def cmd_export(args, cfg):
    s = find_space(cfg, args.space)
    branch = args.branch or "main"
    data = request("GET", "spaces/%s/export.txt?branch=%s"
                   % (s["id"], urllib.parse.quote(branch)), cfg, raw=True)
    text = data.decode("utf-8")
    if args.out:
        with open(args.out, "w", encoding="utf-8", newline="\n") as f:
            f.write(text)
        print("exported %s/%s to %s" % (s["name"], branch, args.out))
    else:
        print(text)


# ------------------------------------------------------------ main ----

def build_parser():
    ap = argparse.ArgumentParser(prog="space",
                                 description="uniheaven CLI",
                                 epilog="theme: SPACE_THEME=dark|light (default: match "
                                        "your terminal) · NO_COLOR=1 or --no-color to "
                                        "disable colors",
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--server", default=None,
                    help="server URL (default %s or $SPACE_SERVER)" % DEFAULT_SERVER)
    ap.add_argument("--no-color", action="store_true",
                    help="disable colors (or set NO_COLOR=1)")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("register", help="create an account and log in")
    p.add_argument("user")
    p.add_argument("--display")
    p.set_defaults(fn=cmd_register)

    p = sub.add_parser("login", help="log in")
    p.add_argument("user")
    p.set_defaults(fn=cmd_login)

    p = sub.add_parser("logout", help="log out")
    p.set_defaults(fn=cmd_logout)

    p = sub.add_parser("me", help="who am I")
    p.set_defaults(fn=cmd_me)

    p = sub.add_parser("create", help="create a space")
    p.add_argument("name")
    p.add_argument("--description")
    p.add_argument("--tags", help="comma separated")
    p.add_argument("--private", action="store_true")
    p.set_defaults(fn=cmd_create)

    p = sub.add_parser("list", help="list spaces")
    p.add_argument("--mine", action="store_true")
    p.add_argument("--tag")
    p.set_defaults(fn=cmd_list)

    p = sub.add_parser("send", help="send a note")
    p.add_argument("text")
    p.add_argument("--space", help="space name (default: your private inbox)")
    p.add_argument("--path", help="note path, e.g. notes/idea.md")
    p.add_argument("--branch", help="branch to write to (default: main)")
    p.add_argument("--message", help="commit message")
    p.set_defaults(fn=cmd_send)

    p = sub.add_parser("pull", help="download a space as .md files")
    p.add_argument("space")
    p.add_argument("--branch")
    p.add_argument("--out", help="target folder (default: current dir)")
    p.set_defaults(fn=cmd_pull)

    p = sub.add_parser("push", help="upload changed .md files")
    p.add_argument("space", nargs="?", help="space name (optional if pulled here before)")
    p.add_argument("--branch")
    p.add_argument("--dir", help="folder to scan (default: current dir)")
    p.add_argument("--message", help="commit message")
    p.set_defaults(fn=cmd_push)

    p = sub.add_parser("comment", help="comment on a note")
    p.add_argument("space")
    p.add_argument("text")
    p.add_argument("--path", required=True)
    p.set_defaults(fn=cmd_comment)

    p = sub.add_parser("branch", help="create a branch")
    p.add_argument("space")
    p.add_argument("new")
    p.add_argument("--from-branch", dest="from_branch")
    p.set_defaults(fn=cmd_branch)

    p = sub.add_parser("merge", help="merge a branch (asks interactively on conflicts)")
    p.add_argument("space")
    p.add_argument("--source", required=True)
    p.add_argument("--target")
    p.add_argument("--resolve", help="comma separated path=ours|theirs")
    p.set_defaults(fn=cmd_merge_entry)

    p = sub.add_parser("diff", help="show a unified diff between revisions")
    p.add_argument("space")
    p.add_argument("--branch")
    p.add_argument("--rev-a", type=int, dest="rev_a")
    p.add_argument("--rev-b", type=int, dest="rev_b")
    p.set_defaults(fn=cmd_diff)

    p = sub.add_parser("history", help="revision history of a branch")
    p.add_argument("space")
    p.add_argument("--branch")
    p.set_defaults(fn=cmd_history)

    p = sub.add_parser("fork", help="fork someone's space into yours")
    p.add_argument("space")
    p.set_defaults(fn=cmd_fork)

    p = sub.add_parser("inbox", help="show notifications")
    p.set_defaults(fn=cmd_inbox)

    p = sub.add_parser("search", help="search notes and spaces")
    p.add_argument("query")
    p.set_defaults(fn=cmd_search)

    p = sub.add_parser("tags", help="list all tags")
    p.set_defaults(fn=cmd_tags)

    p = sub.add_parser("star", help="star a space")
    p.add_argument("space")
    p.set_defaults(fn=cmd_star)

    p = sub.add_parser("unstar", help="unstar a space")
    p.add_argument("space")
    p.set_defaults(fn=cmd_unstar)

    p = sub.add_parser("profile", help="show a user profile and stats")
    p.add_argument("user", nargs="?", help="username (default: you)")
    p.set_defaults(fn=cmd_profile)

    p = sub.add_parser("about", help="set your profile about text")
    p.add_argument("text")
    p.set_defaults(fn=cmd_about)

    p = sub.add_parser("rm", help="delete a note (or a folder: use notes/)")
    p.add_argument("space")
    p.add_argument("--path", required=True)
    p.add_argument("--branch")
    p.set_defaults(fn=cmd_rm)

    p = sub.add_parser("collab", help="view or manage space collaborators")
    p.add_argument("space")
    p.add_argument("--add", help="usernames to add (comma separated)")
    p.add_argument("--remove", help="usernames to remove (comma separated)")
    p.set_defaults(fn=cmd_collab)

    p = sub.add_parser("post", help="post a public message to the news feed")
    p.add_argument("text")
    p.set_defaults(fn=cmd_post)

    p = sub.add_parser("export", help="export a space as one .txt file")
    p.add_argument("space")
    p.add_argument("--branch")
    p.add_argument("--out", help="write to this file instead of printing")
    p.set_defaults(fn=cmd_export)

    return ap


def main():
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    argv = sys.argv[1:]
    server_arg = None
    if "--server" in argv:
        i = argv.index("--server")
        if i + 1 < len(argv):
            server_arg = argv[i + 1]
            del argv[i:i + 2]
    args = build_parser().parse_args(argv)
    if args.no_color:
        ui.color = False
    cfg = cfg_load()
    cfg.setdefault("server", DEFAULT_SERVER)
    if server_arg:
        cfg["server"] = server_arg
    if args.cmd not in ("register", "login"):
        cfg_save(cfg)
    try:
        args.fn(args, cfg)
        cfg_save(cfg)
    except CliError as e:
        print(_c("danger", "error: ") + str(e), file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        sys.exit(130)


if __name__ == "__main__":
    main()
