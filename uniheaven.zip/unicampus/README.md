# ============================================================
# Uniheaven - a tiny self-hosted GitHub for your students
#
# One Python process (stdlib only), JSON files on disk, plain
# HTML/CSS/TypeScript frontend, Python CLI. No frameworks, no SQL.
#
#   Notes ("spaces")  - folders + markdown files, #tags connect spaces
#   LaTeX             - $...$ and $$...$$ in every note (KaTeX, self-hosted)
#   Branching         - branch spaces, merge with 3-way conflict resolution
#   Restore           - view any revision of a note and restore it (a new
#                       revision is created, history keeps everything)
#   Import            - add .md files or a .zip of notes (one revision),
#                       or create a whole new space from files
#   Comments          - comment on notes, @mention other users
#   Fork / star       - fork a space with attribution, star your favorites
#   Search / activity - full-text search, tag cloud, activity feed
#   Accounts          - simple registration, passwords hashed (pbkdf2)
#   Sharing           - collaborators (edit) and viewers (read-only)
#   Profiles          - about text, 20x20 logo (pixel editor or photo),
#                       stats: top tags, top words, revision sparkline
#   Deletion          - delete notes or whole folders (history keeps them)
#   News              - twitter-style public posts with replies, @mentions
#                       and chat colors (!£XX codes)
#   Exports           - .zip of the space, one .txt file (structure on
#                       top, notes below), or the open note as PDF
#                       (client-side jsPDF + KaTeX SVG - no printing)
# ============================================================

Quickstart (local machine)
--------------------------
1. Requirements: Python 3.9+. That is all (no Node needed to *run* it).
2. Start the server:
      python server.py --port 8000
3. Open http://127.0.0.1:8000 and register - the first account is admin.
4. Create a space, write notes with $math$, branch, merge, comment.

CLI (space.py)
--------------
Install it once (it is one stdlib-only Python file):

      sudo bash install_cli.sh              # /usr/local/bin/space
      bash install_cli.sh --user            # ~/.local/bin (no root needed)
      sudo bash install_cli.sh --remove     # uninstall the CLI

      python space.py register alice --server http://127.0.0.1:8000
      python space.py create "Analysis" --tags math          # add --private to hide it
      python space.py send "Theorem 5 proof" --space Analysis --path notes/thm5.md
      python space.py rm Analysis --path notes/thm5.md       # delete a note
      python space.py rm Analysis --path notes/              # delete a folder
      python space.py pull Analysis --out notes/
      python space.py push Analysis --dir notes/ --message "week 3"
      python space.py comment Analysis --path notes/thm5.md "nice!"
      python space.py branch Analysis solutions    # then edit + merge
      python space.py merge Analysis --source solutions
      python space.py diff Analysis                # last revision
      python space.py history Analysis
      python space.py search "eigenvalues"
      python space.py fork Analysis                # copy someone's space
      python space.py inbox                        # mentions
      python space.py star Analysis
      python space.py profile alice                # profile + stats
      python space.py about "I teach analysis"     # set your about text
      python space.py collab Analysis              # list collaborators
      python space.py collab Analysis --add bob --remove carol
      python space.py post "office hours moved!"   # public news post
      python space.py export Analysis --out space.txt   # one-file export
      python space.py tags | list | me | logout

  - Login state lives in ~/.spacecli.json (a Bearer token).
  - Server address is remembered; override with --server or $SPACE_SERVER.
  - Non-interactive password: set $SPACE_PASSWORD (useful for scripts).
  - `send` without --space posts to your private auto-created "inbox" space.
  - Viewers: give read-only access via the web UI (space settings) or by
    adding them to the space meta - they see the space but cannot edit.

CLI style
---------
The CLI mirrors the web UI themes. Colors are on only when the output is a
terminal, so scripts stay clean.

      SPACE_THEME=dark|light   force a palette (default: match your terminal)
      NO_COLOR=1  or  --no-color   disable colors entirely

Chat colors
-----------
In posts and comments, a line starting with `!£` gets a color until the
end of the line. Add `m` for monospace (before or after the number).

      !£01..!£09   normal colors    !£11..!£19   dark colors
      !£21..!£29   light colors     !£00         rainbow (animated)
      !£30         warm white       !£m30        warm white + monospace

      Example:  "!£m30 office hours moved to Friday"
      works with $math$ and **bold** on the same line.

VPS installation (Ubuntu/Debian)
--------------------------------
The repo ships precompiled JS and KaTeX, so the VPS only needs Python 3.

      git clone <your-repo> uniheaven && cd uniheaven
      sudo bash install.sh

That installs to /opt/uniheaven, creates an unprivileged `uniheaven`
system user, starts a systemd service (uniheaven.service, port 8000),
and sets up a nightly backup cron (last 14 copies kept in
/opt/uniheaven/backups). Then:

      sudo ufw allow 8000/tcp
      http://<vps-ip>:8000     -> register, first user = admin

Upgrade later (data in /opt/uniheaven/data is never touched):

      git pull && sudo bash install.sh

Wipe everything and start over:

      sudo bash install.sh --fresh      # also: --dry-run to preview

Admin panel (/admin.html)
-------------------------
The admin panel is a separate login (username `eye`) with its own password.
On first start the server generates a random password and prints it once to
the journal (it is stored PBKDF2-hashed in data/admin_creds.json):

      journalctl -u uniheaven | grep "admin page"

To fix the password yourself, set UNI_ADMIN_PASSWORD in the systemd unit
(see the commented Environment line in uniheaven.service).

HTTPS (optional, your own domain)
---------------------------------
Run the app behind a reverse proxy and bind it to localhost. Edit
/etc/systemd/system/uniheaven.service, set Environment=UNI_HOST=127.0.0.1,
then `systemctl daemon-reload && systemctl restart uniheaven`.

Caddy (/etc/caddy/Caddyfile):
      your.domain.tld {
        reverse_proxy 127.0.0.1:8000
      }

nginx (in /etc/nginx/sites-available/uniheaven):
      server {
        listen 443 ssl;
        server_name your.domain.tld;
        # ssl_certificate ... (Let's Encrypt / certbot)
        location / { proxy_pass http://127.0.0.1:8000; }
      }

Backup / restore
----------------
      sudo tar -czf backup.tar.gz -C /opt/uniheaven data     # manual
      sudo tar -xzf backup.tar.gz -C /opt/uniheaven          # restore
The cron job /etc/cron.daily/uniheaven-backup does this nightly.

Uninstall
---------
      sudo bash uninstall.sh            # remove the app, KEEP data + backups
      sudo bash uninstall.sh --purge    # remove the app AND all data/backups
      sudo bash uninstall.sh --dry-run  # preview what would be removed

The CLI is removed with `sudo bash install_cli.sh --remove`.

Project layout
--------------
      server.py            HTTP server + JSON API (stdlib only)
      space.py             CLI client (styled like the web UI)
      install.sh           VPS installer (systemd + backup cron)
      uninstall.sh         removes the app (data kept unless --purge)
      install_cli.sh       installs / removes the `space` CLI
      tests/e2e.py         end-to-end API test suite
      web/                 frontend
        index.html         home: spaces, tags, search, feed
        space.html         space: tree, editor, comments, branches
        user.html          user profile: about, logo, stats
        css/theme.css      ALL design tokens (angel/light + cyber/dark themes)
        css/layout.css     component styles (tokens only)
        src/*.ts           TypeScript sources
        out/*.js           precompiled JS (committed - VPS needs no Node)
        vendor/katex/      self-hosted KaTeX (on-screen math)
        vendor/mathjax/    tex-svg bundle (vector math for the PDF export)
        vendor/jspdf/      self-hosted jsPDF + svg2pdf (note PDF export)
      data/                created at runtime (users, spaces, notes)
      STYLE.md             how to restyle the app (written for LLMs)

API (JSON, Bearer token or cookie)
----------------------------------
      POST /api/register  POST /api/login  POST /api/logout  GET /api/me
      GET|POST /api/spaces            GET|PATCH|DELETE /api/spaces/<id>
      GET  /api/spaces/<id>/tree?branch=
      GET  /api/spaces/<id>/note?path=&branch=&rev=
      PUT  /api/spaces/<id>/note?branch=        {path, content, message}
      DELETE /api/spaces/<id>/note?path=&branch=   (path with / = folder)
      GET  /api/spaces/<id>/object?sha=
      GET|PUT /api/users/<name>/profile         {about, logo (PNG data URL)}
      GET|POST /api/posts      DELETE /api/posts/<id>   (public news)
      GET  /api/spaces/<id>/export.txt?branch=  (one-file text export)
      GET|POST /api/spaces/<id>/comments?path=
      GET  /api/spaces/<id>/history?branch=
      GET  /api/spaces/<id>/note-history?path=&branch=   (revs touching a note)
      POST /api/spaces/<id>/restore          {path, branch, rev, message?}
      POST /api/spaces/<id>/import           {branch, files:[{path,content}], message?}
      POST /api/spaces/<id>/import-zip?branch=   (raw zip body, .md files only)
      POST /api/spaces/import                create a new space from files
      GET  /api/spaces/<id>/diff?branch=&rev_a=&rev_b=
      POST /api/spaces/<id>/branches            {name, from}
      POST /api/spaces/<id>/merge               {source, target, resolve?}
      POST /api/spaces/<id>/fork
      GET  /api/spaces/<id>/export?branch=      (zip download)
      GET  /api/search?q=      GET /api/tags      GET /api/activity
      POST /api/star/<id>      POST /api/unstar/<id>
      GET  /api/notifications  POST /api/notifications/read
      GET  /api/users?prefix=

Limits & safety
---------------
      - 1 MB per note, disk guard at ~9.5 GB (your 10 GB VPS)
      - login rate limit (8 tries / 10 min per user+IP)
      - registration rate limit (5 per hour per IP; UNI_REGISTER_MAX/WINDOW)
      - optional account cap: UNI_MAX_USERS env var
      - imports: max 50 MB zip / 500 files / 64 MB unzipped; bad entry paths
        (absolute, .., backslash) abort the whole import
      - note paths and branch names sanitized against traversal
      - space names limited to a safe character set (no header injection)
      - private spaces: only owner, collaborators and viewers can see them;
        the public activity feed redacts private-space details
      - passwords: pbkdf2-hmac-sha256, 120k rounds, per-user salt
      - admin panel password: random per install (data/admin_creds.json),
        printed once to the journal; override with UNI_ADMIN_PASSWORD
      - profile logos: PNG data URLs only, max 30 KB

Testing
-------
See web/tsconfig.json for the frontend build (needs `npm i typescript`,
then `npx tsc -p web`). Recompile after editing web/src/ and commit
web/out/ so the VPS stays Node-free.

Server API tests (56 checks: auth, rate limits, traversal, restore,
import, viewers, regression):

      rm -rf /tmp/unitest && UNI_REGISTER_MAX=7 python3 server.py \
          --port 8077 --datadir /tmp/unitest --host 127.0.0.1 &
      python3 tests/e2e.py
